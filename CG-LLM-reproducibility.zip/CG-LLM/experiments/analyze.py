"""
Summarise raw results into tables.

    python -m experiments.analyze main [ablation robustness ...] [--reference cgllm]

Writes results/tables/<experiment>/:
  summary.csv / summary.md / summary.tex   one row per configuration
  by_recipe.csv, by_tag.csv                accuracy breakdowns
  confusion.json, extraction_fields.csv
  significance.csv                         McNemar (exact) vs the reference, Holm-adjusted
  robustness.csv                           variant vs parent accuracy (if perturbations present)
"""

from __future__ import annotations

import argparse
import json
from collections import defaultdict
from pathlib import Path

import pandas as pd

from experiments.common import BENCH_DIR, RESULTS, load_results
from src.benchmark.schema import load_cases
from src.eval import metrics as M
from src.eval.stats import cluster_bootstrap, holm, mcnemar_exact
from src.rag.articles import load_corpus

GROUP_KEYS = ("method", "model", "lang", "temperature", "thinking")
MAIN_COLS = ["accuracy", "macro_f1", "unsafe_permissive_rate", "over_conservative_rate", "mean_cost", "coverage",
             "selective_accuracy", "escalation_precision", "incomplete_recall", "citation_precision",
             "citation_recall", "hallucinated_citation_rate", "modification_validity", "trigger_f1",
             "extraction_case_exact", "consistency", "ece", "aurc", "mean_n_calls", "mean_prompt_tokens",
             "mean_completion_tokens", "mean_llm_latency_s", "mean_cost_cny"]


def load_all_cases() -> dict:
    cases = {}
    for name in ("cases.jsonl", "perturbed.jsonl", "paraphrased.jsonl"):
        p = BENCH_DIR / name
        if p.exists():
            for c in load_cases(p):
                cases[c.case_id] = c
    return cases


def corpus_ids() -> set[str]:
    reg = Path(__file__).resolve().parents[1] / "data" / "regulations"
    return {a.article_id for lang in ("en", "zh") for a in load_corpus(reg, lang)}


def group(records: list[dict], keys=GROUP_KEYS) -> dict[tuple, list[dict]]:
    g = defaultdict(list)
    for r in records:
        g[tuple(r.get(k) for k in keys) + (r.get("perturbation") or "clean",)].append(r)
    return g


def fmt_ci(p: float, lo: float, hi: float) -> str:
    return f"{100 * p:.1f} [{100 * lo:.1f}, {100 * hi:.1f}]"


def per_case_correct(records: list[dict]) -> dict[str, bool]:
    """Majority-vote correctness across repeats per case."""
    by = defaultdict(list)
    for r in records:
        by[r["case_id"]].append(M.is_correct(r))
    return {k: sum(v) * 2 > len(v) for k, v in by.items()}


def analyze(exp: str, reference: str, n_boot: int) -> None:
    records = load_results(exp)
    if not records:
        print(f"[{exp}] no results")
        return
    cases = load_all_cases()
    cids = corpus_ids()
    out = RESULTS / "tables" / exp
    out.mkdir(parents=True, exist_ok=True)

    rows, confusions, fields = [], {}, []
    groups = group(records)
    for key, recs in sorted(groups.items(), key=lambda kv: str(kv[0])):
        s = M.summarize(recs, cases, cids)
        acc = cluster_bootstrap(recs, M.accuracy, n_boot=n_boot)
        upr = cluster_bootstrap(recs, M.unsafe_permissive_rate, n_boot=n_boot)
        row = dict(zip(GROUP_KEYS + ("perturbation",), key))
        row.update({k: s.get(k) for k in ["n", "n_cases"] + MAIN_COLS})
        row["accuracy_ci"] = fmt_ci(*acc)
        row["upr_ci"] = fmt_ci(*upr)
        rows.append(row)
        confusions["|".join(map(str, key))] = M.confusion(recs)
        ex = M.extraction_stats(recs, cases)["extraction_field_acc"]
        if ex:
            fields.append(dict(zip(GROUP_KEYS + ("perturbation",), key), **ex))
    df = pd.DataFrame(rows)
    df.to_csv(out / "summary.csv", index=False)
    show = df[[*GROUP_KEYS, "perturbation", "n_cases", "accuracy_ci", "macro_f1", "upr_ci", "over_conservative_rate",
               "mean_cost", "coverage", "citation_precision", "modification_validity", "mean_completion_tokens"]]
    (out / "summary.md").write_text(show.to_markdown(index=False, floatfmt=".3f"), encoding="utf-8")
    (out / "summary.tex").write_text(show.to_latex(index=False, float_format="%.3f"), encoding="utf-8")
    (out / "confusion.json").write_text(json.dumps(confusions, indent=1), encoding="utf-8")
    if fields:
        pd.DataFrame(fields).to_csv(out / "extraction_fields.csv", index=False)

    # breakdowns
    br, bt = [], []
    for key, recs in groups.items():
        base = dict(zip(GROUP_KEYS + ("perturbation",), key))
        by_recipe, by_tag = defaultdict(list), defaultdict(list)
        for r in recs:
            by_recipe[r["recipe"]].append(r)
            c = cases.get(r["case_id"])
            for t in (c.tags if c else []):
                by_tag[t].append(r)
        br += [dict(base, recipe=k, n=len(v), accuracy=M.accuracy(v), upr=M.unsafe_permissive_rate(v))
               for k, v in by_recipe.items()]
        bt += [dict(base, tag=k, n=len(v), accuracy=M.accuracy(v), upr=M.unsafe_permissive_rate(v))
               for k, v in by_tag.items()]
    pd.DataFrame(br).to_csv(out / "by_recipe.csv", index=False)
    pd.DataFrame(bt).to_csv(out / "by_tag.csv", index=False)

    # significance vs reference (paired on cases, same model/lang/temp/perturbation)
    sig = []
    by_cfg = defaultdict(dict)
    for key, recs in groups.items():
        method, rest = key[0], key[1:]
        by_cfg[rest][method] = per_case_correct(recs)
    for rest, methods in by_cfg.items():
        ref = methods.get(reference)
        if ref is None:
            continue
        pvals = {}
        for m, cor in methods.items():
            if m == reference:
                continue
            common = sorted(set(ref) & set(cor))
            if not common:
                continue
            t = mcnemar_exact([ref[c] for c in common], [cor[c] for c in common])
            pvals[m] = t["p_value"]
            sig.append(dict(zip(GROUP_KEYS[1:] + ("perturbation",), rest), method=m, reference=reference,
                            n=len(common), ref_acc=sum(ref[c] for c in common) / len(common),
                            acc=sum(cor[c] for c in common) / len(common), **t))
        adj = holm(pvals)
        for s in sig:
            if s["method"] in adj and tuple(s.get(k) for k in GROUP_KEYS[1:] + ("perturbation",)) == rest:
                s["p_holm"] = adj[s["method"]]
    if sig:
        pd.DataFrame(sig).to_csv(out / "significance.csv", index=False)

    # robustness: variant accuracy vs its own parent cases
    pert = [r for r in records if r.get("perturbation")]
    if pert:
        rob = []
        for key, recs in group(pert).items():
            parents = {cases[r["case_id"]].parent_id for r in recs if r["case_id"] in cases}
            rob.append(dict(zip(GROUP_KEYS + ("perturbation",), key), n=len(recs), accuracy=M.accuracy(recs),
                            upr=M.unsafe_permissive_rate(recs), n_parents=len(parents)))
        pd.DataFrame(rob).to_csv(out / "robustness.csv", index=False)

    print(f"[{exp}] {len(records)} records, {len(rows)} configurations -> {out}")
    print(show.to_markdown(index=False, floatfmt=".3f"))


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("experiments", nargs="+")
    ap.add_argument("--reference", default="cgllm")
    ap.add_argument("--n-boot", type=int, default=2000)
    args = ap.parse_args()
    for exp in args.experiments:
        analyze(exp, args.reference, args.n_boot)


if __name__ == "__main__":
    main()
