"""
Independent human annotation of benchmark labels (addresses label circularity).

    python -m experiments.annotation export --n 120 --annotators A B C
    # annotators fill the 'decision' (APPROVE/MODIFY/REJECT/ESCALATE) and 'rationale' columns
    python -m experiments.annotation score

Files live in results/annotation/. Sheets contain no gold labels; the answer
key is written separately.
"""

from __future__ import annotations

import argparse
import itertools
import random
from collections import defaultdict
from pathlib import Path

import pandas as pd

from experiments.common import BENCH_DIR, RESULTS
from src.benchmark.schema import load_cases
from src.eval.stats import cohen_kappa, fleiss_kappa
from src.pipelines.prompts import render_context

DIR = RESULTS / "annotation"
GUIDE = """Annotation guide
1. Read the application text and the authority records (submission time, approved operations, geofence zones).
2. Apply the rule sheet (constraints.yaml, printed in sheet 'rules').
3. decision: APPROVE / MODIFY (approvable with conditions or a changed time/altitude) / REJECT / ESCALATE (essential information missing).
4. rationale: one sentence naming the decisive rule(s).
Work independently; do not discuss cases with other annotators."""


def export(n: int, annotators: list[str], seed: int, lang: str) -> None:
    cases = load_cases(BENCH_DIR / "cases.jsonl", split="test")
    rng = random.Random(seed)
    by_recipe = defaultdict(list)
    for c in cases:
        by_recipe[c.recipe].append(c)
    per = max(1, n // len(by_recipe))
    sample = [c for v in by_recipe.values() for c in rng.sample(v, min(per, len(v)))]
    rng.shuffle(sample)
    sample = sample[:n]
    DIR.mkdir(parents=True, exist_ok=True)
    from src.policy.constraints import default_table
    rules = pd.DataFrame([{"id": c.id, "rule": c.name, "effect": str(c.effect), "params": str(c.params or ""),
                           "exemption": c.exemption, "articles": ", ".join(c.articles)} for c in default_table().constraints])
    sheet = pd.DataFrame([{"item": i + 1, "case_id": c.case_id, "application": c.text(lang),
                           "authority_records": render_context(c), "decision": "", "rationale": ""}
                          for i, c in enumerate(sample)])
    for a in annotators:
        with pd.ExcelWriter(DIR / f"annotator_{a}.xlsx") as xw:
            pd.DataFrame({"guide": GUIDE.splitlines()}).to_excel(xw, sheet_name="guide", index=False)
            rules.to_excel(xw, sheet_name="rules", index=False)
            sheet.to_excel(xw, sheet_name="cases", index=False)
    pd.DataFrame([{"case_id": c.case_id, "gold": c.gold.decision, "recipe": c.recipe} for c in sample]).to_csv(
        DIR / "answer_key.csv", index=False)
    print(f"exported {len(sample)} cases for {annotators} -> {DIR}")


def score() -> None:
    key = pd.read_csv(DIR / "answer_key.csv")
    sheets = {p.stem.split("_", 1)[1]: pd.read_excel(p, sheet_name="cases") for p in sorted(DIR.glob("annotator_*.xlsx"))}
    labels = {}
    for a, df in sheets.items():
        df["decision"] = df["decision"].astype(str).str.strip().str.upper()
        labels[a] = dict(zip(df["case_id"], df["decision"]))
    ids = [c for c in key["case_id"] if all(labels[a].get(c) in ("APPROVE", "MODIFY", "REJECT", "ESCALATE") for a in labels)]
    gold = dict(zip(key["case_id"], key["gold"]))
    rows = []
    for a in labels:
        la = [labels[a][c] for c in ids]
        rows.append({"pair": f"{a} vs gold", "n": len(ids), "agreement": sum(x == gold[c] for x, c in zip(la, ids)) / len(ids),
                     "kappa": cohen_kappa(la, [gold[c] for c in ids])})
    for a, b in itertools.combinations(labels, 2):
        la, lb = [labels[a][c] for c in ids], [labels[b][c] for c in ids]
        rows.append({"pair": f"{a} vs {b}", "n": len(ids), "agreement": sum(x == y for x, y in zip(la, lb)) / len(ids),
                     "kappa": cohen_kappa(la, lb)})
    if len(labels) > 2:
        rows.append({"pair": "Fleiss (annotators)", "n": len(ids), "agreement": None,
                     "kappa": fleiss_kappa([[labels[a][c] for a in labels] for c in ids])})
    out = pd.DataFrame(rows)
    out.to_csv(DIR / "agreement.csv", index=False)
    dis = [{"case_id": c, "gold": gold[c], **{a: labels[a][c] for a in labels}} for c in ids
           if any(labels[a][c] != gold[c] for a in labels)]
    pd.DataFrame(dis).to_csv(DIR / "disagreements.csv", index=False)
    print(out.to_markdown(index=False, floatfmt=".3f"))
    print(f"{len(dis)} cases with at least one disagreement -> {DIR / 'disagreements.csv'}")


def main() -> None:
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    e = sub.add_parser("export")
    e.add_argument("--n", type=int, default=120)
    e.add_argument("--annotators", nargs="+", default=["A", "B"])
    e.add_argument("--seed", type=int, default=7)
    e.add_argument("--lang", default="en")
    sub.add_parser("score")
    args = ap.parse_args()
    if args.cmd == "export":
        export(args.n, args.annotators, args.seed, args.lang)
    else:
        score()


if __name__ == "__main__":
    main()
