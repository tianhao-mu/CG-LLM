"""
Scalability of the deterministic layer (no LLM calls).

  1. Separation assessment latency vs number of approved operations, with and
     without the STRtree index (results must be identical).
  2. Full engine evaluation + modification search latency on benchmark cases.

    python -m experiments.bench_scalability [--sizes 10 100 1000 10000 50000]
"""

from __future__ import annotations

import argparse
import random
import statistics
import time
from datetime import datetime, timedelta

import pandas as pd
from pyproj import Transformer

from experiments.common import BENCH_DIR, RESULTS
from src.airspace.separation import SeparationEngine, Volume
from src.benchmark.generator import rect
from src.benchmark.schema import load_cases
from src.policy.engine import RuleEngine

_FWD = Transformer.from_crs("EPSG:4326", "EPSG:4547", always_xy=True)


def synthetic_ops(n: int, seed: int = 0, extent_m: float = 30_000) -> list[Volume]:
    rng = random.Random(seed)
    cx, cy = _FWD.transform(113.93, 22.54)
    day = datetime(2026, 11, 10)
    ops = []
    for i in range(n):
        x, y = cx + rng.uniform(-extent_m / 2, extent_m / 2), cy + rng.uniform(-extent_m / 2, extent_m / 2)
        t0 = day + timedelta(minutes=rng.randrange(6 * 60, 20 * 60, 15))
        lo = rng.choice([0, 20, 40, 60])
        ops.append(Volume.from_lonlat(f"OP{i}", rect(x, y, rng.choice([200, 400, 800]), rng.choice([200, 400, 800])),
                                      lo, lo + rng.choice([30, 60, 80]), t0, t0 + timedelta(minutes=rng.choice([30, 60, 120]))))
    return ops


def bench_separation(sizes: list[int], n_queries: int) -> pd.DataFrame:
    rows = []
    for n in sizes:
        ops = synthetic_ops(n)
        queries = synthetic_ops(n_queries, seed=1)
        for use_index in (True, False):
            if not use_index and n > 20_000:
                continue
            t0 = time.perf_counter()
            eng = SeparationEngine(ops, use_index=use_index)
            build = time.perf_counter() - t0
            lat, sev = [], []
            # Brute force is O(n) per query; a small query sample suffices for its latency and the identity check.
            for q in (queries if use_index or n < 2000 else queries[:10]):
                t = time.perf_counter()
                rep = eng.assess(q)
                lat.append(time.perf_counter() - t)
                sev.append(sorted((p.other_id, p.severity.value) for p in rep.conflicts))
            rows.append({"n_ops": n, "index": use_index, "build_s": build, "mean_ms": 1000 * statistics.mean(lat),
                         "p95_ms": 1000 * sorted(lat)[max(0, int(0.95 * len(lat)) - 1)],
                         "signature": hash(str(sev[:10]))})
            print(rows[-1])
    df = pd.DataFrame(rows)
    for n, g in df.groupby("n_ops"):
        if g["signature"].nunique() > 1:
            print(f"WARNING: indexed and brute-force results differ at n={n}")
    df["identical_results"] = df.groupby("n_ops")["signature"].transform(lambda s: s.nunique() == 1)
    return df.drop(columns="signature")


def bench_engine(limit: int) -> pd.DataFrame:
    engine = RuleEngine()
    rows = []
    for c in load_cases(BENCH_DIR / "cases.jsonl", split="test")[:limit]:
        facts = c.gold.request_facts()
        t = time.perf_counter()
        d = engine.evaluate(facts, c.context)
        rows.append({"case_id": c.case_id, "recipe": c.recipe, "decision": d.decision,
                     "searched": d.modification is not None or any("no verified" in t.detail for t in d.triggers),
                     "n_ops": len(c.context.approved_ops), "ms": 1000 * (time.perf_counter() - t)})
    return pd.DataFrame(rows)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--sizes", nargs="*", type=int, default=[10, 100, 1000, 5000, 10000, 50000])
    ap.add_argument("--queries", type=int, default=200)
    ap.add_argument("--cases", type=int, default=10_000)
    args = ap.parse_args()
    out = RESULTS / "tables" / "scalability"
    out.mkdir(parents=True, exist_ok=True)
    sep = bench_separation(args.sizes, args.queries)
    sep.to_csv(out / "separation.csv", index=False)
    eng = bench_engine(args.cases)
    eng.to_csv(out / "engine_cases.csv", index=False)
    print(sep.to_markdown(index=False))
    print(eng.groupby("searched")["ms"].describe().to_markdown())


if __name__ == "__main__":
    main()
