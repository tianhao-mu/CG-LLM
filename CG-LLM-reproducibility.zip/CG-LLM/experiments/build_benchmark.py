"""
Build the benchmark.

    python -m experiments.build_benchmark                      # cases + perturbations
    python -m experiments.build_benchmark --paraphrase-model glm-4-flash

Writes to data/benchmark/v1/:
  cases.jsonl        clean cases (dev/test split)
  perturbed.jsonl    surface variants of the test cases
  paraphrased.jsonl  LLM paraphrases that pass the fact-preservation check
  build_report.json  counts, label distribution, recipe/engine mismatches
"""

from __future__ import annotations

import argparse
from collections import Counter
from concurrent.futures import ThreadPoolExecutor

from tqdm import tqdm

from experiments.common import BENCH_DIR, load_env, setup_logging
from src.benchmark.generator import generate
from src.benchmark.perturb import PARAPHRASE_PROMPT, make_variants, paraphrase_preserves_facts
from src.benchmark.schema import dump_json, load_cases, save_cases
from src.policy.engine import RuleEngine


def paraphrase(cases, model: str, workers: int, max_n: int | None):
    from src.llm.providers import LLMClient
    client = LLMClient()
    todo = [c for c in cases if c.split == "test"][: max_n or None]

    def one(c):
        r = client.chat(model, [{"role": "user", "content": PARAPHRASE_PROMPT.format(text=c.texts["en"])}],
                        temperature=0.7, max_tokens=800)
        text = (r.text or "").strip()
        if r.error or not text or not paraphrase_preserves_facts(c.texts["en"], text):
            return None
        return c.model_copy(update={"case_id": f"{c.case_id}~paraphrase", "parent_id": c.case_id,
                                    "perturbation": "paraphrase", "texts": {"en": text, "zh": c.texts["zh"]}}, deep=True)

    with ThreadPoolExecutor(workers) as pool:
        out = list(tqdm(pool.map(one, todo), total=len(todo), desc="paraphrase"))
    kept = [c for c in out if c is not None]
    return kept, {"attempted": len(todo), "kept": len(kept), "usage": client.usage_summary()}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--n-per-recipe", type=int, default=20)
    ap.add_argument("--seed", type=int, default=2026)
    ap.add_argument("--dev-frac", type=float, default=0.2)
    ap.add_argument("--paraphrase-model")
    ap.add_argument("--paraphrase-max", type=int)
    ap.add_argument("--workers", type=int, default=4)
    ap.add_argument("--only-paraphrase", action="store_true")
    args = ap.parse_args()
    load_env()
    setup_logging()

    if args.only_paraphrase:
        cases = load_cases(BENCH_DIR / "cases.jsonl")
    else:
        cases, report = generate(args.n_per_recipe, args.seed, args.dev_frac)
        save_cases(cases, BENCH_DIR / "cases.jsonl")
        engine = RuleEngine()
        variants = [v for c in cases if c.split == "test" for v in make_variants(c, engine, seed=args.seed)]
        save_cases(variants, BENCH_DIR / "perturbed.jsonl")
        report["n_cases"] = len(cases)
        report["splits"] = dict(Counter(c.split for c in cases))
        report["perturbations"] = dict(Counter(v.perturbation for v in variants))
        report["trigger_counts"] = dict(Counter(t for c in cases for t in c.gold.trigger_ids))
        report["tags"] = dict(Counter(t for c in cases for t in c.tags))
        dump_json(report, BENCH_DIR / "build_report.json")
        print(f"cases={len(cases)} perturbed={len(variants)} decisions={report['per_decision']}")
        print(f"recipe/engine mismatches (resampled): {report['mismatch']}")

    if args.paraphrase_model:
        kept, rep = paraphrase(cases, args.paraphrase_model, args.workers, args.paraphrase_max)
        save_cases(kept, BENCH_DIR / "paraphrased.jsonl")
        dump_json(rep, BENCH_DIR / "paraphrase_report.json")
        print(f"paraphrases kept {rep['kept']}/{rep['attempted']}")


if __name__ == "__main__":
    main()
