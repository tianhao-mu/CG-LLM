"""
Write data/geofences/nanshan.geojson.

Zone footprints are coarse rectangles around real landmarks in Nanshan and
Bao'an (Shenzhen). They are approximations for the experiment, not official
geofence data; every feature records that in ``provenance``.

    python -m experiments.build_geofences
"""

from __future__ import annotations

import json
from pathlib import Path

from src.airspace.geofence import zones_to_geojson
from src.geo.projection import rectangle_lonlat

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "data" / "geofences" / "nanshan.geojson"
PROV = "approximated_for_experiment"

# (zone_id, name, type, lon, lat, width_m, height_m, exempt_purposes)
STATIC_ZONES = [
    ("Z_AIRPORT_ZGSZ", "Shenzhen Bao'an International Airport control zone", "AIRPORT_CONTROL",
     113.8110, 22.6390, 9000, 7000, ["airport_inspection"]),
    ("Z_SENSITIVE_A", "Sensitive facility protection area A (synthetic)", "SENSITIVE_FACILITY",
     113.9020, 22.5530, 900, 700, []),
    ("Z_PROHIBITED_P1", "Prohibited area P1 (synthetic)", "PROHIBITED",
     113.9640, 22.5640, 600, 600, []),
    ("Z_INFRA_SHEKOU_PORT", "Shekou container port", "INFRASTRUCTURE",
     113.8960, 22.4730, 1800, 1200, ["infrastructure_inspection"]),
    ("Z_INFRA_CHIWAN_PORT", "Chiwan container terminal", "INFRASTRUCTURE",
     113.8820, 22.4620, 1200, 900, ["infrastructure_inspection"]),
    ("Z_INFRA_SZBAY_PORT", "Shenzhen Bay Port (border checkpoint hub)", "INFRASTRUCTURE",
     113.9470, 22.5030, 900, 700, ["infrastructure_inspection"]),
    ("Z_INFRA_NANSHAN_POWER", "Nanshan thermal power plant", "INFRASTRUCTURE",
     113.9070, 22.5050, 700, 600, ["infrastructure_inspection"]),
    ("Z_INFRA_XILI_WATER", "Xili reservoir drinking-water protection area", "INFRASTRUCTURE",
     113.9600, 22.6000, 2000, 1500, ["infrastructure_inspection"]),
]


def build() -> dict:
    zones = []
    for zid, name, ztype, lon, lat, w, h, exempt in STATIC_ZONES:
        zones.append({
            "zone_id": zid, "name": name, "zone_type": ztype,
            "alt_floor_m": 0, "alt_ceiling_m": 10000,
            "exempt_purposes": exempt, "provenance": PROV,
            "center": [lon, lat], "size_m": [w, h],
            "coordinates": rectangle_lonlat(lon, lat, w, h),
        })
    return zones_to_geojson(zones)


def main() -> None:
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(build(), ensure_ascii=False, indent=1), encoding="utf-8")
    print(f"wrote {OUT}")


if __name__ == "__main__":
    main()
