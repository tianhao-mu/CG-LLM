"""
Export the article-level corpus and pre-compute dense embeddings.

    python -m experiments.build_index            # BM25 only needs the corpus
    python -m experiments.build_index --dense    # also BGE-M3 embeddings (needs sentence-transformers)

Writes data/index/articles_<lang>.jsonl and corpus_stats.json.
"""

from __future__ import annotations

import argparse
import json
from collections import Counter

from experiments.common import ROOT, write_jsonl
from src.rag.articles import load_corpus
from src.rag.hybrid import INDEX_DIR, REG_DIR, HybridRetriever


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--dense", action="store_true")
    ap.add_argument("--dense-model", default="BAAI/bge-m3")
    ap.add_argument("--device", default="cpu")
    args = ap.parse_args()
    stats = {}
    for lang in ("en", "zh"):
        arts = load_corpus(REG_DIR, lang)
        write_jsonl([{"article_id": a.article_id, "doc_id": a.doc_id, "number": a.number, "chars": len(a.text),
                      "text": a.text} for a in arts], INDEX_DIR / f"articles_{lang}.jsonl")
        stats[lang] = {"articles": len(arts), "per_doc": dict(Counter(a.doc_id for a in arts)),
                       "mean_chars": sum(len(a.text) for a in arts) / len(arts)}
        if args.dense:
            r = HybridRetriever(lang=lang, mode="dense", dense_model=args.dense_model, articles=arts, device=args.device)
            print(f"{lang}: dense index ready ({r.describe()})")
    (INDEX_DIR / "corpus_stats.json").write_text(json.dumps(stats, indent=1, ensure_ascii=False))
    print(json.dumps(stats, indent=1, ensure_ascii=False))
    print(f"-> {INDEX_DIR.relative_to(ROOT)}")


if __name__ == "__main__":
    main()
