"""
Qualitative case studies.

    python -m experiments.case_study main                       # auto-pick illustrative cases
    python -m experiments.case_study main --cases MODIFY_SEPARATION_TIME-0123

Auto-pick: (a) baseline unsafe-permissive but CG-LLM correct, (b) CG-LLM
escalated a case whose extraction was wrong, (c) a verified modification.
Writes results/case_studies/<experiment>.md
"""

from __future__ import annotations

import argparse
import json
from collections import defaultdict

from experiments.analyze import load_all_cases
from experiments.common import RESULTS, load_results
from src.eval.metrics import PERMISSIVENESS, pred_label
from src.pipelines.prompts import render_context


def pick(by_case: dict, baseline: str, ours: str, k: int) -> list[str]:
    a, b, c = [], [], []
    for cid, d in by_case.items():
        o, bl = d.get(ours), d.get(baseline)
        if not o:
            continue
        if bl and o["decision"] == o["gold_decision"] and pred_label(bl) in PERMISSIVENESS \
                and o["gold_decision"] in PERMISSIVENESS and PERMISSIVENESS[pred_label(bl)] > PERMISSIVENESS[o["gold_decision"]]:
            a.append(cid)
        if o["decision"] == "ESCALATE" and o.get("pre_escalation_decision") != o["gold_decision"]:
            b.append(cid)
        if o["decision"] == "MODIFY" and (o.get("modification") or {}).get("summary") and o["decision"] == o["gold_decision"]:
            c.append(cid)
    return a[:k] + b[:k] + c[:k]


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("experiment")
    ap.add_argument("--cases", nargs="*")
    ap.add_argument("--baseline", default="llm_rules_rag")
    ap.add_argument("--ours", default="cgllm")
    ap.add_argument("--k", type=int, default=2)
    args = ap.parse_args()
    cases = load_all_cases()
    by_case = defaultdict(dict)
    for r in load_results(args.experiment):
        if r["repeat"] == 0 and not r.get("perturbation"):
            by_case[r["case_id"]][r["method"]] = r
    ids = args.cases or pick(by_case, args.baseline, args.ours, args.k)
    lines = [f"# Case studies ({args.experiment})\n"]
    for cid in ids:
        c = cases[cid]
        lines += [f"## {cid}  (gold: {c.gold.decision})\n", "**Application**\n", c.text("en") + "\n",
                  "**Authority records**\n", "```\n" + render_context(c) + "\n```\n",
                  "**Gold engine report**\n", "```\n" + json.dumps(c.gold.engine.get("trigger_ids")) + "\n" +
                  json.dumps(c.gold.modification, ensure_ascii=False) + "\n```\n"]
        for m, r in sorted(by_case[cid].items()):
            lines += [f"### {m} -> {r.get('decision')} (pre-escalation: {r.get('pre_escalation_decision')})\n",
                      (r.get("explanation") or "").strip()[:1500] + "\n"]
            if r.get("review") and r["review"].get("escalation_reasons"):
                lines.append(f"_Escalated ({', '.join(r['review']['escalation_reasons'])}):_ "
                             f"corrections {r['review'].get('corrections')}\n")
    out = RESULTS / "case_studies"
    out.mkdir(parents=True, exist_ok=True)
    (out / f"{args.experiment}.md").write_text("\n".join(lines), encoding="utf-8")
    print(f"{len(ids)} cases -> {out / (args.experiment + '.md')}")


if __name__ == "__main__":
    main()
