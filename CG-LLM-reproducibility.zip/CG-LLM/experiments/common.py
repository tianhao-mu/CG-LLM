"""Shared helpers for experiment scripts."""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Iterable

import yaml

ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "results"
BENCH_DIR = ROOT / "data" / "benchmark" / "v1"


def load_env() -> None:
    try:
        from dotenv import load_dotenv
        load_dotenv(ROOT / ".env")
    except ImportError:
        pass


def setup_logging(level: str = "INFO") -> None:
    logging.basicConfig(level=getattr(logging, level), format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    for noisy in ("httpx", "openai", "jieba", "urllib3"):
        logging.getLogger(noisy).setLevel(logging.WARNING)


def load_config(path: str | Path) -> dict:
    cfg = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    base = cfg.pop("extends", None)
    if base:
        parent = load_config(Path(path).parent / base)
        parent.update(cfg)
        cfg = parent
    return cfg


def read_jsonl(path: str | Path) -> list[dict]:
    p = Path(path)
    if not p.exists():
        return []
    out = []
    with p.open(encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                try:
                    out.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
    return out


def write_jsonl(rows: Iterable[dict], path: str | Path) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open("w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False, default=str) + "\n")


def raw_dir(experiment: str) -> Path:
    return RESULTS / "raw" / experiment


def load_results(experiment: str) -> list[dict]:
    """All records of an experiment, keeping the latest record per run key."""
    rows = []
    for p in sorted(raw_dir(experiment).rglob("*.jsonl")):
        rows.extend(read_jsonl(p))
    latest = {}
    for r in rows:
        key = (r["case_id"], r["method"], r["model"], r["lang"], r["temperature"], r.get("thinking", False), r["repeat"])
        latest[key] = r
    return list(latest.values())
