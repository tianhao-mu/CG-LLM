"""
LLM-assisted constraint compilation.

For every entry of the hand-built constraint table, the LLM receives only the
cited article texts and a menu of check types, and must produce the check,
effect and parameters. Agreement with the hand-built table measures how far
the authoring step itself can be automated (with expert verification).

    python -m experiments.compile_constraints --models glm-4.7-flash qwen-flash --repeats 3
"""

from __future__ import annotations

import argparse
import json

import pandas as pd

from experiments.common import RESULTS, load_env, setup_logging, write_jsonl
from src.llm.providers import LLMClient
from src.pipelines.parsing import extract_json, normalize_articles
from src.policy.constraints import default_table
from src.rag.hybrid import HybridRetriever

CHECK_MENU = {
    "real_name": "aircraft real-name registration required",
    "operation_certificate": "operator must hold a UA operation certificate",
    "insurance": "liability insurance required",
    "pilot_license": "remote pilot licence required",
    "airworthiness": "airworthiness certificate required",
    "altitude": "altitude ceiling for routine operations (params: ceiling_m, micro_ceiling_m)",
    "filing": "deadline for submitting the flight application (params: routine_deadline_hour, emergency_lead_min)",
    "night_lighting": "lighting required at night (params: night_start_hour, night_end_hour)",
    "bvlos": "traffic awareness / collision avoidance required beyond visual line of sight",
    "prohibited_activity": "activities that are prohibited outright",
    "geofence_restricted": "no flight in controlled / prohibited / airport airspace without approval",
    "geofence_infrastructure": "protection areas around public infrastructure",
    "geofence_temporary": "temporarily added controlled airspace",
    "separation_severe": "volume intersection with other approved operations",
    "separation_minor": "insufficient separation from other operations",
    "survey_qualification": "surveying and mapping qualification required",
}

PROMPT = """[TASK:COMPILE] You turn regulation text into a machine-checkable rule for reviewing UAS flight applications.
Read the article(s) and choose the single best check type from this menu:
{menu}
Effects: REJECT (non-remediable) or MODIFY (approvable after a condition or change). For document requirements give
both the effect when the document is stated as not held and when it is not mentioned.
Respond with one JSON object:
{{"check": <menu key>, "effect": {{...}}, "params": {{...}}, "articles": ["<DOC>:<article>", ...], "rationale": string}}

Articles:
{articles}"""


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--models", nargs="*", default=["glm-4.7-flash"])
    ap.add_argument("--repeats", type=int, default=3)
    ap.add_argument("--temperature", type=float, default=0.3)
    args = ap.parse_args()
    load_env()
    setup_logging()
    table = default_table()
    retr = HybridRetriever(lang="en", mode="bm25")
    client = LLMClient()
    menu = "\n".join(f"- {k}: {v}" for k, v in CHECK_MENU.items())

    rows = []
    for c in table.constraints:
        arts = [retr.get(a) for a in c.articles]
        text = "\n\n".join(f"{a.header()}\n{a.text[:2500]}" for a in arts if a)
        for model in args.models:
            for k in range(args.repeats):
                r = client.chat(model, [{"role": "user", "content": PROMPT.format(menu=menu, articles=text)}],
                                temperature=args.temperature, json_mode=True, sample_idx=k)
                obj = extract_json(r.text) or {}
                effect = obj.get("effect") or {}
                eff_vals = sorted({str(v).upper() for v in effect.values()}) if isinstance(effect, dict) else []
                gold_vals = sorted({str(v).upper() for v in c.effect.values()})
                params = obj.get("params") if isinstance(obj.get("params"), dict) else {}
                param_hits = [k2 for k2, v in c.params.items() if str(params.get(k2)) == str(v)]
                rows.append({"constraint": c.id, "basis": c.basis, "model": model, "repeat": k,
                             "check_pred": obj.get("check"), "check_ok": obj.get("check") == c.check,
                             "effect_ok": eff_vals == gold_vals,
                             "param_recall": len(param_hits) / len(c.params) if c.params else None,
                             "article_overlap": len(set(normalize_articles(obj.get("articles"))) & set(c.articles)) / len(c.articles),
                             "raw": json.dumps(obj, ensure_ascii=False)[:1500], "error": r.error})
    out = RESULTS / "tables" / "compile"
    out.mkdir(parents=True, exist_ok=True)
    write_jsonl(rows, out / "compile_raw.jsonl")
    df = pd.DataFrame(rows)
    summ = df.groupby(["model", "basis"])[["check_ok", "effect_ok", "param_recall", "article_overlap"]].mean()
    summ.to_csv(out / "compile_summary.csv")
    df.groupby(["constraint", "model"])[["check_ok", "effect_ok"]].mean().to_csv(out / "compile_by_constraint.csv")
    print(summ.round(3).to_markdown())


if __name__ == "__main__":
    main()
