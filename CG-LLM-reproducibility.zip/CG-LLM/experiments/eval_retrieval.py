"""
Article-level retrieval evaluation (no LLM calls).

Gold relevance = articles mapped to the constraints the engine triggers on the
gold facts. Query types:
  request_text      the application text (standard RAG)
  constraint_name   triggered constraint names + engine details
  constraint_quote  + the source quote and exemption (what CG-LLM uses)

    python -m experiments.eval_retrieval [--modes bm25 dense hybrid] [--reranker BAAI/bge-reranker-v2-m3]
"""

from __future__ import annotations

import argparse
import math

import numpy as np
import pandas as pd

from experiments.common import BENCH_DIR, RESULTS, setup_logging
from src.benchmark.schema import load_cases
from src.policy.constraints import default_table
from src.rag.hybrid import HybridRetriever

KS = (1, 3, 5, 10)


def queries(case, lang: str) -> dict[str, str]:
    table = default_table()
    trig = case.gold.engine.get("triggers", [])
    names, quotes = [], []
    for t in trig:
        c = table.by_id(t["constraint_id"])
        names.append(f"{c.name}. {t['detail']}")
        quotes.append(f"{c.name}. {c.quote_en if lang == 'en' else c.quote_zh} {c.exemption}")
    return {"request_text": case.text(lang), "constraint_name": " ".join(names), "constraint_quote": " ".join(quotes)}


def score(ranked: list[str], gold: set[str]) -> dict:
    out = {f"recall@{k}": len(set(ranked[:k]) & gold) / len(gold) for k in KS}
    rr = next((1 / (i + 1) for i, a in enumerate(ranked) if a in gold), 0.0)
    dcg = sum(1 / math.log2(i + 2) for i, a in enumerate(ranked[:10]) if a in gold)
    idcg = sum(1 / math.log2(i + 2) for i in range(min(len(gold), 10)))
    out.update({"mrr": rr, "ndcg@10": dcg / idcg if idcg else 0.0})
    return out


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--modes", nargs="*", default=["bm25", "dense", "hybrid"])
    ap.add_argument("--langs", nargs="*", default=["en", "zh"])
    ap.add_argument("--reranker")
    ap.add_argument("--split", default="test")
    args = ap.parse_args()
    setup_logging()
    cases = [c for c in load_cases(BENCH_DIR / "cases.jsonl", split=args.split)
             if c.gold.decision in ("MODIFY", "REJECT") and c.gold.articles]

    rows = []
    for lang in args.langs:
        for mode in args.modes:
            for rerank in [None] + ([args.reranker] if args.reranker else []):
                retr = HybridRetriever(lang=lang, mode=mode, reranker_model=rerank)
                if retr.mode != mode:
                    print(f"skip {lang}/{mode}: dense model unavailable")
                    continue
                for c in cases:
                    gold = set(c.gold.articles)
                    for qtype, q in queries(c, lang).items():
                        ranked = [h.article_id for h in retr.retrieve(q, k=10)]
                        rows.append(dict(lang=lang, mode=retr.describe(), query=qtype, case_id=c.case_id,
                                         recipe=c.recipe, **score(ranked, gold)))
    df = pd.DataFrame(rows)
    out = RESULTS / "tables" / "retrieval"
    out.mkdir(parents=True, exist_ok=True)
    df.to_csv(out / "retrieval_per_case.csv", index=False)
    agg = df.groupby(["lang", "mode", "query"]).agg({c: "mean" for c in df.columns if "@" in c or c == "mrr"})
    agg["n"] = df.groupby(["lang", "mode", "query"]).size()
    agg.reset_index().to_csv(out / "retrieval.csv", index=False)
    print(agg.round(3).to_markdown())


if __name__ == "__main__":
    main()
