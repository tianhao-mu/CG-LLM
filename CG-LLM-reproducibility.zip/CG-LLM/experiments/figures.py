"""
Paper figures (PDF + PNG) in results/figures/.

    python -m experiments.figures                 # every figure whose inputs exist
    python -m experiments.figures --only main_bars risk_coverage

Inputs are the tables written by analyze.py, eval_retrieval.py and
bench_scalability.py, plus raw records for curve-type figures.
"""

from __future__ import annotations

import argparse
import json
import traceback
from collections import defaultdict

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch, Rectangle

from experiments.common import BENCH_DIR, RESULTS, load_results
from src.eval import metrics as M
from src.eval.calibration import risk_coverage
from src.eval.stats import cluster_bootstrap

FIG = RESULTS / "figures"
TABLES = RESULTS / "tables"

METHOD_LABELS = {
    "llm_direct": "LLM", "llm_rules": "LLM+Rules", "llm_rag": "LLM+RAG", "llm_rules_rag": "LLM+Rules+RAG",
    "react": "ReAct agent", "regex_engine": "Regex+Engine", "oracle_engine": "Oracle facts+Engine",
    "cgllm": "CG-LLM (ours)", "cgllm_no_review": "w/o review", "cgllm_no_rag_review": "w/o RAG in review",
    "cgllm_request_query": "request-text query", "cgllm_free_mod": "LLM modification", "cgllm_llm_sep": "LLM separation",
    "cgllm_sc": "self-consistency",
}
ORDER = list(METHOD_LABELS)
OURS = "#c0392b"
BASE = "#5d6d7e"


def style() -> None:
    plt.rcParams.update({"font.family": "serif", "font.serif": ["Times New Roman", "DejaVu Serif"], "font.size": 9,
                         "axes.spines.top": False, "axes.spines.right": False, "axes.grid": True, "grid.alpha": 0.3,
                         "savefig.bbox": "tight", "savefig.dpi": 300, "legend.frameon": False})


def save(fig, name: str) -> None:
    FIG.mkdir(parents=True, exist_ok=True)
    fig.savefig(FIG / f"{name}.pdf")
    fig.savefig(FIG / f"{name}.png")
    plt.close(fig)
    print(f"  wrote {name}")


def _summary(exp: str) -> pd.DataFrame:
    return pd.read_csv(TABLES / exp / "summary.csv")


def _order(methods) -> list[str]:
    return sorted(methods, key=lambda m: ORDER.index(m) if m in ORDER else 99)


# ------------------------------------------------------------------ framework
def fig_framework() -> None:
    fig, ax = plt.subplots(figsize=(7.2, 3.2))
    ax.set_xlim(0, 100), ax.set_ylim(0, 44), ax.axis("off")

    def box(x, y, w, h, text, fc):
        ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.4,rounding_size=1.2", fc=fc, ec="#34495e", lw=0.8))
        ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", fontsize=7.5, wrap=True)

    def arrow(x0, y0, x1, y1, txt=""):
        ax.add_patch(FancyArrowPatch((x0, y0), (x1, y1), arrowstyle="-|>", mutation_scale=9, lw=0.8, color="#34495e"))
        if txt:
            ax.text((x0 + x1) / 2, (y0 + y1) / 2 + 1.2, txt, ha="center", fontsize=6.5, color="#34495e")

    llm, det, data = "#fdebd0", "#d6eaf8", "#e8f8f5"
    box(1, 30, 14, 9, "Application\n(free text, zh/en)", data)
    box(1, 4, 14, 12, "Authority records\narea, submission time,\napproved ops, geofences", data)
    box(21, 30, 15, 9, "LLM fact\nextraction\n(JSON schema)", llm)
    box(42, 26, 18, 16, "Rule engine\ncredentials, altitude,\nfiling, operations\n+ geofence check\n+ 4D separation", det)
    box(42, 4, 18, 14, "Verified\nmodification search\n(time / altitude)", det)
    box(66, 28, 14, 12, "Constraint->article\nmap + guided\nhybrid retrieval", det)
    box(66, 4, 14, 14, "LLM review &\nexplanation\n(cites articles)", llm)
    box(86, 26, 13, 14, "Decision\nAPPROVE /\nMODIFY / REJECT", "#fadbd8")
    box(86, 4, 13, 14, "ESCALATE\nto human\n(disagreement,\nmissing facts)", "#f5eef8")
    box(21, 17, 15, 8, "Constraint table\n16 rules -> articles", "#fef9e7")
    arrow(15, 34.5, 21, 34.5)
    arrow(36, 34.5, 42, 34.5, "facts")
    arrow(15, 8, 42, 8, "")
    ax.text(28, 9.2, "geometry, time", ha="center", fontsize=6.5, color="#34495e")
    arrow(36, 22, 42, 29, "")
    arrow(51, 26, 51, 18)
    ax.text(52, 21.5, "geometric\nissue", fontsize=6.5, color="#34495e")
    arrow(60, 34, 66, 34, "triggers")
    arrow(60, 11, 66, 11, "verified plan")
    arrow(73, 28, 73, 18, "articles")
    arrow(80, 14, 86, 30, "agree")
    arrow(80, 9, 86, 9, "disagree")
    ax.text(2, 42.5, "CG-LLM: the LLM reads and explains; deterministic components decide and verify.", fontsize=8, style="italic")
    save(fig, "fig_framework")


# ------------------------------------------------------------------ results
def fig_main_bars(exp: str = "main") -> None:
    recs = [r for r in load_results(exp) if not r.get("perturbation")]
    by = defaultdict(list)
    for r in recs:
        by[r["method"]].append(r)
    methods = _order(by)
    fig, axes = plt.subplots(1, 3, figsize=(7.2, 2.6))
    for ax, (metric, title) in zip(axes, [(M.accuracy, "Accuracy (%)"), (M.unsafe_permissive_rate, "Unsafe-permissive rate (%)"),
                                          (M.mean_cost, "Cost-weighted error")]):
        vals = [cluster_bootstrap(by[m], metric, n_boot=1000) for m in methods]
        scale = 1 if metric is M.mean_cost else 100
        p = np.array([v[0] for v in vals]) * scale
        err = np.array([[v[0] - v[1], v[2] - v[0]] for v in vals]).T * scale
        colors = [OURS if m == "cgllm" else BASE for m in methods]
        ax.barh(range(len(methods)), p, xerr=err, color=colors, error_kw={"lw": 0.7, "capsize": 2})
        ax.set_yticks(range(len(methods)))
        ax.set_yticklabels([METHOD_LABELS.get(m, m) for m in methods] if ax is axes[0] else [])
        ax.invert_yaxis()
        ax.set_title(title, fontsize=9)
    save(fig, "fig_main_bars")


def fig_confusion(exp: str = "main", methods=("llm_rules_rag", "react", "cgllm")) -> None:
    conf = json.loads((TABLES / exp / "confusion.json").read_text())
    picked = [(k, v) for k, v in conf.items() if k.split("|")[0] in methods and k.endswith("|clean")]
    picked = sorted(picked, key=lambda kv: methods.index(kv[0].split("|")[0]))[: len(methods)]
    if not picked:
        return
    fig, axes = plt.subplots(1, len(picked), figsize=(2.4 * len(picked), 2.4))
    axes = np.atleast_1d(axes)
    rows, cols = ["APPROVE", "MODIFY", "REJECT", "ESCALATE"], ["APPROVE", "MODIFY", "REJECT", "ESCALATE", "INVALID"]
    for ax, (k, m) in zip(axes, picked):
        mat = np.array([[m[r][c] for c in cols] for r in rows], float)
        norm = mat / np.maximum(mat.sum(1, keepdims=True), 1)
        ax.imshow(norm, cmap="Blues", vmin=0, vmax=1)
        for i in range(len(rows)):
            for j in range(len(cols)):
                if mat[i, j]:
                    ax.text(j, i, f"{int(mat[i, j])}", ha="center", va="center", fontsize=6.5,
                            color="white" if norm[i, j] > 0.6 else "black")
        ax.set_xticks(range(len(cols)), ["A", "M", "R", "E", "X"])
        ax.set_yticks(range(len(rows)), ["A", "M", "R", "E"] if ax is axes[0] else [])
        ax.set_title(METHOD_LABELS.get(k.split("|")[0], k), fontsize=8)
        ax.grid(False)
        ax.set_xlabel("predicted")
    axes[0].set_ylabel("gold")
    save(fig, "fig_confusion")


def fig_recipe_heatmap(exp: str = "main") -> None:
    df = pd.read_csv(TABLES / exp / "by_recipe.csv")
    df = df[df["perturbation"] == "clean"]
    piv = df.groupby(["recipe", "method"])["accuracy"].mean().unstack("method")
    piv = piv[_order(piv.columns)]
    fig, ax = plt.subplots(figsize=(0.55 * piv.shape[1] + 2.5, 0.22 * piv.shape[0] + 1))
    im = ax.imshow(piv.values, cmap="RdYlGn", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(range(piv.shape[1]), [METHOD_LABELS.get(m, m) for m in piv.columns], rotation=40, ha="right")
    ax.set_yticks(range(piv.shape[0]), piv.index, fontsize=6.5)
    ax.grid(False)
    fig.colorbar(im, ax=ax, fraction=0.03, label="accuracy")
    save(fig, "fig_recipe_heatmap")


def fig_models(exp: str = "models_compare") -> None:
    df = _summary(exp)
    df = df[df["perturbation"] == "clean"]
    piv = df.pivot_table(index="model", columns="method", values="accuracy")
    piv = piv[_order(piv.columns)].sort_values(piv.columns[0])
    fig, ax = plt.subplots(figsize=(4.2, 0.35 * len(piv) + 1))
    y = np.arange(len(piv))
    for m in piv.columns:
        ax.plot(piv[m] * 100, y, "o", label=METHOD_LABELS.get(m, m), color=OURS if m == "cgllm" else None, ms=5)
    for i, (_, row) in enumerate(piv.iterrows()):
        ax.plot([row.min() * 100, row.max() * 100], [i, i], color="#bbb", lw=1, zorder=0)
    ax.set_yticks(y, piv.index)
    ax.set_xlabel("Accuracy (%)")
    ax.legend(loc="lower right", fontsize=7)
    save(fig, "fig_models")


def fig_ablation(exp: str = "ablation") -> None:
    df = _summary(exp)
    df = df[df["perturbation"] == "clean"].groupby("method")[["accuracy", "unsafe_permissive_rate", "coverage"]].mean()
    if "cgllm" not in df.index:
        return
    ref = df.loc["cgllm"]
    d = (df.drop("cgllm") - ref) * 100
    d = d.loc[_order(d.index)]
    fig, ax = plt.subplots(figsize=(4.8, 0.32 * len(d) + 1))
    y = np.arange(len(d))
    ax.barh(y - 0.2, d["accuracy"], 0.38, label="Delta accuracy (pp)", color="#2e86c1")
    ax.barh(y + 0.2, d["unsafe_permissive_rate"], 0.38, label="Delta unsafe-permissive (pp)", color=OURS)
    ax.axvline(0, color="k", lw=0.6)
    ax.set_yticks(y, [METHOD_LABELS.get(m, m) for m in d.index])
    ax.invert_yaxis()
    ax.legend(fontsize=7)
    save(fig, "fig_ablation")


def fig_robustness(exp: str = "robustness", clean_exp: str = "main") -> None:
    df = _summary(exp)
    try:
        clean = _summary(clean_exp)
        clean = clean[(clean["perturbation"] == "clean") & clean["method"].isin(df["method"].unique())]
        df = pd.concat([clean, df])
    except FileNotFoundError:
        pass
    piv = df.pivot_table(index="perturbation", columns="method", values="accuracy")
    piv = piv[_order(piv.columns)]
    order = ["clean"] + [p for p in piv.index if p != "clean"]
    piv = piv.reindex([p for p in order if p in piv.index])
    fig, ax = plt.subplots(figsize=(5.6, 2.6))
    w = 0.8 / piv.shape[1]
    for i, m in enumerate(piv.columns):
        ax.bar(np.arange(len(piv)) + i * w, piv[m] * 100, w, label=METHOD_LABELS.get(m, m),
               color=OURS if m == "cgllm" else None)
    ax.set_xticks(np.arange(len(piv)) + 0.4 - w / 2, piv.index, rotation=15)
    ax.set_ylabel("Accuracy (%)")
    ax.legend(fontsize=7, ncol=2)
    save(fig, "fig_robustness")


def fig_risk_coverage(exp: str = "main", methods=("llm_rules_rag", "react", "cgllm", "cgllm_sc")) -> None:
    recs = [r for r in load_results(exp) if not r.get("perturbation") and r["gold_decision"] in M.LABELS]
    fig, ax = plt.subplots(figsize=(3.4, 2.6))
    for m in methods:
        rs = [r for r in recs if r["method"] == m and r.get("confidence") is not None]
        if not rs:
            continue
        # escalated outputs are abstentions: confidence 0 so they are dropped first
        conf = [0.0 if M.pred_label(r) == "ESCALATE" else r["confidence"] for r in rs]
        rc = risk_coverage(conf, [M.is_correct(r) for r in rs])
        ax.plot(rc["coverage"], np.array(rc["risk"]) * 100, label=f"{METHOD_LABELS.get(m, m)} (AURC {rc['aurc']:.3f})",
                color=OURS if m == "cgllm" else None)
    ax.set_xlabel("Coverage")
    ax.set_ylabel("Risk = error rate (%)")
    ax.legend(fontsize=6.5)
    save(fig, "fig_risk_coverage")


def fig_retrieval() -> None:
    df = pd.read_csv(TABLES / "retrieval" / "retrieval.csv")
    fig, axes = plt.subplots(1, df["lang"].nunique(), figsize=(3.4 * df["lang"].nunique(), 2.6), squeeze=False)
    for ax, (lang, g) in zip(axes[0], df.groupby("lang")):
        for (mode, q), gg in g.groupby(["mode", "query"]):
            ks = [1, 3, 5, 10]
            ax.plot(ks, [gg[f"recall@{k}"].iloc[0] for k in ks], marker="o", ms=3,
                    ls="-" if q.startswith("constraint_quote") else ("--" if q == "constraint_name" else ":"),
                    label=f"{mode} / {q}")
        ax.set_title(f"Article retrieval ({lang})", fontsize=9)
        ax.set_xlabel("k")
        ax.set_ylabel("Recall@k")
        ax.set_xticks([1, 3, 5, 10])
    axes[0][-1].legend(fontsize=6, loc="lower right")
    save(fig, "fig_retrieval")


def fig_scalability() -> None:
    df = pd.read_csv(TABLES / "scalability" / "separation.csv")
    fig, ax = plt.subplots(figsize=(3.4, 2.6))
    for idx, g in df.groupby("index"):
        ax.loglog(g["n_ops"], g["mean_ms"], "o-", label="STRtree index" if idx else "brute force", ms=4)
    ax.set_xlabel("Approved operations in database")
    ax.set_ylabel("Separation check latency (ms)")
    ax.legend()
    save(fig, "fig_scalability")


def fig_temperature(exp: str = "temperature") -> None:
    df = _summary(exp)
    fig, axes = plt.subplots(1, 2, figsize=(6, 2.4))
    for m, g in df.groupby("method"):
        g = g.sort_values("temperature")
        kw = {"color": OURS} if m == "cgllm" else {}
        axes[0].plot(g["temperature"], g["accuracy"] * 100, "o-", label=METHOD_LABELS.get(m, m), **kw)
        axes[1].plot(g["temperature"], g["consistency"] * 100, "o-", **kw)
    axes[0].set_ylabel("Accuracy (%)"), axes[1].set_ylabel("Decision consistency (%)")
    for ax in axes:
        ax.set_xlabel("Temperature")
    axes[0].legend(fontsize=7)
    save(fig, "fig_temperature")


def fig_cost_accuracy(exp: str = "main") -> None:
    df = _summary(exp)
    df = df[df["perturbation"] == "clean"]
    df = df[df["mean_prompt_tokens"] > 0]
    fig, ax = plt.subplots(figsize=(3.6, 2.6))
    for _, r in df.iterrows():
        tok = r["mean_prompt_tokens"] + r["mean_completion_tokens"]
        ax.scatter(tok, r["accuracy"] * 100, color=OURS if r["method"] == "cgllm" else BASE, s=18)
        ax.annotate(METHOD_LABELS.get(r["method"], r["method"]), (tok, r["accuracy"] * 100), fontsize=6,
                    xytext=(3, 2), textcoords="offset points")
    ax.set_xscale("log")
    ax.set_xlabel("Tokens per request")
    ax.set_ylabel("Accuracy (%)")
    save(fig, "fig_cost_accuracy")


def fig_extraction_fields(exp: str = "main") -> None:
    df = pd.read_csv(TABLES / exp / "extraction_fields.csv")
    df = df[(df["perturbation"] == "clean") & (df["model"] != "none")]
    if df.empty:
        return
    df["label"] = df["method"].map(lambda m: METHOD_LABELS.get(m, m)) + " / " + df["model"]
    fields = [c for c in M.FACT_FIELDS if c in df.columns]
    mat = df.set_index("label")[fields]
    fig, ax = plt.subplots(figsize=(7.2, 0.3 * len(mat) + 1.2))
    im = ax.imshow(mat.values, cmap="RdYlGn", vmin=0.5, vmax=1, aspect="auto")
    ax.set_xticks(range(len(fields)), fields, rotation=55, ha="right", fontsize=6.5)
    ax.set_yticks(range(len(mat)), mat.index, fontsize=7)
    ax.grid(False)
    fig.colorbar(im, ax=ax, fraction=0.025, label="field accuracy")
    save(fig, "fig_extraction_fields")


def fig_case_map(case_id: str | None = None) -> None:
    """Plan view of one case: request, approved ops, zones and the verified modification's time shift."""
    from src.benchmark.schema import load_cases
    from src.geo.projection import polygon_lonlat_to_metric
    from src.airspace.geofence import load_zones
    from src.policy.engine import DEFAULT_GEOFENCE
    cases = load_cases(BENCH_DIR / "cases.jsonl", split="test")
    if case_id:
        c = next(x for x in cases if x.case_id == case_id)
    else:
        c = next(x for x in cases if x.recipe == "MULTI_MODIFY" and x.gold.modification and x.context.approved_ops)
    area = polygon_lonlat_to_metric(c.context.area_coordinates)
    ox, oy = area.centroid.x, area.centroid.y
    fig, (ax, ax2) = plt.subplots(1, 2, figsize=(7.2, 3), gridspec_kw={"width_ratios": [1.2, 1]})

    def draw(poly, **kw):
        x0, y0, x1, y1 = poly.bounds
        ax.add_patch(Rectangle((x0 - ox, y0 - oy), x1 - x0, y1 - y0, **kw))

    for z in load_zones(DEFAULT_GEOFENCE):
        if z.polygon.distance(area) < 3000:
            draw(z.polygon, fc="#f5b7b1", ec="#c0392b", alpha=0.4, label=z.name)
    for op in c.context.approved_ops:
        draw(polygon_lonlat_to_metric(op.coordinates), fc="#aed6f1", ec="#2471a3", alpha=0.6)
    draw(area, fc="none", ec=OURS, lw=1.5)
    ax.set_xlim(-2000, 2000), ax.set_ylim(-1600, 1600), ax.set_aspect("equal")
    ax.set_xlabel("East (m)"), ax.set_ylabel("North (m)")
    ax.set_title("Plan view (request in red, approved ops in blue)", fontsize=8)

    f = c.gold.facts
    from datetime import datetime
    t = lambda s: datetime.fromisoformat(s)
    base = t(f["time_start"]).replace(hour=0, minute=0)
    hrs = lambda s: (t(s) - base).total_seconds() / 3600
    for op in c.context.approved_ops:
        ax2.add_patch(Rectangle((hrs(op.time_start.isoformat()), op.altitude_min_m),
                                hrs(op.time_end.isoformat()) - hrs(op.time_start.isoformat()),
                                op.altitude_max_m - op.altitude_min_m, fc="#aed6f1", ec="#2471a3", alpha=0.6))
    ax2.add_patch(Rectangle((hrs(f["time_start"]), f["altitude_min_m"] or 0), hrs(f["time_end"]) - hrs(f["time_start"]),
                            f["altitude_max_m"] - (f["altitude_min_m"] or 0), fc="none", ec=OURS, lw=1.2, ls="--"))
    m = c.gold.modification
    ax2.add_patch(Rectangle((hrs(m["time_start"]), m["altitude_min_m"]), hrs(m["time_end"]) - hrs(m["time_start"]),
                            m["altitude_max_m"] - m["altitude_min_m"], fc=OURS, alpha=0.25, ec=OURS))
    ax2.axhline(120, color="k", lw=0.6, ls=":")
    ax2.autoscale_view()
    ax2.text(0.01, 120, " 120 m ceiling", fontsize=6, va="bottom", transform=ax2.get_yaxis_transform())
    ax2.set_xlabel("Time of day (h)"), ax2.set_ylabel("Altitude (m)")
    ax2.set_title(f"Time-altitude view: requested (dashed) vs verified modification\n{m['summary']}", fontsize=7)
    save(fig, "fig_case_map")


FIGURES = {"framework": fig_framework, "main_bars": fig_main_bars, "confusion": fig_confusion,
           "recipe_heatmap": fig_recipe_heatmap, "models": fig_models, "ablation": fig_ablation,
           "robustness": fig_robustness, "risk_coverage": fig_risk_coverage, "retrieval": fig_retrieval,
           "scalability": fig_scalability, "temperature": fig_temperature, "cost_accuracy": fig_cost_accuracy,
           "extraction_fields": fig_extraction_fields, "case_map": fig_case_map}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", nargs="*")
    ap.add_argument("--main-exp", default="main", help="experiment used for main-result figures (e.g. smoke)")
    args = ap.parse_args()
    style()
    for name, fn in FIGURES.items():
        if args.only and name not in args.only:
            continue
        try:
            if name in ("main_bars", "confusion", "recipe_heatmap", "risk_coverage", "cost_accuracy", "extraction_fields"):
                fn(args.main_exp)
            else:
                fn()
        except FileNotFoundError as e:
            print(f"  skip {name}: missing input ({e.filename})")
        except Exception:  # noqa: BLE001
            print(f"  failed {name}:\n{traceback.format_exc()}")


if __name__ == "__main__":
    main()
