"""
Blind re-labeling of a stratified sample, without the rule engine.

Two readers see the same application and authority records and never see the
gold label:

  rule_sheet  the written constraint table (effects and parameters)
  statute     the cited article texts only, no effect codes and no local
              separation minima

Agreement with the engine labels, and agreement between the two readers, is
the independence check. This is not a human study.

    python -m experiments.independent_label --n 120
"""

from __future__ import annotations

import argparse
import json
import random
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor

import pandas as pd
from tqdm import tqdm

from experiments.common import BENCH_DIR, RESULTS, load_env, setup_logging, write_jsonl
from src.benchmark.schema import load_cases
from src.eval.stats import cohen_kappa
from src.llm.providers import LLMClient
from src.pipelines.parsing import extract_json, normalize_decision
from src.pipelines.prompts import render_context
from src.policy.constraints import default_table
from src.rag.hybrid import HybridRetriever

OUT = RESULTS / "tables" / "independence"

DECISIONS = (
    "APPROVE = approve as submitted. MODIFY = approvable once a missing document is supplied or the time window "
    "or altitude band is changed. REJECT = not approvable. ESCALATE = altitude, time window or aircraft weight is "
    "missing. If any ground for REJECT is present, answer REJECT. Otherwise if any ground for MODIFY is present, "
    "answer MODIFY. Otherwise APPROVE."
)


def sample_cases(n: int, seed: int):
    cases = load_cases(BENCH_DIR / "cases.jsonl", split="test")
    rng = random.Random(seed)
    by = defaultdict(list)
    for c in cases:
        by[c.recipe].append(c)
    per = max(1, n // len(by))
    picked = [c for v in by.values() for c in rng.sample(v, min(per, len(v)))]
    rng.shuffle(picked)
    return picked[:n]


def statute_text() -> str:
    table = default_table()
    retr = HybridRetriever(lang="en", mode="bm25")
    ids = []
    for c in table.constraints:
        ids.extend(c.articles)
    blocks = []
    for i in dict.fromkeys(ids):
        art = retr.get(i)
        if art:
            blocks.append(f"{art.header()}\n{art.text[:1800]}")
    return "\n\n".join(blocks)


def messages(case, source: str, rules: str) -> list[dict]:
    sys = (
        "[TASK:DECIDE] You are an independent reviewer labeling one UAS flight application. "
        "Decide only from the application, the authority records, and the material below. "
        f"{DECISIONS} Respond with one JSON object: "
        '{"decision": "APPROVE"|"MODIFY"|"REJECT"|"ESCALATE", "rationale": string}\n\n' + rules
    )
    user = f"Application:\n{case.text('en')}\n\nAuthority records:\n{render_context(case)}"
    return [{"role": "system", "content": sys}, {"role": "user", "content": user}]


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=120)
    ap.add_argument("--seed", type=int, default=11)
    ap.add_argument("--model", default="glm-5.3-flash")
    ap.add_argument("--workers", type=int, default=3)
    args = ap.parse_args()
    load_env()
    setup_logging()
    cases = sample_cases(args.n, args.seed)
    table = default_table()
    sources = {
        "rule_sheet": "Written rules:\n" + table.rules_text("en"),
        "statute": "Regulation articles. Apply only what these articles say; do not invent numeric separation minima.\n\n"
                   + statute_text(),
    }
    client = LLMClient()
    done = {}
    prev = OUT / "labels.jsonl"
    if prev.exists():
        for line in prev.read_text().splitlines():
            if line.strip():
                r = json.loads(line)
                if r.get("decision"):
                    done[(r["case_id"], r["source"])] = r
    jobs = [(c, src) for c in cases for src in sources if (c.case_id, src) not in done]
    print(f"resume: {len(done)} kept, {len(jobs)} to run")

    def one(job):
        case, src = job
        r = client.chat(args.model, messages(case, src, sources[src]), temperature=0.0, json_mode=True, max_tokens=2000)
        obj = extract_json(r.text) or {}
        return {"case_id": case.case_id, "recipe": case.recipe, "gold": case.gold.decision, "source": src,
                "decision": normalize_decision(obj.get("decision")), "rationale": str(obj.get("rationale", ""))[:500],
                "error": r.error}

    with ThreadPoolExecutor(args.workers) as pool:
        fresh = list(tqdm(pool.map(one, jobs), total=len(jobs), desc="label")) if jobs else []
    rows = list(done.values()) + fresh
    OUT.mkdir(parents=True, exist_ok=True)
    write_jsonl(rows, OUT / "labels.jsonl")

    summary = []
    by = defaultdict(dict)
    for r in rows:
        by[r["case_id"]][r["source"]] = r["decision"]
        by[r["case_id"]]["gold"] = r["gold"]
        by[r["case_id"]]["recipe"] = r["recipe"]
    ids = [c.case_id for c in cases]
    gold = [by[i]["gold"] for i in ids]
    for src in sources:
        pred = [by[i].get(src) for i in ids]
        valid = [(g, p) for g, p in zip(gold, pred) if p in ("APPROVE", "MODIFY", "REJECT", "ESCALATE")]
        summary.append({"pair": f"{src} vs gold", "n": len(valid),
                        "agreement": sum(g == p for g, p in valid) / len(valid),
                        "kappa": cohen_kappa([g for g, _ in valid], [p for _, p in valid])})
    a = [by[i].get("rule_sheet") for i in ids]
    b = [by[i].get("statute") for i in ids]
    both = [(x, y) for x, y in zip(a, b) if x in ("APPROVE", "MODIFY", "REJECT", "ESCALATE")
            and y in ("APPROVE", "MODIFY", "REJECT", "ESCALATE")]
    summary.append({"pair": "rule_sheet vs statute", "n": len(both),
                    "agreement": sum(x == y for x, y in both) / len(both),
                    "kappa": cohen_kappa([x for x, _ in both], [y for _, y in both])})
    pd.DataFrame(summary).to_csv(OUT / "agreement.csv", index=False)

    disagree = []
    for i in ids:
        if by[i].get("rule_sheet") != by[i]["gold"] or by[i].get("statute") != by[i]["gold"]:
            disagree.append({"case_id": i, "recipe": by[i]["recipe"], "gold": by[i]["gold"],
                             "rule_sheet": by[i].get("rule_sheet"), "statute": by[i].get("statute")})
    pd.DataFrame(disagree).to_csv(OUT / "disagreements.csv", index=False)
    print(pd.DataFrame(summary).round(3).to_markdown(index=False))
    print("disagreements", len(disagree), "of", len(ids))
    print("by recipe", Counter(d["recipe"] for d in disagree).most_common(8))
    print(json.dumps(client.usage_summary(), indent=1))


if __name__ == "__main__":
    main()
