"""
LLM-as-judge scoring of explanations.

The judge sees the application, the *gold* engine report and the texts of the
articles the method cited. Use a judge model different from the evaluated
model to limit self-preference.

    python -m experiments.judge_explanations main --judge qwen-flash --methods llm_rules_rag react cgllm --stride 3
"""

from __future__ import annotations

import argparse
import json
from concurrent.futures import ThreadPoolExecutor

import numpy as np
import pandas as pd
from tqdm import tqdm

from experiments.analyze import load_all_cases
from experiments.common import RESULTS, load_env, load_results, setup_logging, write_jsonl
from src.llm.providers import LLMClient
from src.pipelines.parsing import extract_json
from src.pipelines.prompts import judge_messages
from src.rag.hybrid import HybridRetriever

SCORES = ("faithfulness", "citation_support", "actionability", "clarity")


def engine_text(engine: dict) -> str:
    lines = [f"Engine decision: {engine.get('decision')}"]
    for t in engine.get("triggers", []):
        lines.append(f"- {t['constraint_id']} [{t['kind']} -> {t['effect']}] {t['detail']}")
    m = engine.get("modification")
    if m:
        lines.append(f"Verified modification: {m.get('summary')} ({m.get('time_start')} to {m.get('time_end')}, "
                     f"{m.get('altitude_min_m')}-{m.get('altitude_max_m')} m)")
    if engine.get("conditions"):
        lines.append("Conditions: " + "; ".join(engine["conditions"]))
    return "\n".join(lines)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("experiment")
    ap.add_argument("--judge", default="qwen-flash")
    ap.add_argument("--methods", nargs="*", default=["llm_rules_rag", "react", "cgllm"])
    ap.add_argument("--model")
    ap.add_argument("--stride", type=int, default=3)
    ap.add_argument("--workers", type=int, default=4)
    args = ap.parse_args()
    load_env()
    setup_logging()

    cases = load_all_cases()
    recs = [r for r in load_results(args.experiment) if r["method"] in args.methods and r["repeat"] == 0
            and r.get("explanation") and r["gold_decision"] != "ESCALATE" and not r.get("perturbation")
            and (args.model is None or r["model"] == args.model)]
    keep = sorted({r["case_id"] for r in recs})[:: args.stride]
    recs = [r for r in recs if r["case_id"] in set(keep)]
    retr = HybridRetriever(lang="en", mode="bm25")
    client = LLMClient()

    def one(r):
        c = cases[r["case_id"]]
        arts = [retr.get(a) for a in (r.get("cited_articles") or [])]
        art_text = "\n\n".join(f"{a.header()}\n{a.text[:900]}" for a in arts if a) or "(no valid citations)"
        resp = client.chat(args.judge, judge_messages(c, engine_text(c.gold.engine), r["explanation"], art_text),
                           temperature=0.0, json_mode=True)
        obj = extract_json(resp.text) or {}
        row = {"case_id": r["case_id"], "method": r["method"], "model": r["model"], "judge": args.judge,
               "correct": r.get("decision") == r["gold_decision"], "error": resp.error,
               "unsupported_claims": obj.get("unsupported_claims", [])}
        for s in SCORES:
            try:
                row[s] = float(obj.get(s))
            except (TypeError, ValueError):
                row[s] = np.nan
        return row

    with ThreadPoolExecutor(args.workers) as pool:
        rows = list(tqdm(pool.map(one, recs), total=len(recs), desc="judge"))
    out = RESULTS / "tables" / "judge"
    out.mkdir(parents=True, exist_ok=True)
    write_jsonl(rows, out / f"{args.experiment}__{args.judge}.jsonl")
    df = pd.DataFrame(rows)
    df["n_unsupported"] = df["unsupported_claims"].apply(lambda v: len(v) if isinstance(v, list) else np.nan)
    agg = df.groupby(["method", "model"])[list(SCORES) + ["n_unsupported"]].agg(["mean", "std"])
    agg.to_csv(out / f"{args.experiment}__{args.judge}_summary.csv")
    print(agg.round(2).to_markdown())
    print(json.dumps(client.usage_summary(), indent=1))


if __name__ == "__main__":
    main()
