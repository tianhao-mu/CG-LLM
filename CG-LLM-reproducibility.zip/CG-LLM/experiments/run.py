"""
Run decision pipelines over the benchmark.

    python -m experiments.run experiments/configs/main.yaml
    python -m experiments.run experiments/configs/smoke.yaml --limit 20

Output: results/raw/<experiment>/<model>/<method>__<lang>__T<temp>[__think].jsonl
Runs are resumable: (case, repeat) pairs already written without error are
skipped. All LLM calls are cached, so re-running never re-bills.
"""

from __future__ import annotations

import argparse
import json
import logging
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

from tqdm import tqdm

from experiments.common import BENCH_DIR, ROOT, load_config, load_env, raw_dir, read_jsonl, setup_logging
from src.benchmark.schema import load_cases
from src.llm.providers import LLMClient, load_registry
from src.pipelines.base import RunContext
from src.pipelines.registry import METHODS, NEEDS_RETRIEVER
from src.policy.engine import RuleEngine
from src.rag.hybrid import HybridRetriever

log = logging.getLogger("run")


def build_retrievers(cfg: dict, langs: list[str]) -> dict[str, HybridRetriever]:
    rcfg = cfg.get("retriever", {})
    return {lang: HybridRetriever(lang=lang, mode=rcfg.get("mode", "hybrid"), reranker_model=rcfg.get("reranker"),
                                  max_per_doc=rcfg.get("max_per_doc"), dense_model=rcfg.get("dense_model", "BAAI/bge-m3"))
            for lang in langs}


def load_benchmark(cfg: dict, limit: int | None) -> list:
    files = cfg.get("benchmark", str(BENCH_DIR / "cases.jsonl"))
    files = files if isinstance(files, list) else [files]
    cases = []
    for f in files:
        p = Path(f)
        p = p if p.is_absolute() else ROOT / p
        if not p.exists():
            log.warning("benchmark file %s not found; skipped", p)
            continue
        cases += load_cases(p, split=cfg.get("split"), recipes=cfg.get("recipes"))
    if cfg.get("perturbations"):
        cases = [c for c in cases if c.perturbation in set(cfg["perturbations"])]
    stride = cfg.get("subsample_stride")
    if stride:
        cases = cases[::int(stride)]
    lim = limit or cfg.get("limit")
    return cases[:lim] if lim else cases


def out_path(exp: str, model: str, method: str, lang: str, temp: float, thinking: bool) -> Path:
    name = f"{method}__{lang}__T{temp:g}" + ("__think" if thinking else "") + ".jsonl"
    return raw_dir(exp) / model / name


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("config")
    ap.add_argument("--limit", type=int)
    ap.add_argument("--methods", nargs="*")
    ap.add_argument("--models", nargs="*")
    ap.add_argument("--workers", type=int)
    ap.add_argument("--no-cache", action="store_true")
    ap.add_argument("--dry-run", action="store_true", help="print the run plan and exit")
    args = ap.parse_args()

    load_env()
    setup_logging()
    cfg = load_config(args.config)
    exp = cfg["name"]
    cases = load_benchmark(cfg, args.limit)
    langs = cfg.get("langs", ["en"])
    methods = args.methods or cfg["methods"]
    models = args.models or cfg.get("models", ["mock"])
    temps = cfg.get("temperatures", [0.0])
    repeats = int(cfg.get("repeats", 1))
    thinking_opts = cfg.get("thinking", [False])
    thinking_opts = thinking_opts if isinstance(thinking_opts, list) else [thinking_opts]
    workers = args.workers or int(cfg.get("workers", 4))
    unknown = [m for m in methods if m not in METHODS]
    if unknown:
        raise SystemExit(f"unknown methods: {unknown}; available: {sorted(METHODS)}")

    registry = load_registry()
    client = LLMClient(registry, use_cache=not args.no_cache)
    engine = RuleEngine()
    retrievers = build_retrievers(cfg, langs) if any(m in NEEDS_RETRIEVER for m in methods) else {}

    jobs = []
    for method in methods:
        cls = METHODS[method]
        for model in (models if cls.uses_llm else ["none"]):
            for lang in langs:
                for temp in (temps if cls.uses_llm else [0.0]):
                    for think in (thinking_opts if cls.uses_llm else [False]):
                        reps = int(cfg.get("method_repeats", {}).get(method, repeats)) if cls.uses_llm else 1
                        jobs.append((method, model, lang, float(temp), bool(think), reps))
    total = sum(len(cases) * j[5] for j in jobs)
    print(f"experiment={exp} cases={len(cases)} configurations={len(jobs)} runs={total}")
    for j in jobs:
        print("  ", j)
    if args.dry_run:
        return

    t_start = time.time()
    for method, model, lang, temp, think, reps in jobs:
        path = out_path(exp, model, method, lang, temp, think)
        done = {(r["case_id"], r["repeat"]) for r in read_jsonl(path) if not r.get("error")}
        todo = [(c, k) for k in range(reps) for c in cases if (c.case_id, k) not in done]
        if not todo:
            print(f"[skip] {path.relative_to(ROOT)} complete")
            continue
        rc = RunContext(client=client if METHODS[method].uses_llm else None, model=model, temperature=temp, lang=lang,
                        thinking=think, engine=engine, retriever=retrievers.get(lang),
                        top_k=int(cfg.get("retriever", {}).get("top_k", 5)))
        path.parent.mkdir(parents=True, exist_ok=True)
        lock = threading.Lock()
        local = threading.local()

        def work(item):
            case, k = item
            if not hasattr(local, "pipe"):
                local.pipe = METHODS[method](rc, **cfg.get("method_options", {}).get(method, {}))
            return local.pipe.run(case, repeat=k)

        n_err = 0
        budget_hit = False
        with path.open("a", encoding="utf-8") as fout, ThreadPoolExecutor(max_workers=workers) as pool:
            futures = [pool.submit(work, it) for it in todo]
            for fut in tqdm(as_completed(futures), total=len(futures), desc=f"{method}/{model}/{lang}/T{temp:g}"):
                rec = fut.result()
                if str(rec.get("error", "")).startswith("BudgetExhausted"):
                    budget_hit = True
                    break
                n_err += bool(rec.get("error"))
                with lock:
                    fout.write(json.dumps(rec, ensure_ascii=False, default=str) + "\n")
                    fout.flush()
        if budget_hit:
            log.error("token budget reached; stopping before any further billed calls")
            break
        if n_err:
            log.warning("%s: %d/%d records with errors (re-run to retry)", path.name, n_err, len(todo))

    usage = client.usage_summary()
    usage_path = raw_dir(exp) / "usage.json"
    prev = json.loads(usage_path.read_text()) if usage_path.exists() else []
    prev.append({"time": time.strftime("%Y-%m-%d %H:%M:%S"), "elapsed_s": round(time.time() - t_start, 1),
                 "usage": usage})
    usage_path.write_text(json.dumps(prev, indent=2))
    print(json.dumps(usage, indent=2))


if __name__ == "__main__":
    main()
