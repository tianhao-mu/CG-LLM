"""
Blinded expert evaluation of explanations.

    python -m experiments.user_study export main --methods llm_rules_rag react cgllm --n 30 --raters R1 R2 R3
    # raters score each system output 1-5 on the listed criteria
    python -m experiments.user_study score

Systems are shown as anonymous labels in a per-case random order; the key is
stored separately in results/user_study/key.csv.
"""

from __future__ import annotations

import argparse
import itertools
import random

import pandas as pd
from scipy import stats

from experiments.analyze import load_all_cases
from experiments.common import RESULTS, load_results
from src.eval.stats import holm
from src.pipelines.prompts import render_context

DIR = RESULTS / "user_study"
CRITERIA = ["decision_correct_1to5", "faithful_to_records", "regulatory_grounding", "actionability", "trust"]


def export(exp: str, methods: list[str], n: int, raters: list[str], model: str | None, seed: int) -> None:
    cases = load_all_cases()
    recs = [r for r in load_results(exp) if r["method"] in methods and r["repeat"] == 0 and not r.get("perturbation")
            and (model is None or r["model"] == model) and r["gold_decision"] != "ESCALATE"]
    by_case = {}
    for r in recs:
        by_case.setdefault(r["case_id"], {})[r["method"]] = r
    full = [c for c, d in by_case.items() if len(d) == len(methods)]
    rng = random.Random(seed)
    chosen = rng.sample(full, min(n, len(full)))
    rows, key = [], []
    for i, cid in enumerate(chosen):
        order = methods[:]
        rng.shuffle(order)
        for j, m in enumerate(order):
            label = "ABCDEFG"[j]
            r = by_case[cid][m]
            rows.append({"item": i + 1, "case_id": cid, "system": label, "application": cases[cid].text("en"),
                         "authority_records": render_context(cases[cid]), "system_decision": r.get("decision"),
                         "system_explanation": r.get("explanation", ""), **{c: "" for c in CRITERIA}, "comment": ""})
            key.append({"case_id": cid, "system": label, "method": m})
    DIR.mkdir(parents=True, exist_ok=True)
    for rater in raters:
        pd.DataFrame(rows).to_excel(DIR / f"rater_{rater}.xlsx", index=False)
    pd.DataFrame(key).to_csv(DIR / "key.csv", index=False)
    print(f"exported {len(chosen)} cases x {len(methods)} systems for {raters} -> {DIR}")


def score() -> None:
    key = pd.read_csv(DIR / "key.csv")
    frames = []
    for p in sorted(DIR.glob("rater_*.xlsx")):
        df = pd.read_excel(p)
        df["rater"] = p.stem.split("_", 1)[1]
        frames.append(df)
    df = pd.concat(frames).merge(key, on=["case_id", "system"])
    for c in CRITERIA:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    summary = df.groupby("method")[CRITERIA].agg(["mean", "std", "count"])
    summary.to_csv(DIR / "summary.csv")
    print(summary.round(2).to_markdown())
    tests = []
    for c in CRITERIA:
        wide = df.groupby(["case_id", "rater", "method"])[c].mean().unstack("method").dropna()
        if wide.shape[0] < 3 or wide.shape[1] < 2:
            continue
        if wide.shape[1] >= 3:
            fr = stats.friedmanchisquare(*[wide[m] for m in wide.columns])
            tests.append({"criterion": c, "test": "friedman", "pair": "all", "stat": fr.statistic, "p": fr.pvalue})
        pvals = {}
        for a, b in itertools.combinations(wide.columns, 2):
            w = stats.wilcoxon(wide[a], wide[b], zero_method="zsplit")
            pvals[f"{a} vs {b}"] = w.pvalue
            tests.append({"criterion": c, "test": "wilcoxon", "pair": f"{a} vs {b}", "stat": w.statistic, "p": w.pvalue})
        adj = holm(pvals)
        for t in tests:
            if t["criterion"] == c and t["pair"] in adj:
                t["p_holm"] = adj[t["pair"]]
    pd.DataFrame(tests).to_csv(DIR / "tests.csv", index=False)
    print(pd.DataFrame(tests).round(4).to_markdown(index=False))


def main() -> None:
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    e = sub.add_parser("export")
    e.add_argument("experiment")
    e.add_argument("--methods", nargs="+", default=["llm_rules_rag", "react", "cgllm"])
    e.add_argument("--n", type=int, default=30)
    e.add_argument("--raters", nargs="+", default=["R1", "R2", "R3"])
    e.add_argument("--model")
    e.add_argument("--seed", type=int, default=11)
    sub.add_parser("score")
    args = ap.parse_args()
    if args.cmd == "export":
        export(args.experiment, args.methods, args.n, args.raters, args.model, args.seed)
    else:
        score()


if __name__ == "__main__":
    main()
