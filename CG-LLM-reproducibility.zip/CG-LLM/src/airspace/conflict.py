"""
3D spatio-temporal conflict detection engine.

Detects conflicts between a proposed airspace operation and existing
approved operations. Uses Shapely for 2D polygon intersection +
altitude band overlap + time window overlap.
"""

import logging
from datetime import datetime
from typing import List

from shapely import wkt
from shapely.geometry import Polygon

from src.models.decision import ConflictDetail, ConflictResult
from src.models.operation import ApprovedOperation

logger = logging.getLogger(__name__)


def _parse_polygon(area_wkt: str) -> Polygon:
    """Parse a WKT string into a Shapely Polygon."""
    geom = wkt.loads(area_wkt)
    if not isinstance(geom, Polygon):
        raise ValueError(f"Expected Polygon, got {type(geom)}")
    return geom


def _check_spatial_overlap(
    request_poly: Polygon,
    op_poly: Polygon,
) -> tuple[float, float]:
    """Compute spatial (2D) overlap between two polygons.

    Returns:
        (overlap_area_m2, overlap_percent) —
        overlap_percent is the overlap area as a percentage of
        the *request* polygon area.
    """
    if not request_poly.intersects(op_poly):
        return 0.0, 0.0

    intersection = request_poly.intersection(op_poly)
    overlap_area = intersection.area
    overlap_percent = (overlap_area / request_poly.area * 100) if request_poly.area > 0 else 0.0

    return overlap_area, overlap_percent


def _check_altitude_overlap(
    req_min: float, req_max: float, op_min: float, op_max: float
) -> tuple[bool, float, float]:
    """Check altitude band overlap between request and existing operation.

    Returns:
        (has_overlap, overlap_min, overlap_max)
    """
    overlap_min = max(req_min, op_min)
    overlap_max = min(req_max, op_max)

    if overlap_min < overlap_max:
        return True, overlap_min, overlap_max
    return False, 0.0, 0.0


def _check_temporal_overlap(
    req_start: datetime, req_end: datetime,
    op_start: datetime, op_end: datetime,
) -> float:
    """Check temporal overlap between request and existing operation.

    Returns:
        overlap_minutes — duration of overlap in minutes; 0 if no overlap.
    """
    overlap_start = max(req_start, op_start)
    overlap_end = min(req_end, op_end)

    if overlap_start < overlap_end:
        return (overlap_end - overlap_start).total_seconds() / 60.0
    return 0.0


def _classify_severity(
    spatial_overlap_pct: float,
    has_alt_overlap: bool,
    temporal_overlap_min: float,
) -> str:
    """Classify conflict severity based on the three overlap dimensions.

    CRITICAL:  Full 3D overlap AND spatial overlap > 50%.
    HIGH:      Full 3D overlap.
    MEDIUM:    Two-dimensional overlap (spatial + temporal,
               spatial + altitude, or altitude + temporal).
    LOW:       Single-dimension or marginal overlap.
    """
    overlap_dims = sum([
        spatial_overlap_pct > 0,
        has_alt_overlap,
        temporal_overlap_min > 0,
    ])

    if overlap_dims == 3 and spatial_overlap_pct > 50:
        return "CRITICAL"
    elif overlap_dims == 3:
        return "HIGH"
    elif overlap_dims == 2:
        return "MEDIUM"
    else:
        return "LOW"


def detect_conflicts(
    request_area_wkt: str,
    request_alt_min: float,
    request_alt_max: float,
    request_time_start: datetime,
    request_time_end: datetime,
    existing_operations: List[ApprovedOperation],
    buffer_m: float = 50.0,
) -> ConflictResult:
    """Detect spatio-temporal conflicts between a request and existing operations.

    Args:
        request_area_wkt: WKT Polygon of the requested area.
        request_alt_min: Minimum altitude of the request (m).
        request_alt_max: Maximum altitude of the request (m).
        request_time_start: Start time of the request.
        request_time_end: End time of the request.
        existing_operations: List of already-approved operations.
        buffer_m: Spatial buffer in metres — a safety margin is added
                  around the requested area.

    Returns:
        ConflictResult with all detected conflicts sorted by severity.
    """
    try:
        request_poly = _parse_polygon(request_area_wkt)
    except Exception as e:
        logger.error(f"Failed to parse request polygon: {e}")
        return ConflictResult(
            has_conflict=False,
            conflict_count=0,
            conflicts=[],
        )

    # Apply buffer (approximate degrees → metres conversion)
    request_poly_buffered = request_poly.buffer(buffer_m / 111320.0)

    conflicts: List[ConflictDetail] = []

    for op in existing_operations:
        try:
            op_poly = _parse_polygon(op.area_wkt)
        except Exception:
            logger.warning(f"Failed to parse op polygon: {op.operation_id}")
            continue

        # 3D check
        overlap_area, overlap_pct = _check_spatial_overlap(
            request_poly_buffered, op_poly
        )
        has_alt, alt_min, alt_max = _check_altitude_overlap(
            request_alt_min, request_alt_max,
            op.altitude_min_m, op.altitude_max_m,
        )
        temporal_overlap_min = _check_temporal_overlap(
            request_time_start, request_time_end,
            op.time_start, op.time_end,
        )

        if overlap_area > 0 or has_alt or temporal_overlap_min > 0:
            severity = _classify_severity(
                overlap_pct, has_alt, temporal_overlap_min
            )

            # Build English description
            desc_parts = []
            if overlap_area > 0:
                desc_parts.append(
                    f"horizontal overlap {overlap_pct:.1f}% ({overlap_area:.0f} m²)"
                )
            if has_alt:
                desc_parts.append(
                    f"altitude overlap {alt_min:.0f}–{alt_max:.0f} m"
                )
            if temporal_overlap_min > 0:
                desc_parts.append(
                    f"temporal overlap {temporal_overlap_min:.0f} min"
                )

            description = (
                f"Conflict with [{op.operator_name}] "
                f"{op.flight_purpose} operation: "
                + "; ".join(desc_parts)
                + f". Severity: {severity}"
            )

            conflicts.append(ConflictDetail(
                operation_a_id="REQUEST",
                operation_b_id=op.operation_id,
                spatial_overlap_area_m2=round(overlap_area, 2),
                spatial_overlap_percent=round(overlap_pct, 2),
                altitude_overlap_min_m=round(alt_min, 1),
                altitude_overlap_max_m=round(alt_max, 1),
                has_altitude_overlap=has_alt,
                temporal_overlap_minutes=round(temporal_overlap_min, 1),
                severity=severity,
                description=description,
            ))

    # Sort by severity (most severe first)
    severity_order = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3}
    conflicts.sort(key=lambda c: severity_order.get(c.severity, 4))

    logger.info(
        f"Conflict check: {len(conflicts)} conflicts found "
        f"({len(existing_operations)} existing ops checked)"
    )

    return ConflictResult(
        has_conflict=len(conflicts) > 0,
        conflict_count=len(conflicts),
        conflicts=conflicts,
    )
