"""
Geofence checks against restricted, infrastructure and temporary zones.

Static zones are loaded from GeoJSON (lon/lat); temporary controlled zones
carry an active time window and may also be supplied per case.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Iterable, Sequence

from shapely.geometry import Polygon, shape

from src.airspace.separation import Volume
from src.geo.projection import polygon_lonlat_to_metric, to_metric


class ZoneType(str, Enum):
    PROHIBITED = "PROHIBITED"
    AIRPORT_CONTROL = "AIRPORT_CONTROL"
    SENSITIVE_FACILITY = "SENSITIVE_FACILITY"
    INFRASTRUCTURE = "INFRASTRUCTURE"
    TEMPORARY = "TEMPORARY"


RESTRICTED_TYPES = {ZoneType.PROHIBITED, ZoneType.AIRPORT_CONTROL, ZoneType.SENSITIVE_FACILITY}


@dataclass
class Zone:
    zone_id: str
    name: str
    zone_type: ZoneType
    polygon: Polygon  # metric
    alt_floor_m: float = 0.0
    alt_ceiling_m: float = 10_000.0
    active_start: datetime | None = None
    active_end: datetime | None = None
    exempt_purposes: list[str] = field(default_factory=list)
    provenance: str = ""

    @classmethod
    def from_dict(cls, d: dict) -> "Zone":
        """Build from a flat dict with ``coordinates`` as [[lon, lat], ...]."""
        return cls(
            zone_id=d["zone_id"],
            name=d.get("name", d["zone_id"]),
            zone_type=ZoneType(d["zone_type"]),
            polygon=polygon_lonlat_to_metric(d["coordinates"]),
            alt_floor_m=float(d.get("alt_floor_m", 0.0)),
            alt_ceiling_m=float(d.get("alt_ceiling_m", 10_000.0)),
            active_start=_opt_dt(d.get("active_start")),
            active_end=_opt_dt(d.get("active_end")),
            exempt_purposes=list(d.get("exempt_purposes", [])),
            provenance=d.get("provenance", ""),
        )


def _opt_dt(v) -> datetime | None:
    if v in (None, ""):
        return None
    return v if isinstance(v, datetime) else datetime.fromisoformat(str(v))


@dataclass
class ZoneHit:
    zone_id: str
    name: str
    zone_type: ZoneType
    exempt: bool
    overlap_m2: float
    active_start: datetime | None = None
    active_end: datetime | None = None

    def to_dict(self) -> dict:
        return {
            "zone_id": self.zone_id, "name": self.name, "zone_type": self.zone_type.value,
            "exempt": self.exempt, "overlap_m2": round(self.overlap_m2, 1),
            "active_start": self.active_start.isoformat() if self.active_start else None,
            "active_end": self.active_end.isoformat() if self.active_end else None,
        }

    def to_text(self) -> str:
        s = f"{self.name} [{self.zone_type.value}]"
        if self.active_start:
            s += f", active {self.active_start:%Y-%m-%d %H:%M}-{self.active_end:%H:%M}"
        if self.exempt:
            s += " (purpose-based exemption applies)"
        return s


def load_zones(path: Path | str) -> list[Zone]:
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    zones = []
    for feat in data["features"]:
        p = feat["properties"]
        zones.append(Zone(
            zone_id=p["zone_id"],
            name=p.get("name", p["zone_id"]),
            zone_type=ZoneType(p["zone_type"]),
            polygon=to_metric(shape(feat["geometry"])),
            alt_floor_m=float(p.get("alt_floor_m", 0.0)),
            alt_ceiling_m=float(p.get("alt_ceiling_m", 10_000.0)),
            active_start=_opt_dt(p.get("active_start")),
            active_end=_opt_dt(p.get("active_end")),
            exempt_purposes=list(p.get("exempt_purposes", [])),
            provenance=p.get("provenance", ""),
        ))
    return zones


def zones_to_geojson(zones: Sequence[dict]) -> dict:
    """Serialise flat zone dicts (lon/lat coordinates) to a FeatureCollection."""
    feats = []
    for z in zones:
        props = {k: v for k, v in z.items() if k != "coordinates"}
        feats.append({"type": "Feature", "properties": props,
                      "geometry": {"type": "Polygon", "coordinates": [z["coordinates"]]}})
    return {"type": "FeatureCollection", "features": feats}


class GeofenceChecker:
    def __init__(self, zones: Iterable[Zone]):
        self.zones = list(zones)

    def with_extra(self, extra: Iterable[Zone]) -> "GeofenceChecker":
        return GeofenceChecker(self.zones + list(extra))

    def check(self, vol: Volume, purpose: str | None = None) -> list[ZoneHit]:
        hits = []
        for z in self.zones:
            if not vol.polygon.intersects(z.polygon):
                continue
            overlap = vol.polygon.intersection(z.polygon).area
            if overlap <= 0:
                continue
            if vol.alt_max <= z.alt_floor_m or vol.alt_min >= z.alt_ceiling_m:
                continue
            if z.active_start and z.active_end and (vol.end <= z.active_start or vol.start >= z.active_end):
                continue
            exempt = purpose is not None and purpose in z.exempt_purposes
            hits.append(ZoneHit(z.zone_id, z.name, z.zone_type, exempt, overlap, z.active_start, z.active_end))
        return hits
