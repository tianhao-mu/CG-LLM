"""
4D (horizontal x vertical x time) separation assessment.

A requested volume is compared against each approved operation. Gaps are
measured independently in each dimension on a metric plane; a pair is in
conflict only when it is close in *all* dimensions at once, which corrects
the single-dimension overlap rule used in the conference version.

Severity levels
  CRITICAL  strict 4D intersection, overlap ratio > critical ratio
  HIGH      strict 4D intersection
  MEDIUM    every gap below the separation minima
  LOW       every gap below advisory_factor x minima
  NONE      otherwise
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import datetime
from enum import Enum
from typing import Iterable, Sequence

from shapely.geometry import Polygon
from shapely.strtree import STRtree

from src.geo.projection import polygon_lonlat_to_metric


class Severity(str, Enum):
    NONE = "NONE"
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"

    @property
    def rank(self) -> int:
        return ["NONE", "LOW", "MEDIUM", "HIGH", "CRITICAL"].index(self.value)


@dataclass(frozen=True)
class SeparationMinima:
    horizontal_m: float = 50.0
    vertical_m: float = 30.0
    temporal_min: float = 10.0
    advisory_factor: float = 2.0
    critical_overlap_ratio: float = 0.5

    @classmethod
    def from_dict(cls, d: dict | None) -> "SeparationMinima":
        return cls(**(d or {}))


@dataclass
class Volume:
    """A 4D operation volume. ``polygon`` is metric (EPSG:4547)."""
    vid: str
    polygon: Polygon
    alt_min: float
    alt_max: float
    start: datetime
    end: datetime
    meta: dict = field(default_factory=dict)

    @classmethod
    def from_lonlat(cls, vid: str, coords: Sequence[Sequence[float]], alt_min: float, alt_max: float,
                    start: datetime | str, end: datetime | str, **meta) -> "Volume":
        return cls(vid, polygon_lonlat_to_metric(coords), float(alt_min), float(alt_max),
                   _dt(start), _dt(end), meta)

    def shifted(self, minutes: float = 0.0, alt_min: float | None = None, alt_max: float | None = None) -> "Volume":
        from datetime import timedelta
        delta = timedelta(minutes=minutes)
        return Volume(self.vid, self.polygon,
                      self.alt_min if alt_min is None else alt_min,
                      self.alt_max if alt_max is None else alt_max,
                      self.start + delta, self.end + delta, dict(self.meta))


def _dt(v: datetime | str) -> datetime:
    return v if isinstance(v, datetime) else datetime.fromisoformat(str(v))


def _interval_gap(a0: float, a1: float, b0: float, b1: float) -> tuple[float, float]:
    """Return (gap, overlap) between two closed intervals."""
    overlap = min(a1, b1) - max(a0, b0)
    return (max(0.0, -overlap), max(0.0, overlap))


@dataclass
class PairAssessment:
    request_id: str
    other_id: str
    horizontal_gap_m: float
    vertical_gap_m: float
    temporal_gap_min: float
    horizontal_overlap_m2: float
    overlap_ratio: float
    severity: Severity

    def to_dict(self) -> dict:
        d = asdict(self)
        d["severity"] = self.severity.value
        for k in ("horizontal_gap_m", "vertical_gap_m", "temporal_gap_min", "horizontal_overlap_m2", "overlap_ratio"):
            d[k] = round(d[k], 3)
        return d

    def to_text(self) -> str:
        return (f"{self.other_id}: severity={self.severity.value}, horizontal gap={self.horizontal_gap_m:.0f} m, "
                f"vertical gap={self.vertical_gap_m:.0f} m, time gap={self.temporal_gap_min:.0f} min, "
                f"overlap ratio={self.overlap_ratio:.2f}")


@dataclass
class SeparationReport:
    request_id: str
    pairs: list[PairAssessment]

    @property
    def max_severity(self) -> Severity:
        return max((p.severity for p in self.pairs), key=lambda s: s.rank, default=Severity.NONE)

    @property
    def conflicts(self) -> list[PairAssessment]:
        return [p for p in self.pairs if p.severity != Severity.NONE]

    def to_dict(self) -> dict:
        return {"request_id": self.request_id, "max_severity": self.max_severity.value,
                "conflicts": [p.to_dict() for p in self.conflicts]}

    def to_text(self) -> str:
        if not self.conflicts:
            return "No separation infringement with approved operations."
        lines = [f"Maximum severity: {self.max_severity.value}"]
        lines += ["- " + p.to_text() for p in sorted(self.conflicts, key=lambda p: -p.severity.rank)]
        return "\n".join(lines)


class SeparationEngine:
    """Assess a requested volume against approved volumes.

    ``use_index`` toggles the STRtree pre-filter; both modes return identical
    results and are compared in the scalability benchmark.
    """

    def __init__(self, approved: Iterable[Volume], minima: SeparationMinima | None = None, use_index: bool = True):
        self.minima = minima or SeparationMinima()
        self.approved = list(approved)
        self.use_index = use_index
        self._tree = STRtree([v.polygon for v in self.approved]) if use_index and self.approved else None

    def _candidates(self, req: Volume) -> list[Volume]:
        if self._tree is None:
            return self.approved
        radius = self.minima.horizontal_m * self.minima.advisory_factor
        idx = self._tree.query(req.polygon.buffer(radius))
        return [self.approved[i] for i in sorted(idx)]

    def assess_pair(self, req: Volume, other: Volume) -> PairAssessment:
        m = self.minima
        h_gap = req.polygon.distance(other.polygon)
        inter_area = req.polygon.intersection(other.polygon).area if h_gap == 0 else 0.0
        v_gap, v_ov = _interval_gap(req.alt_min, req.alt_max, other.alt_min, other.alt_max)
        t0r, t1r = req.start.timestamp() / 60, req.end.timestamp() / 60
        t0o, t1o = other.start.timestamp() / 60, other.end.timestamp() / 60
        t_gap, t_ov = _interval_gap(t0r, t1r, t0o, t1o)

        strict = inter_area > 0 and v_ov > 0 and t_ov > 0
        ratio = 0.0
        if strict:
            a_min = max(min(req.polygon.area, other.polygon.area), 1e-9)
            v_min = max(min(req.alt_max - req.alt_min, other.alt_max - other.alt_min), 1e-9)
            t_min = max(min(t1r - t0r, t1o - t0o), 1e-9)
            ratio = min(1.0, inter_area / a_min) * min(1.0, v_ov / v_min) * min(1.0, t_ov / t_min)

        if strict:
            sev = Severity.CRITICAL if ratio > m.critical_overlap_ratio else Severity.HIGH
        elif h_gap < m.horizontal_m and v_gap < m.vertical_m and t_gap < m.temporal_min:
            sev = Severity.MEDIUM
        elif (h_gap < m.horizontal_m * m.advisory_factor and v_gap < m.vertical_m * m.advisory_factor
              and t_gap < m.temporal_min * m.advisory_factor):
            sev = Severity.LOW
        else:
            sev = Severity.NONE
        return PairAssessment(req.vid, other.vid, h_gap, v_gap, t_gap, inter_area, ratio, sev)

    def assess(self, req: Volume) -> SeparationReport:
        return SeparationReport(req.vid, [self.assess_pair(req, o) for o in self._candidates(req)])
