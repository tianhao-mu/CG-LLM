"""
Airspace state manager.

Uses SQLite to store approved airspace operations and supports
spatio-temporal range queries.
"""

import json
import logging
import sqlite3
from datetime import datetime
from pathlib import Path
from typing import List, Optional

from src.models.operation import ApprovedOperation

logger = logging.getLogger(__name__)


class AirspaceStateManager:
    """State store for managing approved airspace operations."""

    def __init__(self, db_path: str = "data/airspace_state.db"):
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_db()

    def _get_conn(self) -> sqlite3.Connection:
        conn = sqlite3.connect(str(self.db_path))
        conn.row_factory = sqlite3.Row
        return conn

    def _init_db(self):
        """Create table schema."""
        with self._get_conn() as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS approved_operations (
                    operation_id TEXT PRIMARY KEY,
                    request_id TEXT,
                    operator_name TEXT NOT NULL,
                    flight_purpose TEXT NOT NULL,
                    altitude_min_m REAL NOT NULL,
                    altitude_max_m REAL NOT NULL,
                    area_wkt TEXT NOT NULL,
                    area_description TEXT,
                    time_start TEXT NOT NULL,
                    time_end TEXT NOT NULL,
                    approved_at TEXT NOT NULL,
                    approved_by TEXT NOT NULL,
                    remarks TEXT,
                    status TEXT NOT NULL DEFAULT 'ACTIVE'
                )
            """)
            conn.commit()
        logger.debug(f"DB initialized: {self.db_path}")

    def add_operation(self, op: ApprovedOperation) -> str:
        """Add an approved operation."""
        with self._get_conn() as conn:
            conn.execute(
                """
                INSERT INTO approved_operations
                (operation_id, request_id, operator_name, flight_purpose,
                 altitude_min_m, altitude_max_m, area_wkt, area_description,
                 time_start, time_end, approved_at, approved_by, remarks, status)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    op.operation_id,
                    op.request_id,
                    op.operator_name,
                    op.flight_purpose,
                    op.altitude_min_m,
                    op.altitude_max_m,
                    op.area_wkt,
                    op.area_description,
                    op.time_start.isoformat(),
                    op.time_end.isoformat(),
                    op.approved_at.isoformat(),
                    op.approved_by,
                    op.remarks,
                    op.status,
                ),
            )
            conn.commit()
        logger.info(f"Added operation: {op.operation_id}")
        return op.operation_id

    def get_active_operations(
        self,
        time_start: Optional[datetime] = None,
        time_end: Optional[datetime] = None,
        status: str = "ACTIVE",
    ) -> List[ApprovedOperation]:
        """Query active operations, optionally filtered by time window."""
        with self._get_conn() as conn:
            query = "SELECT * FROM approved_operations WHERE status = ?"
            params = [status]

            if time_start and time_end:
                # Find operations with overlapping time windows
                query += (
                    " AND time_start <= ? AND time_end >= ?"
                )
                params.extend([
                    time_end.isoformat(),
                    time_start.isoformat(),
                ])

            rows = conn.execute(query, params).fetchall()

        ops = []
        for row in rows:
            ops.append(ApprovedOperation(
                operation_id=row["operation_id"],
                request_id=row["request_id"],
                operator_name=row["operator_name"],
                flight_purpose=row["flight_purpose"],
                altitude_min_m=row["altitude_min_m"],
                altitude_max_m=row["altitude_max_m"],
                area_wkt=row["area_wkt"],
                area_description=row["area_description"],
                time_start=datetime.fromisoformat(row["time_start"]),
                time_end=datetime.fromisoformat(row["time_end"]),
                approved_at=datetime.fromisoformat(row["approved_at"]),
                approved_by=row["approved_by"],
                remarks=row["remarks"],
                status=row["status"],
            ))

        return ops

    def count(self) -> int:
        with self._get_conn() as conn:
            row = conn.execute(
                "SELECT COUNT(*) as cnt FROM approved_operations"
            ).fetchone()
        return row["cnt"]

    def clear(self):
        with self._get_conn() as conn:
            conn.execute("DELETE FROM approved_operations")
            conn.commit()
        logger.info("All operations cleared.")
