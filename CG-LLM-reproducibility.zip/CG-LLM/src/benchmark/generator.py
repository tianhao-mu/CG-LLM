"""
Recipe-based benchmark generator.

Each recipe states an *intended* decision and builds facts plus an airspace
context that should produce it. The gold label is the rule engine's decision
on the gold facts; a case is kept only if it equals the recipe intent, so
every label is confirmed by two independent routes (recipe design and
engine). Disagreements are re-sampled and counted in the build report.
"""

from __future__ import annotations

import json
import math
import random
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from pathlib import Path
from typing import Callable

from pyproj import Transformer

from src.benchmark.schema import Case, Gold
from src.benchmark.templates import FT_PER_M, altitude_values, render
from src.benchmark.world import (BACKGROUND_OPERATORS, OPERATOR_PURPOSES, OPERATORS, PURPOSE_MODELS, PURPOSE_SITES,
                                 PURPOSE_UAS_CLASSES, SITES, SPECIAL_MODELS, UAS_CATALOG, Site)
from src.policy.engine import APPROVE, ESCALATE, INDETERMINATE, MODIFY, REJECT, RuleEngine
from src.policy.facts import ApprovedOp, CaseContext, RequestFacts, TemporaryZone, classify_mtow

ROOT = Path(__file__).resolve().parents[2]
GEOFENCE = ROOT / "data" / "geofences" / "nanshan.geojson"

_FWD = Transformer.from_crs("EPSG:4326", "EPSG:4547", always_xy=True)
_INV = Transformer.from_crs("EPSG:4547", "EPSG:4326", always_xy=True)

PUBLIC_SERVICE = {"emergency_rescue", "environmental_monitoring", "airport_inspection"}
BASE_DATE = datetime(2026, 11, 2)


def rect(cx: float, cy: float, w: float, h: float) -> list[list[float]]:
    """Metric rectangle -> lon/lat ring."""
    pts = [(cx - w / 2, cy - h / 2), (cx + w / 2, cy - h / 2), (cx + w / 2, cy + h / 2), (cx - w / 2, cy + h / 2),
           (cx - w / 2, cy - h / 2)]
    return [[round(v, 7) for v in _INV.transform(x, y)] for x, y in pts]


@dataclass
class Draft:
    facts: dict
    site: Site
    cx: float
    cy: float
    w: float
    h: float
    submitted_at: datetime
    approved: list[dict] = field(default_factory=list)
    temp_zones: list[dict] = field(default_factory=list)
    tags: list[str] = field(default_factory=list)
    style_overrides: dict = field(default_factory=dict)

    @property
    def start(self) -> datetime:
        return self.facts["time_start"]

    @property
    def end(self) -> datetime:
        return self.facts["time_end"]

    @property
    def alt(self) -> tuple[float, float]:
        return self.facts.get("altitude_min_m") or 0.0, self.facts["altitude_max_m"]


class Generator:
    def __init__(self, seed: int = 2026, engine: RuleEngine | None = None):
        self.rng = random.Random(seed)
        self.engine = engine or RuleEngine()
        gj = json.loads(GEOFENCE.read_text(encoding="utf-8"))
        self.zones = {f["properties"]["zone_id"]: f["properties"] for f in gj["features"]}
        self.report = {"attempts": 0, "kept": 0, "mismatch": {}}
        self._ids = 0

    # ------------------------------------------------------------ base draft
    def base(self, purpose: str | None = None, cls: str | None = None, operator=None, site: Site | None = None,
             night: bool = False) -> Draft:
        r = self.rng
        if operator is None:
            if purpose:
                cands = [o for o in OPERATORS if purpose in OPERATOR_PURPOSES[o.en]]
            else:
                cands = [o for o in OPERATORS if OPERATOR_PURPOSES[o.en][0] not in ("airport_inspection",)]
            operator = r.choice(cands)
        purpose = purpose or r.choice(OPERATOR_PURPOSES[operator.en])
        cls = cls or r.choice(PURPOSE_UAS_CLASSES[purpose])
        pool = [u for u in UAS_CATALOG[cls] if u.model in PURPOSE_MODELS[purpose]] if purpose in PURPOSE_MODELS \
            else [u for u in UAS_CATALOG[cls] if u.model not in SPECIAL_MODELS]
        uas = r.choice(pool or UAS_CATALOG[cls])
        if site is None:
            keys = PURPOSE_SITES.get(purpose)
            site = r.choice([s for s in SITES if (s.key in keys if keys else s.key not in ("fuyong",))])

        day = BASE_DATE + timedelta(days=r.randint(1, 60))
        if night:
            start = day.replace(hour=19) + timedelta(minutes=r.choice([-15, 0, 30, 60, 90]))
        else:
            start = day.replace(hour=r.randint(8, 15), minute=r.choice([0, 15, 30, 45]))
        dur = r.choice([30, 45, 60, 90, 120, 150])
        end = start + timedelta(minutes=dur)
        if cls == "micro":
            a_min, a_max = 0.0, float(r.choice([20, 30, 40, 50]))
        else:
            a_min = float(r.choice([0, 0, 10, 20, 30, 40, 50]))
            a_max = float(min(120, a_min + r.choice([30, 40, 50, 60, 70, 80])))
        if r.random() < 0.6:
            submitted = (start - timedelta(days=1)).replace(hour=r.randint(8, 11), minute=r.choice([0, 10, 25, 40]))
        else:
            submitted = (start - timedelta(days=r.randint(2, 6))).replace(hour=r.randint(9, 17), minute=r.choice([0, 30]))

        individual = operator.kind == "individual"
        commercial = None if individual else (False if purpose in PUBLIC_SERVICE else True)
        if individual and purpose == "aerial_photography" and r.random() < 0.5:
            commercial = False
        f = dict(operator_name=operator.en, operator_type=operator.kind, commercial=commercial, purpose=purpose,
                 uas_model=uas.model, mtow_kg=uas.mtow_kg, altitude_min_m=a_min, altitude_max_m=a_max,
                 time_start=start, time_end=end, emergency=None, bvlos=None, daa_capability=None, lighting=None,
                 prohibited_activity=None)
        f["_operator_zh"] = operator.zh
        for k in self.required_credentials(f):
            f[k] = True
        if r.random() < 0.25:
            f["bvlos"] = False
        if r.random() < 0.2 and not individual:
            f["liability_insurance"] = True

        cx, cy = _FWD.transform(site.lon, site.lat)
        cx += r.uniform(-250, 250)
        cy += r.uniform(-250, 250)
        w, h = r.choice([200, 300, 400, 500, 600]), r.choice([200, 300, 400, 500])
        return Draft(f, site, cx, cy, w, h, submitted)

    def required_credentials(self, f: dict) -> list[str]:
        cls = classify_mtow(f["mtow_kg"]).value
        heavy = cls in ("small", "medium", "large")
        agri = f["purpose"] == "agriculture"
        req = ["real_name_registered"]
        if cls != "micro" and f["operator_type"] != "individual" and not (agri and cls != "large"):
            req.append("operation_certificate")
        if f.get("commercial") or heavy:
            req.append("liability_insurance")
        if heavy:
            req.append("agri_operating_certificate" if agri else "pilot_license")
        if cls in ("medium", "large"):
            req.append("airworthiness_certificate")
        if f["purpose"] == "surveying":
            req.append("survey_qualification")
        return req

    # ------------------------------------------------------------ ops helpers
    def op(self, d: Draft, dx: float = 0, dy: float = 0, w: float | None = None, h: float | None = None,
           alt: tuple[float, float] | None = None, t0: datetime | None = None, t1: datetime | None = None) -> dict:
        self._ids += 1
        return dict(op_id=f"OP-{self._ids:05d}", operator=self.rng.choice(BACKGROUND_OPERATORS),
                    coordinates=rect(d.cx + dx, d.cy + dy, w or d.w, h or d.h),
                    altitude_min_m=(alt or d.alt)[0], altitude_max_m=(alt or d.alt)[1],
                    time_start=t0 or d.start, time_end=t1 or d.end)

    def add_background(self, d: Draft, n: int | None = None) -> None:
        """Approved operations that never interact with the request."""
        r = self.rng
        n = r.randint(1, 5) if n is None else n
        tries = 0
        while n > 0 and tries < 50:
            tries += 1
            dx, dy = r.uniform(-3000, 3000), r.uniform(-3000, 3000)
            t0 = d.start.replace(hour=r.randint(7, 17), minute=r.choice([0, 30]))
            o = self.op(d, dx, dy, r.choice([200, 300, 500]), r.choice([200, 300, 500]),
                        (float(r.choice([0, 20, 40])), float(r.choice([60, 90, 120]))), t0,
                        t0 + timedelta(minutes=r.choice([30, 60, 120])))
            if self._interacts(d, o):
                continue
            d.approved.append(o)
            n -= 1

    def _interacts(self, d: Draft, o: dict) -> bool:
        from src.airspace.separation import SeparationEngine, Severity, Volume
        req = Volume.from_lonlat("R", rect(d.cx, d.cy, d.w, d.h), *d.alt, d.start, d.end)
        other = Volume.from_lonlat("O", o["coordinates"], o["altitude_min_m"], o["altitude_max_m"],
                                   o["time_start"], o["time_end"])
        p = SeparationEngine([], self.engine.table.minima).assess_pair(req, other)
        # Keep background traffic clear of the whole modification search range (+-4 h).
        close_in_space = p.horizontal_gap_m < 150 and p.vertical_gap_m < 90
        return p.severity != Severity.NONE or (close_in_space and p.temporal_gap_min < 260)

    # ------------------------------------------------------------ conflicts
    def time_gap_op(self, d: Draft, gap: float, after: bool = True) -> dict:
        dur = timedelta(minutes=self.rng.choice([30, 60]))
        if after:
            t0 = d.end + timedelta(minutes=gap)
            return self.op(d, t0=t0, t1=t0 + dur)
        t1 = d.start - timedelta(minutes=gap)
        return self.op(d, t0=t1 - dur, t1=t1)

    def vertical_gap_op(self, d: Draft, gap: float) -> dict:
        lo, hi = d.alt
        top = min(120.0, hi + gap + 30)
        return self.op(d, alt=(hi + gap, max(top, hi + gap + 10)), t0=d.start - timedelta(minutes=30),
                       t1=d.end + timedelta(minutes=30))

    def horizontal_gap_op(self, d: Draft, gap: float, w: float = 300) -> dict:
        dx = d.w / 2 + gap + w / 2
        return self.op(d, dx=dx, w=w, h=d.h, t0=d.start - timedelta(minutes=15), t1=d.end + timedelta(minutes=15))

    def zone_edge(self, zone_id: str, inside: float = 0.5) -> tuple[float, float]:
        """Metric point near a static zone edge; ``inside`` in [0,1] moves toward the centre."""
        z = self.zones[zone_id]
        zx, zy = _FWD.transform(*z["center"])
        half = z["size_m"][0] / 2
        return zx + half * (1 - inside), zy

    # ------------------------------------------------------------ finalize
    def finalize(self, recipe: str, intent: str, d: Draft, style: dict | None = None) -> Case | None:
        r = self.rng
        self.report["attempts"] += 1
        style = style or {
            "time_fmt": r.choice(["long", "long", "iso", "12h"]),
            "alt_unit": "ft" if r.random() < 0.12 else "m",
            "order": "shuffled" if r.random() < 0.3 else "standard",
            "distractors": r.choice([0, 0, 0, 1, 2]),
        }
        style.update(d.style_overrides)
        style["operator_zh"] = d.facts.get("_operator_zh", "")
        style["area_zh"] = d.site.zh
        f = {k: v for k, v in d.facts.items() if not k.startswith("_")}
        facts = RequestFacts.model_validate(f)
        if style["alt_unit"] == "ft" and facts.altitude_max_m is not None:
            a_ft, b_ft = altitude_values(facts, "ft")
            facts = facts.model_copy(update={"altitude_min_m": round(a_ft / FT_PER_M, 2),
                                             "altitude_max_m": round(b_ft / FT_PER_M, 2)})
        facts = facts.model_copy(update={"uas_class": classify_mtow(facts.mtow_kg).value if facts.mtow_kg else None})

        area_en, area_zh = d.site.en, d.site.zh
        ctx = CaseContext(case_id="tmp", area_name=area_en, area_coordinates=rect(d.cx, d.cy, d.w, d.h),
                          submitted_at=d.submitted_at, approved_ops=[ApprovedOp(**o) for o in d.approved],
                          temporary_zones=[TemporaryZone(**z) for z in d.temp_zones])
        dec = self.engine.evaluate(facts, ctx)
        gold_decision = ESCALATE if dec.decision == INDETERMINATE else dec.decision
        if gold_decision != intent:
            key = f"{recipe}:{gold_decision}"
            self.report["mismatch"][key] = self.report["mismatch"].get(key, 0) + 1
            return None

        rs = random.Random(r.random())
        text_en = render(facts, area_en, style, "en", random.Random(rs.random()))
        zh_facts = facts.model_copy(update={"operator_name": d.facts.get("_operator_zh", facts.operator_name)})
        text_zh = render(zh_facts, area_zh, style, "zh", random.Random(rs.random()))
        cid = f"{recipe}-{self.report['kept']:04d}"
        ctx = ctx.model_copy(update={"case_id": cid})
        self.report["kept"] += 1
        return Case(case_id=cid, recipe=recipe, tags=d.tags, texts={"en": text_en, "zh": text_zh}, style=style,
                    context=ctx,
                    gold=Gold(decision=gold_decision, intent=intent, facts=facts.to_json_dict(),
                              trigger_ids=dec.trigger_ids, articles=dec.articles, modification=dec.modification,
                              engine=dec.to_dict()))


# ============================================================== recipes
Recipe = Callable[[Generator], Draft]
RECIPES: dict[str, tuple[str, Recipe, list[str]]] = {}


def recipe(name: str, intent: str, tags: list[str] | None = None):
    def deco(fn: Recipe):
        RECIPES[name] = (intent, fn, tags or [])
        return fn
    return deco


@recipe("APPROVE_CLEAN", APPROVE, ["clean"])
def _approve_clean(g: Generator) -> Draft:
    d = g.base()
    g.add_background(d)
    return d


@recipe("APPROVE_MICRO_INDIVIDUAL", APPROVE, ["clean", "class"])
def _approve_micro(g):
    op = g.rng.choice([o for o in OPERATORS if o.kind == "individual"])
    d = g.base(purpose="recreation", cls="micro", operator=op)
    g.add_background(d)
    return d


@recipe("APPROVE_NEAR_MISS", APPROVE, ["separation", "near_miss"])
def _approve_near_miss(g):
    d = g.base()
    r = g.rng
    kind = r.choice(["time", "vertical", "horizontal"])
    if kind == "time":
        d.approved.append(g.time_gap_op(d, r.randint(21, 45), after=r.random() < 0.5))
    elif kind == "vertical" and d.alt[1] <= 50:
        d.approved.append(g.vertical_gap_op(d, r.randint(61, 70)))
    else:
        d.approved.append(g.horizontal_gap_op(d, r.randint(101, 200)))
    d.tags.append(kind)
    return d


@recipe("MODIFY_SEPARATION_TIME", MODIFY, ["separation"])
def _mod_sep_time(g):
    d = g.base()
    d.approved.append(g.time_gap_op(d, g.rng.choice([1, 3, 5, 8, 12, 15, 18]), after=g.rng.random() < 0.5))
    g.add_background(d, g.rng.randint(0, 3))
    return d


@recipe("MODIFY_SEPARATION_VERTICAL", MODIFY, ["separation"])
def _mod_sep_vert(g):
    d = g.base()
    d.facts["altitude_min_m"] = float(g.rng.choice([40, 50, 60]))
    d.facts["altitude_max_m"] = d.facts["altitude_min_m"] + 30
    d.approved.append(g.vertical_gap_op(d, g.rng.choice([5, 10, 15, 20, 25])))
    return d


@recipe("MODIFY_SEPARATION_HORIZONTAL", MODIFY, ["separation"])
def _mod_sep_horiz(g):
    d = g.base()
    d.approved.append(g.horizontal_gap_op(d, g.rng.choice([10, 20, 30, 40, 60, 80])))
    return d


@recipe("REJECT_SEPARATION_OVERLAP", REJECT, ["separation"])
def _rej_overlap(g):
    d = g.base()
    r = g.rng
    d.approved.append(g.op(d, dx=r.uniform(-0.3, 0.3) * d.w, dy=r.uniform(-0.3, 0.3) * d.h,
                           t0=d.start + timedelta(minutes=r.choice([-30, 0, 15])),
                           t1=d.end + timedelta(minutes=r.choice([0, 30]))))
    return d


@recipe("REJECT_SEPARATION_UNRESOLVABLE", REJECT, ["separation", "unresolvable"])
def _rej_unres(g):
    d = g.base()
    day = d.start.replace(hour=0, minute=0)
    d.approved.append(g.op(d, dx=d.w / 2 + 20 + 300, w=600, h=d.h + 200, alt=(0.0, 120.0),
                           t0=day.replace(hour=5), t1=day.replace(hour=23)))
    return d


@recipe("MODIFY_ALTITUDE", MODIFY, ["altitude"])
def _mod_alt(g):
    d = g.base()
    d.facts["altitude_max_m"] = float(g.rng.choice([125, 130, 135, 140, 150]))
    d.facts["altitude_min_m"] = float(g.rng.choice([0, 20, 40, 60]))
    return d


@recipe("MODIFY_MICRO_ALTITUDE", MODIFY, ["altitude", "class"])
def _mod_micro_alt(g):
    op = g.rng.choice([o for o in OPERATORS if o.kind == "individual"])
    d = g.base(purpose="recreation", cls="micro", operator=op)
    d.facts["altitude_min_m"] = 0.0
    d.facts["altitude_max_m"] = float(g.rng.choice([60, 70, 80]))
    return d


@recipe("REJECT_ALTITUDE", REJECT, ["altitude"])
def _rej_alt(g):
    d = g.base()
    d.facts["altitude_max_m"] = float(g.rng.choice([160, 180, 200, 250, 300]))
    d.facts["altitude_min_m"] = float(g.rng.choice([0, 50, 100]))
    return d


@recipe("REJECT_RESTRICTED_ZONE", REJECT, ["geofence"])
def _rej_restricted(g):
    zid = g.rng.choice(["Z_AIRPORT_ZGSZ", "Z_SENSITIVE_A", "Z_PROHIBITED_P1"])
    d = g.base()
    d.cx, d.cy = g.zone_edge(zid, g.rng.uniform(0.0, 0.3))
    d.tags.append(zid)
    return d


@recipe("APPROVE_AIRPORT_EXEMPT", APPROVE, ["geofence", "exemption"])
def _approve_airport(g):
    d = g.base(purpose="airport_inspection")
    zx, zy = _FWD.transform(*g.zones["Z_AIRPORT_ZGSZ"]["center"])
    d.cx, d.cy = zx + g.rng.uniform(-2000, 2000), zy + g.rng.uniform(-1500, 1500)
    return d


@recipe("REJECT_INFRASTRUCTURE", REJECT, ["geofence"])
def _rej_infra(g):
    zid = g.rng.choice(["Z_INFRA_SHEKOU_PORT", "Z_INFRA_CHIWAN_PORT", "Z_INFRA_SZBAY_PORT", "Z_INFRA_NANSHAN_POWER",
                        "Z_INFRA_XILI_WATER"])
    d = g.base(purpose=g.rng.choice(["aerial_photography", "delivery", "surveying", "training"]))
    d.cx, d.cy = g.zone_edge(zid, g.rng.uniform(0.0, 0.4))
    d.tags.append(zid)
    return d


@recipe("APPROVE_INFRA_INSPECTION", APPROVE, ["geofence", "exemption"])
def _approve_infra(g):
    zid = g.rng.choice(["Z_INFRA_NANSHAN_POWER", "Z_INFRA_SZBAY_PORT", "Z_INFRA_SHEKOU_PORT"])
    d = g.base(purpose="infrastructure_inspection")
    d.cx, d.cy = g.zone_edge(zid, g.rng.uniform(0.3, 0.9))
    d.tags.append(zid)
    return d


def _temp_zone(g: Generator, d: Draft, t0: datetime, t1: datetime) -> dict:
    name = g.rng.choice(["Temporary controlled airspace for a public event",
                         "Temporary controlled airspace for a VIP visit",
                         "Temporary controlled airspace for firefighting operations"])
    return dict(zone_id=f"TMP-{g._ids:05d}", name=name, coordinates=rect(d.cx + 200, d.cy, d.w + 1500, d.h + 1500),
                active_start=t0, active_end=t1)


@recipe("MODIFY_TEMPORARY_ZONE", MODIFY, ["geofence", "temporary"])
def _mod_temp(g):
    d = g.base()
    off = g.rng.choice([-20, -10, 10, 20])
    t0 = d.start + timedelta(minutes=off)
    d.temp_zones.append(_temp_zone(g, d, t0, t0 + timedelta(minutes=g.rng.choice([30, 45]))))
    return d


@recipe("REJECT_TEMPORARY_ZONE", REJECT, ["geofence", "temporary"])
def _rej_temp(g):
    d = g.base()
    day = d.start.replace(hour=0, minute=0)
    d.temp_zones.append(_temp_zone(g, d, day.replace(hour=4), day.replace(hour=23, minute=30)))
    return d


@recipe("REJECT_CREDENTIAL_NEGATIVE", REJECT, ["credential"])
def _rej_cred(g):
    d = g.base(cls=None)
    field_ = g.rng.choice(g.required_credentials(d.facts))
    d.facts[field_] = False
    d.tags.append(field_)
    return d


@recipe("MODIFY_CREDENTIAL_MISSING", MODIFY, ["credential"])
def _mod_cred(g):
    d = g.base()
    field_ = g.rng.choice(g.required_credentials(d.facts))
    d.facts[field_] = None
    d.tags.append(field_)
    return d


@recipe("MODIFY_NIGHT_NO_LIGHTING", MODIFY, ["operational", "night"])
def _mod_night(g):
    d = g.base(night=True)
    d.facts["lighting"] = g.rng.choice([None, False])
    return d


@recipe("APPROVE_NIGHT_LIT", APPROVE, ["operational", "night"])
def _approve_night(g):
    d = g.base(night=True)
    d.facts["lighting"] = True
    return d


@recipe("MODIFY_BVLOS_NO_DAA", MODIFY, ["operational", "bvlos"])
def _mod_bvlos(g):
    d = g.base()
    d.facts["bvlos"] = True
    d.facts["daa_capability"] = g.rng.choice([None, False])
    return d


@recipe("APPROVE_BVLOS_DAA", APPROVE, ["operational", "bvlos"])
def _approve_bvlos(g):
    d = g.base()
    d.facts["bvlos"] = True
    d.facts["daa_capability"] = True
    return d


@recipe("REJECT_LATE_FILING", REJECT, ["filing"])
def _rej_late(g):
    d = g.base()
    if g.rng.random() < 0.5:
        d.submitted_at = (d.start - timedelta(days=1)).replace(hour=g.rng.randint(13, 20), minute=0)
    else:
        d.submitted_at = d.start - timedelta(hours=g.rng.randint(2, 5))
    return d


@recipe("APPROVE_EMERGENCY", APPROVE, ["filing", "emergency"])
def _approve_emergency(g):
    d = g.base(purpose="emergency_rescue")
    d.facts["emergency"] = True
    d.submitted_at = d.start - timedelta(minutes=g.rng.choice([35, 45, 60, 90, 120]))
    return d


@recipe("REJECT_EMERGENCY_LATE", REJECT, ["filing", "emergency"])
def _rej_emergency(g):
    d = g.base(purpose="emergency_rescue")
    d.facts["emergency"] = True
    d.submitted_at = d.start - timedelta(minutes=g.rng.choice([5, 10, 15, 20, 25]))
    return d


@recipe("REJECT_PROHIBITED_ACTIVITY", REJECT, ["prohibited"])
def _rej_prohibited(g):
    d = g.base(purpose="aerial_photography")
    d.facts["prohibited_activity"] = True
    return d


@recipe("APPROVE_AGRI_EXEMPT", APPROVE, ["exemption", "class"])
def _approve_agri(g):
    d = g.base(purpose="agriculture", site=g.rng.choice([s for s in SITES if s.key in ("songgang", "shiyan")]))
    return d


@recipe("MULTI_MODIFY", MODIFY, ["multi"])
def _multi_mod(g):
    d = g.base()
    d.facts["altitude_max_m"] = float(g.rng.choice([130, 140]))
    d.facts["altitude_min_m"] = 20.0
    field_ = g.rng.choice(g.required_credentials(d.facts))
    d.facts[field_] = None
    if g.rng.random() < 0.5:
        d.approved.append(g.time_gap_op(d, g.rng.choice([3, 6, 12]), after=True))
    return d


@recipe("MULTI_REJECT", REJECT, ["multi"])
def _multi_rej(g):
    d = g.base()
    d.approved.append(g.time_gap_op(d, g.rng.choice([4, 8, 14]), after=g.rng.random() < 0.5))
    field_ = g.rng.choice(g.required_credentials(d.facts))
    d.facts[field_] = False
    d.facts["altitude_max_m"] = float(g.rng.choice([110, 130]))
    return d


@recipe("MULTI_NIGHT_SEPARATION", MODIFY, ["multi", "night"])
def _multi_night(g):
    d = g.base(night=True)
    d.facts["lighting"] = None
    d.approved.append(g.time_gap_op(d, g.rng.choice([2, 6, 15]), after=False))
    return d


@recipe("BOUNDARY_ALTITUDE", APPROVE, ["boundary", "altitude"])
def _bnd_alt_ok(g):
    d = g.base()
    d.facts["altitude_max_m"] = 120.0
    d.style_overrides = {"alt_unit": "m"}
    return d


@recipe("BOUNDARY_ALTITUDE_MARGIN", MODIFY, ["boundary", "altitude"])
def _bnd_alt_margin(g):
    d = g.base()
    d.facts["altitude_max_m"] = 150.0
    d.facts["altitude_min_m"] = float(g.rng.choice([0, 50, 100]))
    d.style_overrides = {"alt_unit": "m"}
    return d


@recipe("BOUNDARY_ALTITUDE_BEYOND", REJECT, ["boundary", "altitude"])
def _bnd_alt_beyond(g):
    d = g.base()
    d.facts["altitude_max_m"] = 155.0
    d.style_overrides = {"alt_unit": "m"}
    return d


@recipe("BOUNDARY_FILING", APPROVE, ["boundary", "filing"])
def _bnd_filing(g):
    d = g.base()
    d.submitted_at = (d.start - timedelta(days=1)).replace(hour=11, minute=g.rng.choice([45, 55, 59]))
    return d


@recipe("BOUNDARY_FILING_LATE", REJECT, ["boundary", "filing"])
def _bnd_filing_late(g):
    d = g.base()
    d.submitted_at = (d.start - timedelta(days=1)).replace(hour=12, minute=g.rng.choice([1, 5, 15]))
    return d


@recipe("BOUNDARY_SEPARATION_ADVISORY", MODIFY, ["boundary", "separation"])
def _bnd_sep_adv(g):
    d = g.base()
    d.approved.append(g.time_gap_op(d, g.rng.choice([10, 19]), after=True))
    return d


@recipe("BOUNDARY_SEPARATION_CLEAR", APPROVE, ["boundary", "separation"])
def _bnd_sep_clear(g):
    d = g.base()
    d.approved.append(g.time_gap_op(d, 20, after=True))
    return d


@recipe("INCOMPLETE_REQUEST", ESCALATE, ["incomplete"])
def _incomplete(g):
    d = g.base()
    missing = g.rng.choice(["altitude", "time", "aircraft"])
    if missing == "altitude":
        d.facts["altitude_max_m"] = None
        d.facts["altitude_min_m"] = None
    elif missing == "time":
        d.facts["time_start"] = None
        d.facts["time_end"] = None
    else:
        d.facts["mtow_kg"] = None
    d.tags.append(missing)
    return d


def generate(n_per_recipe: int = 20, seed: int = 2026, dev_frac: float = 0.2, recipes: list[str] | None = None,
             max_tries: int = 40) -> tuple[list[Case], dict]:
    g = Generator(seed)
    cases: list[Case] = []
    for name, (intent, fn, tags) in RECIPES.items():
        if recipes and name not in recipes:
            continue
        got = []
        tries = 0
        while len(got) < n_per_recipe and tries < n_per_recipe * max_tries:
            tries += 1
            d = fn(g)
            d.tags = list(dict.fromkeys(tags + d.tags))
            c = g.finalize(name, intent, d)
            if c is not None:
                got.append(c)
        n_dev = max(1, round(len(got) * dev_frac))
        for i, c in enumerate(got):
            c.split = "dev" if i < n_dev else "test"
        cases.extend(got)
    report = dict(g.report, per_recipe={k: sum(c.recipe == k for c in cases) for k in RECIPES},
                  per_decision={k: sum(c.gold.decision == k for c in cases) for k in (APPROVE, MODIFY, REJECT, ESCALATE)},
                  seed=seed, n_per_recipe=n_per_recipe)
    return cases, report
