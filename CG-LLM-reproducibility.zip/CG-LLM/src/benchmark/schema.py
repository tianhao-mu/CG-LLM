"""Benchmark case schema and I/O."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Iterable, Optional

from pydantic import BaseModel, Field

from src.policy.facts import CaseContext, RequestFacts


class Gold(BaseModel):
    decision: str                     # APPROVE | MODIFY | REJECT | ESCALATE
    intent: str                       # decision intended by the recipe (cross-check)
    facts: dict                       # RequestFacts as JSON
    trigger_ids: list[str] = Field(default_factory=list)
    articles: list[str] = Field(default_factory=list)
    modification: Optional[dict] = None
    engine: dict = Field(default_factory=dict)

    def request_facts(self) -> RequestFacts:
        return RequestFacts.model_validate(self.facts)


class Case(BaseModel):
    case_id: str
    split: str = "test"
    recipe: str
    tags: list[str] = Field(default_factory=list)
    texts: dict[str, str]             # lang -> request text
    style: dict = Field(default_factory=dict)
    context: CaseContext
    gold: Gold
    parent_id: Optional[str] = None
    perturbation: Optional[str] = None

    def text(self, lang: str = "en") -> str:
        return self.texts.get(lang) or self.texts["en"]


def save_cases(cases: Iterable[Case], path: Path | str) -> int:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    n = 0
    with path.open("w", encoding="utf-8") as f:
        for c in cases:
            f.write(c.model_dump_json() + "\n")
            n += 1
    return n


def load_cases(path: Path | str, split: str | None = None, limit: int | None = None,
               recipes: Iterable[str] | None = None) -> list[Case]:
    out = []
    recipes = set(recipes) if recipes else None
    with Path(path).open(encoding="utf-8") as f:
        for line in f:
            if not line.strip():
                continue
            c = Case.model_validate_json(line)
            if split and c.split != split:
                continue
            if recipes and c.recipe not in recipes:
                continue
            out.append(c)
    if limit:
        out = out[:limit]
    return out


def dump_json(obj, path: Path | str) -> None:
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(obj, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
