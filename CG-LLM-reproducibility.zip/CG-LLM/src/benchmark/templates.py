"""
Bilingual (en / zh) request-text rendering.

``render`` turns gold facts into an application letter. Every fact that is
not None is stated exactly once; None facts are omitted, so the gold label of
"not stated" is faithful to the text. Style options vary the surface form
(time format, altitude unit, sentence order, distractors) without changing
the facts.
"""

from __future__ import annotations

import random
from datetime import datetime

from src.benchmark.world import PURPOSE_TEXT
from src.policy.facts import RequestFacts

FT_PER_M = 1 / 0.3048

EN = {
    "intro": ["This application is submitted by {op}.", "Applicant: {op}.", "We, {op}, hereby apply for a UAS flight authorization.",
              "{op} requests approval for the following drone operation."],
    "intro_ind": ["My name is {op} and I would like to apply for a drone flight.", "Applicant: {op} (private individual).",
                  "I, {op}, am applying for permission to fly a drone."],
    "purpose": ["The purpose of the flight is {p} over {area}.", "We plan to conduct {p} at {area}.",
                "The mission involves {p} in the {area} area."],
    "commercial_t": ["This is a commercial operation.", "The flight is carried out on a commercial basis for a paying client."],
    "commercial_f": ["The flight is non-commercial.", "This is a non-commercial, public-service flight."],
    "uas": ["Aircraft: {m}, maximum take-off weight {w} kg.", "We will use a {m} (MTOW {w} kg).",
            "The aircraft is a {m} with a take-off mass of {w} kg."],
    "uas_g": ["We will use a {m} weighing {g} g at take-off.", "Aircraft: {m}, take-off weight {g} grams."],
    "real_name_registered": (["The aircraft is real-name registered with the CAAC.",
                              "Real-name registration of the drone has been completed."],
                             ["The aircraft has not yet completed real-name registration.",
                              "We have not registered the drone under the real-name system."]),
    "operation_certificate": (["We hold a valid Civil UA Operation Certificate.",
                               "Our company holds a current UAS operation certificate."],
                              ["Our operation certificate expired last month and the renewal is still pending.",
                               "We do not currently hold a UAS operation certificate."]),
    "pilot_license": (["The remote pilot holds a valid CAAC UAS pilot licence.",
                       "Our pilot is licensed by the CAAC for this aircraft class."],
                      ["The pilot does not hold a remote pilot licence.",
                       "Our pilot's licence has lapsed and has not been renewed."]),
    "agri_operating_certificate": (["The operator holds the manufacturer-issued agricultural UAS operating certificate."],
                                   ["The operator has not obtained an agricultural UAS operating certificate."]),
    "liability_insurance": (["Third-party liability insurance is in place for this flight.",
                             "The operation is covered by valid third-party liability insurance."],
                            ["We have not purchased liability insurance for this operation.",
                             "The flight is not covered by any liability insurance."]),
    "airworthiness_certificate": (["The aircraft holds a valid airworthiness certificate.",
                                   "An airworthiness certificate has been issued for this aircraft."],
                                  ["The aircraft has no airworthiness certificate.",
                                   "The airworthiness certificate application is still under review."]),
    "survey_qualification": (["We hold a surveying and mapping qualification certificate.",
                              "Our institute is qualified for surveying and mapping activities."],
                             ["We have not yet obtained a surveying and mapping qualification.",
                              "Our surveying qualification certificate has been revoked."]),
    "alt": ["Planned altitude: {a}-{b} {u} above ground level.", "We will fly between {a} and {b} {u} AGL.",
            "The operating altitude band is {a} to {b} {u} true altitude."],
    "alt0": ["We will fly at heights up to {b} {u} above ground.", "Maximum altitude: {b} {u} AGL."],
    "time": ["The flight is scheduled for {d} from {s} to {e}.", "Proposed operating window: {d}, {s} to {e}.",
             "We intend to fly on {d} between {s} and {e}."],
    "bvlos_t": ["Part of the flight will be beyond visual line of sight.", "The operation is BVLOS."],
    "bvlos_f": ["All flying will be within visual line of sight.", "The pilot will keep the aircraft in visual line of sight at all times."],
    "daa_t": ["The aircraft carries ADS-B In and a detect-and-avoid system.", "A detect-and-avoid system is installed on board."],
    "daa_f": ["The aircraft has no detect-and-avoid equipment."],
    "lighting_t": ["Anti-collision strobe lights will be on throughout the flight.", "The aircraft is fitted with navigation and anti-collision lights."],
    "lighting_f": ["The aircraft is not equipped with navigation lights."],
    "emergency": ["This is an emergency request related to an ongoing incident.", "URGENT: emergency operation in support of an active rescue."],
    "prohibited": ["The footage will include close-up photography of the adjacent military installation.",
                   "We will also film the restricted military facility next to the site."],
    "distractors": ["Our team has completed more than 300 flights without incident.", "Founded in 2015, we have 120 employees.",
                    "Weather forecasts indicate light winds of about 3 m/s.", "A ground crew of 4 people will be on site.",
                    "Please contact our flight manager at 0755-2668 0120 for questions.", "The batteries were replaced in 2025."],
    "closing": ["Thank you for your consideration.", "We look forward to your reply.", ""],
}

ZH = {
    "intro": ["申请单位：{op}。", "本申请由{op}提交。", "{op}现申请以下无人机飞行活动。"],
    "intro_ind": ["申请人：{op}（个人）。", "本人{op}，申请进行一次无人机飞行。"],
    "purpose": ["飞行目的为在{area}开展{p}。", "拟在{area}实施{p}作业。", "本次任务为{area}区域的{p}。"],
    "commercial_t": ["本次飞行为经营性飞行活动。", "本次飞行为受客户委托的商业作业。"],
    "commercial_f": ["本次飞行为非经营性公益飞行。", "本次飞行不属于经营性活动。"],
    "uas": ["航空器型号：{m}，最大起飞重量{w}千克。", "使用{m}（最大起飞重量{w}千克）。", "使用的无人机为{m}，起飞重量{w}千克。"],
    "uas_g": ["使用{m}，起飞重量{g}克。"],
    "real_name_registered": (["该无人机已在民航局完成实名登记。", "无人机已完成实名制登记。"],
                             ["该无人机尚未完成实名登记。", "我们还没有对无人机进行实名登记。"]),
    "operation_certificate": (["我单位持有有效的民用无人驾驶航空器运营合格证。", "公司已取得无人机运营合格证。"],
                              ["我单位运营合格证已于上月过期，换证仍在办理中。", "我单位目前未取得运营合格证。"]),
    "pilot_license": (["操控员持有有效的民航无人机操控员执照。", "飞手已取得相应等级的操控员执照。"],
                      ["操控员未取得操控员执照。", "飞手执照已失效且尚未更新。"]),
    "agri_operating_certificate": (["操控人员持有厂家颁发的农用无人机操作证书。"],
                                   ["操控人员尚未取得农用无人机操作证书。"]),
    "liability_insurance": (["本次飞行已投保第三者责任险。", "已购买有效的第三者责任保险。"],
                            ["本次作业未投保责任保险。", "本次飞行没有任何责任保险。"]),
    "airworthiness_certificate": (["该航空器持有有效的适航证。", "该机型已取得适航许可。"],
                                  ["该航空器没有适航证。", "适航许可申请仍在审查中。"]),
    "survey_qualification": (["我单位持有测绘资质证书。", "我院具备测绘资质。"],
                             ["我单位尚未取得测绘资质。", "我单位测绘资质证书已被吊销。"]),
    "alt": ["计划飞行高度为真高{a}至{b}{u}。", "飞行高度范围：{a}-{b}{u}（真高）。", "作业高度在{a}{u}到{b}{u}之间。"],
    "alt0": ["飞行高度不超过真高{b}{u}。", "最大飞行高度：真高{b}{u}。"],
    "time": ["计划飞行时间为{d}{s}至{e}。", "拟飞行时段：{d}，{s}至{e}。", "我们打算在{d}{s}到{e}之间飞行。"],
    "bvlos_t": ["部分航段为超视距飞行。", "本次为超视距（BVLOS）飞行。"],
    "bvlos_f": ["全程为视距内飞行。", "操控员将始终保持目视可见。"],
    "daa_t": ["航空器装有ADS-B接收机和探测避让系统。", "机上配备探测与避让系统。"],
    "daa_f": ["航空器未配备探测避让设备。"],
    "lighting_t": ["飞行全程开启防撞频闪灯。", "航空器配有航行灯和防撞灯。"],
    "lighting_f": ["航空器未安装航行灯。"],
    "emergency": ["本申请为应急飞行申请，用于处置正在发生的突发事件。", "紧急：本次为配合救援的应急飞行。"],
    "prohibited": ["拍摄内容将包括对相邻军事设施的近距离拍摄。", "我们还将拍摄场地旁的军事禁区设施。"],
    "distractors": ["我们团队已安全完成300余架次飞行。", "公司成立于2015年，现有员工120人。", "天气预报显示风速约3米/秒。",
                    "现场将有4名地勤人员。", "如有疑问请联系飞行负责人，电话0755-2668 0120。", "电池已于2025年更换。"],
    "closing": ["感谢审核。", "盼复。", ""],
}

UNIT_TEXT = {"en": {"m": "m", "ft": "ft"}, "zh": {"m": "米", "ft": "英尺"}}


def _fmt_num(x: float) -> str:
    return f"{x:g}"


def fmt_date(d: datetime, lang: str, style: str) -> str:
    if lang == "zh":
        return f"{d.year}年{d.month}月{d.day}日"
    if style == "iso":
        return d.strftime("%Y-%m-%d")
    return f"{d.day} {d.strftime('%B')} {d.year}"


def fmt_time(t: datetime, lang: str, style: str) -> str:
    if style != "12h":
        return t.strftime("%H:%M")
    h12 = t.hour % 12 or 12
    if lang == "zh":
        return f"{'上午' if t.hour < 12 else '下午' if t.hour < 18 else '晚上'}{h12}:{t.minute:02d}"
    return f"{h12}:{t.minute:02d} {'am' if t.hour < 12 else 'pm'}"


def altitude_values(f: RequestFacts, unit: str) -> tuple[float, float]:
    """Altitudes as rendered. Feet are rounded inward so the band never grows."""
    a, b = f.altitude_min_m or 0.0, f.altitude_max_m
    if unit == "ft":
        import math
        return (math.ceil(a * FT_PER_M) if a else 0, math.floor(b * FT_PER_M))
    return a, b


def render(f: RequestFacts, area_name: str, style: dict, lang: str, rng: random.Random) -> str:
    T = EN if lang == "en" else ZH
    pick = rng.choice
    unit = style.get("alt_unit", "m")
    tstyle = style.get("time_fmt", "long")

    def credential(field: str) -> str | None:
        v = getattr(f, field)
        if v is None:
            return None
        pos, neg = T[field]
        return pick(pos if v else neg)

    purpose_en, purpose_zh = PURPOSE_TEXT.get(f.purpose, (str(f.purpose), str(f.purpose)))
    head = [pick(T["intro_ind"] if f.operator_type == "individual" else T["intro"]).format(op=f.operator_name),
            pick(T["purpose"]).format(p=purpose_en if lang == "en" else purpose_zh, area=area_name)]
    body: list[str] = []
    if f.emergency:
        head.insert(0, pick(T["emergency"]))
    if f.commercial is True:
        body.append(pick(T["commercial_t"]))
    elif f.commercial is False:
        body.append(pick(T["commercial_f"]))
    if f.mtow_kg is not None:
        if f.mtow_kg < 1 and rng.random() < 0.5:
            body.append(pick(T["uas_g"]).format(m=f.uas_model, g=_fmt_num(round(f.mtow_kg * 1000))))
        else:
            body.append(pick(T["uas"]).format(m=f.uas_model, w=_fmt_num(f.mtow_kg)))
    for field in ("real_name_registered", "operation_certificate", "pilot_license", "agri_operating_certificate",
                  "liability_insurance", "airworthiness_certificate", "survey_qualification"):
        s = credential(field)
        if s:
            body.append(s)
    if f.altitude_max_m is not None:
        a, b = altitude_values(f, unit)
        u = UNIT_TEXT[lang][unit]
        tpl = pick(T["alt0"]) if a == 0 else pick(T["alt"])
        body.append(tpl.format(a=_fmt_num(a), b=_fmt_num(b), u=u))
    if f.time_start is not None and f.time_end is not None:
        body.append(pick(T["time"]).format(d=fmt_date(f.time_start, lang, tstyle), s=fmt_time(f.time_start, lang, tstyle),
                                           e=fmt_time(f.time_end, lang, tstyle)))
    if f.bvlos is True:
        body.append(pick(T["bvlos_t"]))
    elif f.bvlos is False:
        body.append(pick(T["bvlos_f"]))
    if f.daa_capability is True:
        body.append(pick(T["daa_t"]))
    elif f.daa_capability is False:
        body.append(pick(T["daa_f"]))
    if f.lighting is True:
        body.append(pick(T["lighting_t"]))
    elif f.lighting is False:
        body.append(pick(T["lighting_f"]))
    if f.prohibited_activity:
        body.append(pick(T["prohibited"]))

    n_distract = int(style.get("distractors", 0))
    if n_distract:
        body += rng.sample(T["distractors"], k=min(n_distract, len(T["distractors"])))
    if style.get("order") == "shuffled":
        rng.shuffle(body)
    closing = pick(T["closing"])
    sep = " " if lang == "en" else ""
    text = sep.join(head + body + ([closing] if closing else []))
    return text.replace("..", ".")
