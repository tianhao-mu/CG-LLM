"""
Synthetic but geographically grounded world for the benchmark: operation
sites in Nanshan / Bao'an (Shenzhen), operators and a UAS catalogue.

Site coordinates are approximate landmark locations; UAS masses are
approximate public figures rounded for the experiment. Operators are fictitious.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Site:
    key: str
    en: str
    zh: str
    lon: float
    lat: float


SITES = [
    Site("talent_park", "Shenzhen Talent Park", "深圳人才公园", 113.9510, 22.5240),
    Site("science_park", "Nanshan Hi-Tech Science Park", "南山高新科技园", 113.9470, 22.5410),
    Site("houhai", "Houhai CBD", "后海中心区", 113.9380, 22.5160),
    Site("qianhai", "Qianhai Free Trade Zone", "前海自贸区", 113.8990, 22.5360),
    Site("sea_world", "Shekou Sea World", "蛇口海上世界", 113.9160, 22.4830),
    Site("nantou", "Nantou Ancient Town", "南头古城", 113.9230, 22.5420),
    Site("univ_town", "Xili University Town", "西丽大学城", 113.9760, 22.5830),
    Site("tanglang", "Tanglang Mountain Park", "塘朗山郊野公园", 113.9900, 22.5650),
    Site("dachong", "Dachong Business Centre", "大冲商务中心", 113.9560, 22.5470),
    Site("binhai", "Shenzhen Bay Coastal Park", "深圳湾滨海公园", 113.9650, 22.5150),
    Site("xixiang", "Xixiang Industrial Area", "西乡工业区", 113.8650, 22.5800),
    Site("baoan_center", "Bao'an Central District", "宝安中心区", 113.8830, 22.5560),
    Site("tiezai", "Tiezai Mountain Park", "铁仔山公园", 113.8560, 22.5960),
    Site("fuyong", "Fuyong Logistics Park", "福永物流园", 113.8250, 22.6800),
    Site("songgang", "Songgang Farmland", "松岗农田片区", 113.8400, 22.7700),
    Site("shiyan", "Shiyan Orchards", "石岩果园", 113.9300, 22.6800),
]

SITE_BY_KEY = {s.key: s for s in SITES}


@dataclass(frozen=True)
class Operator:
    en: str
    zh: str
    kind: str  # entity | individual


OPERATORS = [
    Operator("Pengcheng Aerial Imaging Co., Ltd.", "鹏城航拍科技有限公司", "entity"),
    Operator("Bayview Drone Logistics Co., Ltd.", "湾景无人机物流有限公司", "entity"),
    Operator("Nanshan Urban Survey Institute", "南山城市测绘院", "entity"),
    Operator("Lingyun Power Inspection Services Co., Ltd.", "凌云电力巡检服务有限公司", "entity"),
    Operator("Greenfield Agri-Tech Co., Ltd.", "绿野农业科技有限公司", "entity"),
    Operator("Shenzhen Coastal Environmental Monitoring Centre", "深圳滨海环境监测中心", "entity"),
    Operator("Skylight Performance Studio Co., Ltd.", "天幕灯光表演工作室有限公司", "entity"),
    Operator("Harbour Emergency Rescue Team", "港湾应急救援队", "entity"),
    Operator("Qianhai Flight Training Academy", "前海飞行培训学校", "entity"),
    Operator("Airport Facilities Maintenance Department", "机场设施维护部", "entity"),
    Operator("Mr. Li Wei", "李伟先生", "individual"),
    Operator("Ms. Chen Xiaoyu", "陈晓雨女士", "individual"),
    Operator("Mr. Zhang Hao", "张浩先生", "individual"),
]


@dataclass(frozen=True)
class UAS:
    model: str
    mtow_kg: float


UAS_CATALOG = {
    "micro": [UAS("DJI Mini 4 Pro", 0.249), UAS("DJI Mini 3", 0.248)],
    "light": [UAS("DJI Air 3", 0.72), UAS("DJI Mavic 3 Enterprise", 1.05), UAS("Autel EVO Max 4T", 1.6),
              UAS("DJI Matrice 30T", 4.0), UAS("DJI Inspire 3", 4.3)],
    "small": [UAS("DJI Matrice 350 RTK", 9.2), UAS("Meituan M4 delivery drone", 12.5),
              UAS("Freefly Alta X", 18.0)],
    "medium": [UAS("DJI Agras T50", 92.0), UAS("DJI FlyCart 30", 95.0), UAS("XAG P100 Pro", 88.0),
               UAS("Antwork TR9", 30.0)],
    "large": [UAS("Heavy-lift cargo UAS HL-200 (synthetic)", 210.0)],
}

PURPOSE_TEXT = {
    "aerial_photography": ("aerial photography and filming", "航拍摄影"),
    "delivery": ("parcel delivery", "物流配送"),
    "infrastructure_inspection": ("inspection of the facility we operate", "对我方运营设施的巡检"),
    "airport_inspection": ("inspection and calibration of airport navigation facilities", "机场导航设施巡检与校验"),
    "surveying": ("topographic surveying and mapping", "地形测绘"),
    "agriculture": ("crop spraying", "农作物植保喷洒"),
    "emergency_rescue": ("emergency search and rescue", "应急搜救"),
    "environmental_monitoring": ("coastal water-quality monitoring", "近岸水质监测"),
    "training": ("pilot training flights", "飞行员培训飞行"),
    "performance": ("a drone light show", "无人机灯光表演"),
    "recreation": ("recreational flying", "休闲娱乐飞行"),
}

OPERATOR_PURPOSES = {
    "Pengcheng Aerial Imaging Co., Ltd.": ["aerial_photography"],
    "Bayview Drone Logistics Co., Ltd.": ["delivery"],
    "Nanshan Urban Survey Institute": ["surveying"],
    "Lingyun Power Inspection Services Co., Ltd.": ["infrastructure_inspection"],
    "Greenfield Agri-Tech Co., Ltd.": ["agriculture"],
    "Shenzhen Coastal Environmental Monitoring Centre": ["environmental_monitoring"],
    "Skylight Performance Studio Co., Ltd.": ["performance"],
    "Harbour Emergency Rescue Team": ["emergency_rescue"],
    "Qianhai Flight Training Academy": ["training"],
    "Airport Facilities Maintenance Department": ["airport_inspection"],
    "Mr. Li Wei": ["recreation", "aerial_photography"],
    "Ms. Chen Xiaoyu": ["recreation", "aerial_photography"],
    "Mr. Zhang Hao": ["recreation"],
}

PURPOSE_UAS_CLASSES = {
    "aerial_photography": ["light", "small"],
    "delivery": ["small", "medium"],
    "infrastructure_inspection": ["light", "small"],
    "airport_inspection": ["light", "small"],
    "surveying": ["light", "small"],
    "agriculture": ["medium"],
    "emergency_rescue": ["light", "small"],
    "environmental_monitoring": ["light", "small"],
    "training": ["light", "small"],
    "performance": ["light"],
    "recreation": ["micro", "light"],
}

PURPOSE_MODELS = {
    "delivery": ["Meituan M4 delivery drone", "DJI FlyCart 30", "Antwork TR9"],
    "agriculture": ["DJI Agras T50", "XAG P100 Pro"],
}
SPECIAL_MODELS = {m for ms in PURPOSE_MODELS.values() for m in ms}
PURPOSE_SITES = {"agriculture": ["songgang", "shiyan"]}

BACKGROUND_OPERATORS = ["SZ Express Air", "Coastline Mapping", "Metro Inspection Unit", "Harbour Patrol",
                        "Bay Media", "Qianhai Logistics", "Urban Air Lab", "City Grid Survey"]
