"""
Global configuration management.

Priority: environment variable > .env file > default value.
"""

import os
from pathlib import Path
from typing import Optional

from dotenv import load_dotenv

# Load .env file
load_dotenv()

# Project root directory
PROJECT_ROOT = Path(__file__).resolve().parent.parent


class Settings:
    """Application configuration."""

    # --- LLM ---
    DEEPSEEK_API_KEY: str = os.getenv("DEEPSEEK_API_KEY", "")
    DEEPSEEK_BASE_URL: str = os.getenv(
        "DEEPSEEK_BASE_URL", "https://api.deepseek.com"
    )
    DEEPSEEK_MODEL: str = os.getenv("DEEPSEEK_MODEL", "deepseek-chat")

    # --- Embedding ---
    EMBEDDING_MODEL: str = os.getenv("EMBEDDING_MODEL", "BAAI/bge-m3")
    EMBEDDING_DEVICE: str = os.getenv("EMBEDDING_DEVICE", "cpu")

    # --- Storage ---
    CHROMA_PERSIST_DIR: str = os.getenv(
        "CHROMA_PERSIST_DIR",
        str(PROJECT_ROOT / "data" / "chroma_db"),
    )
    REGULATION_COLLECTION: str = os.getenv(
        "REGULATION_COLLECTION", "regulations"
    )
    AIRSPACE_DB_PATH: str = os.getenv(
        "AIRSPACE_DB_PATH",
        str(PROJECT_ROOT / "data" / "airspace_state.db"),
    )

    # --- Agent ---
    MAX_AGENT_STEPS: int = int(os.getenv("MAX_AGENT_STEPS", "10"))
    LLM_TEMPERATURE: float = float(os.getenv("LLM_TEMPERATURE", "0.3"))
    LLM_MAX_TOKENS: int = int(os.getenv("LLM_MAX_TOKENS", "2048"))

    @classmethod
    def validate(cls) -> list[str]:
        """Validate critical configuration; return list of missing items."""
        missing = []
        if not cls.DEEPSEEK_API_KEY:
            missing.append("DEEPSEEK_API_KEY")
        return missing

    @classmethod
    def summary(cls) -> str:
        lines = [
            "Configuration:",
            f"  LLM: {cls.DEEPSEEK_MODEL} @ {cls.DEEPSEEK_BASE_URL}",
            f"  Embedding: {cls.EMBEDDING_MODEL} on {cls.EMBEDDING_DEVICE}",
            f"  Chroma: {cls.CHROMA_PERSIST_DIR}",
            f"  Airspace DB: {cls.AIRSPACE_DB_PATH}",
        ]
        missing = cls.validate()
        if missing:
            lines.append(f"  WARNING — Missing: {', '.join(missing)}")
        return "\n".join(lines)


settings = Settings()
