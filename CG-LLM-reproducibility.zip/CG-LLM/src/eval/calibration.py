"""Calibration and selective-prediction metrics."""

from __future__ import annotations

from typing import Sequence

import numpy as np


def ece(conf: Sequence[float], correct: Sequence[bool], n_bins: int = 10) -> float:
    c, y = np.asarray(conf, float), np.asarray(correct, float)
    if len(c) == 0:
        return float("nan")
    bins = np.linspace(0, 1, n_bins + 1)
    idx = np.clip(np.digitize(c, bins[1:-1]), 0, n_bins - 1)
    total = 0.0
    for b in range(n_bins):
        m = idx == b
        if m.any():
            total += m.mean() * abs(y[m].mean() - c[m].mean())
    return float(total)


def reliability(conf: Sequence[float], correct: Sequence[bool], n_bins: int = 10) -> list[dict]:
    c, y = np.asarray(conf, float), np.asarray(correct, float)
    bins = np.linspace(0, 1, n_bins + 1)
    idx = np.clip(np.digitize(c, bins[1:-1]), 0, n_bins - 1)
    out = []
    for b in range(n_bins):
        m = idx == b
        out.append({"bin_lo": bins[b], "bin_hi": bins[b + 1], "n": int(m.sum()),
                    "conf": float(c[m].mean()) if m.any() else None, "acc": float(y[m].mean()) if m.any() else None})
    return out


def risk_coverage(conf: Sequence[float], correct: Sequence[bool]) -> dict:
    """Risk-coverage curve when abstaining on the lowest-confidence cases first."""
    c, y = np.asarray(conf, float), np.asarray(correct, float)
    if len(c) == 0:
        return {"coverage": [], "risk": [], "aurc": float("nan")}
    order = np.argsort(-c, kind="stable")
    y_sorted = y[order]
    n = len(y)
    coverage = np.arange(1, n + 1) / n
    risk = np.cumsum(1 - y_sorted) / np.arange(1, n + 1)
    trapz = getattr(np, "trapezoid", None) or np.trapz
    return {"coverage": coverage.tolist(), "risk": risk.tolist(), "aurc": float(trapz(risk, coverage))}
