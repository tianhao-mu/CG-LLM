"""
Evaluation metrics over pipeline result records.

Gold labels are APPROVE / MODIFY / REJECT (decisive cases) plus ESCALATE
(incomplete requests). A predicted ESCALATE on a decisive case is an
abstention: it counts as an error for accuracy but not as an unsafe one.
"""

from __future__ import annotations

from collections import Counter, defaultdict
from typing import Iterable, Sequence

import numpy as np

LABELS = ("APPROVE", "MODIFY", "REJECT")
ALL_PRED = ("APPROVE", "MODIFY", "REJECT", "ESCALATE", "INVALID")
PERMISSIVENESS = {"APPROVE": 2, "MODIFY": 1, "REJECT": 0}

# (gold, pred) -> cost. Unsafe errors are expensive; over-conservative cheap.
COSTS = {("REJECT", "APPROVE"): 10, ("REJECT", "MODIFY"): 5, ("MODIFY", "APPROVE"): 3,
         ("APPROVE", "REJECT"): 2, ("APPROVE", "MODIFY"): 1, ("MODIFY", "REJECT"): 1}
ESCALATE_COST = 0.5
INVALID_COST = 1.0

FACT_FIELDS = ["operator_type", "commercial", "purpose", "mtow_kg", "real_name_registered", "operation_certificate",
               "pilot_license", "agri_operating_certificate", "liability_insurance", "airworthiness_certificate",
               "survey_qualification", "altitude_min_m", "altitude_max_m", "time_start", "time_end", "emergency",
               "bvlos", "daa_capability", "lighting", "prohibited_activity"]


def pred_label(r: dict) -> str:
    d = r.get("decision")
    return d if d in ALL_PRED[:4] else "INVALID"


def is_correct(r: dict) -> bool:
    return pred_label(r) == r["gold_decision"]


def decision_cost(gold: str, pred: str) -> float:
    if pred == gold:
        return 0.0
    if pred == "ESCALATE":
        return ESCALATE_COST
    if pred == "INVALID":
        return INVALID_COST
    if gold == "ESCALATE":
        return 3.0 if pred == "APPROVE" else 1.0
    return float(COSTS.get((gold, pred), 1.0))


def _div(a: float, b: float) -> float:
    return a / b if b else float("nan")


def accuracy(records: Sequence[dict]) -> float:
    return _div(sum(is_correct(r) for r in records), len(records))


def decisive(records: Iterable[dict]) -> list[dict]:
    return [r for r in records if r["gold_decision"] in LABELS]


def macro_f1(records: Sequence[dict]) -> float:
    recs = decisive(records)
    f1s = []
    for c in LABELS:
        tp = sum(1 for r in recs if r["gold_decision"] == c and pred_label(r) == c)
        fp = sum(1 for r in recs if r["gold_decision"] != c and pred_label(r) == c)
        fn = sum(1 for r in recs if r["gold_decision"] == c and pred_label(r) != c)
        p, q = _div(tp, tp + fp), _div(tp, tp + fn)
        f1s.append(0.0 if not (p == p and q == q) or p + q == 0 else 2 * p * q / (p + q))
    return float(np.mean(f1s))


def unsafe_permissive_rate(records: Sequence[dict]) -> float:
    recs = [r for r in decisive(records) if r["gold_decision"] in ("MODIFY", "REJECT")]
    bad = sum(1 for r in recs if pred_label(r) in PERMISSIVENESS
              and PERMISSIVENESS[pred_label(r)] > PERMISSIVENESS[r["gold_decision"]])
    return _div(bad, len(recs))


def over_conservative_rate(records: Sequence[dict]) -> float:
    recs = [r for r in decisive(records) if r["gold_decision"] in ("APPROVE", "MODIFY")]
    bad = sum(1 for r in recs if pred_label(r) in PERMISSIVENESS
              and PERMISSIVENESS[pred_label(r)] < PERMISSIVENESS[r["gold_decision"]])
    return _div(bad, len(recs))


def mean_cost(records: Sequence[dict]) -> float:
    return _div(sum(decision_cost(r["gold_decision"], pred_label(r)) for r in records), len(records))


def escalation_stats(records: Sequence[dict]) -> dict:
    dec = decisive(records)
    esc = [r for r in dec if pred_label(r) == "ESCALATE"]
    caught = [r for r in esc if r.get("pre_escalation_decision") not in (None, r["gold_decision"])]
    kept = [r for r in dec if pred_label(r) != "ESCALATE"]
    inc = [r for r in records if r["gold_decision"] == "ESCALATE"]
    return {
        "coverage": _div(len(kept), len(dec)),
        "escalation_rate": _div(len(esc), len(dec)),
        "escalation_precision": _div(len(caught), len(esc)),
        "selective_accuracy": _div(sum(is_correct(r) for r in kept), len(kept)),
        "incomplete_recall": _div(sum(pred_label(r) == "ESCALATE" for r in inc), len(inc)),
        "pre_escalation_accuracy": _div(sum(r.get("pre_escalation_decision") == r["gold_decision"] for r in dec), len(dec)),
    }


def confusion(records: Sequence[dict]) -> dict:
    m = {g: {p: 0 for p in ALL_PRED} for g in LABELS + ("ESCALATE",)}
    for r in records:
        m[r["gold_decision"]][pred_label(r)] += 1
    return m


def set_prf(pred: Iterable[str], gold: Iterable[str]) -> tuple[float, float, float]:
    p, g = set(pred), set(gold)
    if not p and not g:
        return 1.0, 1.0, 1.0
    tp = len(p & g)
    prec, rec = _div(tp, len(p)), _div(tp, len(g))
    prec = 0.0 if prec != prec else prec
    rec = 0.0 if rec != rec else rec
    f = 0.0 if prec + rec == 0 else 2 * prec * rec / (prec + rec)
    return prec, rec, f


def citation_stats(records: Sequence[dict], cases: dict, corpus_ids: set[str]) -> dict:
    ps, rs, fs, halluc, n_cited, empty = [], [], [], 0, 0, 0
    for r in records:
        c = cases.get(r["case_id"])
        if c is None or r["gold_decision"] == "ESCALATE":
            continue
        cited = r.get("cited_articles") or []
        if not cited:
            empty += 1
        n_cited += len(cited)
        halluc += sum(1 for a in cited if a not in corpus_ids)
        p, q, f = set_prf(cited, c.gold.articles)
        ps.append(p), rs.append(q), fs.append(f)
    return {"citation_precision": float(np.mean(ps)) if ps else float("nan"),
            "citation_recall": float(np.mean(rs)) if rs else float("nan"),
            "citation_f1": float(np.mean(fs)) if fs else float("nan"),
            "hallucinated_citation_rate": _div(halluc, n_cited),
            "no_citation_rate": _div(empty, len(ps))}


def trigger_stats(records: Sequence[dict], cases: dict) -> dict:
    fs, exact = [], []
    for r in records:
        c = cases.get(r["case_id"])
        if c is None or r["gold_decision"] == "ESCALATE":
            continue
        pred = [v for v in (r.get("violated_constraints") or []) if str(v).startswith("C")]
        pred = [v.split()[0].strip(",;:") for v in pred]
        _, _, f = set_prf(pred, c.gold.trigger_ids)
        fs.append(f)
        exact.append(set(pred) == set(c.gold.trigger_ids))
    return {"trigger_f1": float(np.mean(fs)) if fs else float("nan"),
            "trigger_exact": float(np.mean(exact)) if exact else float("nan")}


def modification_stats(records: Sequence[dict], cases: dict) -> dict:
    """Validity of proposed modifications on cases whose gold decision needs a geometric change."""
    valid, rel_cost, n = [], [], 0
    for r in records:
        c = cases.get(r["case_id"])
        if c is None or c.gold.modification is None or pred_label(r) != "MODIFY":
            continue
        n += 1
        chk = r.get("modification_check") or {}
        ok = bool(chk.get("valid"))
        valid.append(ok)
        if ok and c.gold.modification.get("cost"):
            rel_cost.append(chk.get("cost", np.nan) / c.gold.modification["cost"])
    return {"modification_n": n, "modification_validity": float(np.mean(valid)) if valid else float("nan"),
            "modification_rel_cost": float(np.nanmedian(rel_cost)) if rel_cost else float("nan")}


def _field_equal(field: str, a, b) -> bool:
    if a is None or b is None:
        return a is None and b is None
    if field in ("mtow_kg",):
        return abs(float(a) - float(b)) <= max(0.01, 0.02 * abs(float(b)))
    if field in ("altitude_min_m", "altitude_max_m"):
        return abs(float(a) - float(b)) <= 1.0
    if field in ("time_start", "time_end"):
        return str(a)[:16] == str(b)[:16]
    return a == b


def extraction_stats(records: Sequence[dict], cases: dict) -> dict:
    per_field = defaultdict(list)
    all_ok = []
    for r in records:
        c = cases.get(r["case_id"])
        if c is None or not r.get("facts"):
            continue
        ok_case = True
        for f in FACT_FIELDS:
            ok = _field_equal(f, r["facts"].get(f), c.gold.facts.get(f))
            per_field[f].append(ok)
            ok_case &= ok
        all_ok.append(ok_case)
    return {"extraction_case_exact": float(np.mean(all_ok)) if all_ok else float("nan"),
            "extraction_field_acc": {f: float(np.mean(v)) for f, v in per_field.items()}}


def consistency(records: Sequence[dict]) -> dict:
    from src.eval.stats import fleiss_kappa
    by_case = defaultdict(list)
    for r in records:
        by_case[r["case_id"]].append(pred_label(r))
    multi = [v for v in by_case.values() if len(v) > 1]
    if not multi:
        return {"consistency": float("nan"), "fleiss_kappa_repeats": float("nan")}
    agree = [Counter(v).most_common(1)[0][1] / len(v) for v in multi]
    return {"consistency": float(np.mean(agree)), "all_repeats_identical": float(np.mean([a == 1.0 for a in agree])),
            "fleiss_kappa_repeats": fleiss_kappa(multi)}


def summarize(records: Sequence[dict], cases: dict | None = None, corpus_ids: set[str] | None = None) -> dict:
    cases = cases or {}
    out = {"n": len(records), "n_cases": len({r["case_id"] for r in records}),
           "accuracy": accuracy(records), "decisive_accuracy": accuracy(decisive(records)),
           "macro_f1": macro_f1(records), "unsafe_permissive_rate": unsafe_permissive_rate(records),
           "over_conservative_rate": over_conservative_rate(records), "mean_cost": mean_cost(records),
           "invalid_rate": _div(sum(pred_label(r) == "INVALID" for r in records), len(records)),
           "error_rate": _div(sum(bool(r.get("error")) for r in records), len(records))}
    out.update(escalation_stats(records))
    if cases:
        out.update(trigger_stats(records, cases))
        out.update(modification_stats(records, cases))
        ex = extraction_stats(records, cases)
        out["extraction_case_exact"] = ex["extraction_case_exact"]
        if corpus_ids is not None:
            out.update(citation_stats(records, cases, corpus_ids))
    out.update(consistency(records))
    for k in ("prompt_tokens", "completion_tokens", "cost_cny", "llm_latency_s", "n_calls"):
        vals = [r.get(k, 0) or 0 for r in records]
        out[f"mean_{k}"] = float(np.mean(vals)) if vals else float("nan")
    confs = [r.get("confidence") for r in records]
    if any(c is not None for c in confs):
        from src.eval.calibration import ece, risk_coverage
        pairs = [(c, is_correct(r)) for c, r in zip(confs, records) if c is not None and r["gold_decision"] in LABELS]
        if pairs:
            cs, ys = zip(*pairs)
            out["ece"] = ece(cs, ys)
            out["aurc"] = risk_coverage(cs, ys)["aurc"]
    return out
