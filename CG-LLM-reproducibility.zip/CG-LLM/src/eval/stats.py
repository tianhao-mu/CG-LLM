"""Statistical utilities: confidence intervals, paired tests, agreement."""

from __future__ import annotations

import math
from collections import Counter, defaultdict
from typing import Callable, Hashable, Sequence

import numpy as np
from scipy import stats as sps


def wilson_ci(k: int, n: int, alpha: float = 0.05) -> tuple[float, float]:
    if n == 0:
        return (float("nan"), float("nan"))
    z = sps.norm.ppf(1 - alpha / 2)
    p = k / n
    denom = 1 + z * z / n
    centre = (p + z * z / (2 * n)) / denom
    half = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / denom
    return (max(0.0, centre - half), min(1.0, centre + half))


def cluster_bootstrap(records: Sequence[dict], metric: Callable[[Sequence[dict]], float], cluster_key: str = "case_id",
                      n_boot: int = 2000, seed: int = 0, alpha: float = 0.05) -> tuple[float, float, float]:
    """Point estimate and percentile CI, resampling whole cases (all repeats together)."""
    groups: dict[Hashable, list[dict]] = defaultdict(list)
    for r in records:
        groups[r[cluster_key]].append(r)
    keys = list(groups)
    point = metric(records)
    if not keys:
        return point, float("nan"), float("nan")
    rng = np.random.default_rng(seed)
    vals = []
    for _ in range(n_boot):
        sample = [r for i in rng.integers(0, len(keys), len(keys)) for r in groups[keys[i]]]
        v = metric(sample)
        if v == v:
            vals.append(v)
    if not vals:
        return point, float("nan"), float("nan")
    lo, hi = np.percentile(vals, [100 * alpha / 2, 100 * (1 - alpha / 2)])
    return point, float(lo), float(hi)


def mcnemar_exact(a_correct: Sequence[bool], b_correct: Sequence[bool]) -> dict:
    """Exact (binomial) McNemar test on paired per-case correctness."""
    b = sum(1 for x, y in zip(a_correct, b_correct) if x and not y)
    c = sum(1 for x, y in zip(a_correct, b_correct) if y and not x)
    n = b + c
    p = 1.0 if n == 0 else min(1.0, 2 * sps.binom.cdf(min(b, c), n, 0.5))
    return {"a_only": b, "b_only": c, "p_value": float(p)}


def holm(pvals: dict[str, float]) -> dict[str, float]:
    items = sorted(pvals.items(), key=lambda kv: kv[1])
    m, out, running = len(items), {}, 0.0
    for i, (k, p) in enumerate(items):
        running = max(running, min(1.0, (m - i) * p))
        out[k] = running
    return out


def cohen_kappa(a: Sequence[Hashable], b: Sequence[Hashable]) -> float:
    n = len(a)
    if n == 0:
        return float("nan")
    po = sum(x == y for x, y in zip(a, b)) / n
    ca, cb = Counter(a), Counter(b)
    pe = sum(ca[k] * cb.get(k, 0) for k in ca) / (n * n)
    return 1.0 if pe == 1 else (po - pe) / (1 - pe)


def fleiss_kappa(ratings: Sequence[Sequence[Hashable]]) -> float:
    """``ratings[i]`` = labels given to item i by its raters (equal count per item)."""
    ratings = [r for r in ratings if len(r) >= 2]
    if not ratings:
        return float("nan")
    cats = sorted({x for r in ratings for x in r}, key=str)
    n = len(ratings[0])
    ratings = [r for r in ratings if len(r) == n]
    N = len(ratings)
    counts = np.array([[r.count(c) for c in cats] for r in ratings], dtype=float)
    p_j = counts.sum(0) / (N * n)
    P_i = ((counts ** 2).sum(1) - n) / (n * (n - 1))
    Pbar, Pe = P_i.mean(), (p_j ** 2).sum()
    return 1.0 if Pe == 1 else float((Pbar - Pe) / (1 - Pe))
