"""
Projection between WGS-84 lon/lat and a metric plane.

All distances and areas are computed in CGCS2000 / 3-degree Gauss-Kruger
CM 114E (EPSG:4547), whose distortion over Shenzhen is well below 0.01 %.
"""

from __future__ import annotations

from functools import lru_cache
from typing import Sequence

from pyproj import Transformer
from shapely.geometry import Polygon
from shapely.ops import transform

METRIC_CRS = "EPSG:4547"


@lru_cache(maxsize=4)
def _forward(crs: str = METRIC_CRS) -> Transformer:
    return Transformer.from_crs("EPSG:4326", crs, always_xy=True)


@lru_cache(maxsize=4)
def _inverse(crs: str = METRIC_CRS) -> Transformer:
    return Transformer.from_crs(crs, "EPSG:4326", always_xy=True)


def to_metric(geom, crs: str = METRIC_CRS):
    """Project a lon/lat shapely geometry to metres."""
    return transform(_forward(crs).transform, geom)


def to_lonlat(geom, crs: str = METRIC_CRS):
    """Project a metric shapely geometry back to lon/lat."""
    return transform(_inverse(crs).transform, geom)


def polygon_lonlat_to_metric(coords: Sequence[Sequence[float]], crs: str = METRIC_CRS) -> Polygon:
    """Build a metric polygon from ``[[lon, lat], ...]`` coordinates."""
    poly = Polygon([(float(x), float(y)) for x, y in coords])
    metric = to_metric(poly, crs)
    if not metric.is_valid:
        metric = metric.buffer(0)
    return metric


def offset_lonlat(lon: float, lat: float, dx_m: float, dy_m: float, crs: str = METRIC_CRS) -> tuple[float, float]:
    """Move a lon/lat point by (dx, dy) metres."""
    x, y = _forward(crs).transform(lon, lat)
    return _inverse(crs).transform(x + dx_m, y + dy_m)


def rectangle_lonlat(lon: float, lat: float, width_m: float, height_m: float,
                     crs: str = METRIC_CRS) -> list[list[float]]:
    """Axis-aligned rectangle (in metres) centred on a lon/lat point."""
    x, y = _forward(crs).transform(lon, lat)
    hw, hh = width_m / 2, height_m / 2
    inv = _inverse(crs)
    corners = [(x - hw, y - hh), (x + hw, y - hh), (x + hw, y + hh), (x - hw, y + hh), (x - hw, y - hh)]
    return [[round(c, 7) for c in inv.transform(cx, cy)] for cx, cy in corners]
