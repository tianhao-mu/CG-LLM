"""Thread-safe sqlite cache for LLM responses."""

from __future__ import annotations

import hashlib
import json
import sqlite3
import threading
from pathlib import Path


def cache_key(**parts) -> str:
    blob = json.dumps(parts, sort_keys=True, ensure_ascii=False, default=str)
    return hashlib.sha256(blob.encode("utf-8")).hexdigest()


class ResponseCache:
    def __init__(self, path: Path | str):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self._conn = sqlite3.connect(str(self.path), check_same_thread=False, timeout=60)
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("CREATE TABLE IF NOT EXISTS responses (key TEXT PRIMARY KEY, payload TEXT NOT NULL, "
                           "created TEXT DEFAULT CURRENT_TIMESTAMP)")
        self._conn.execute("CREATE TABLE IF NOT EXISTS usage (model TEXT PRIMARY KEY, prompt_tokens INTEGER NOT NULL, "
                           "completion_tokens INTEGER NOT NULL)")
        self._conn.commit()

    def add_usage(self, model: str, prompt_tokens: int, completion_tokens: int) -> None:
        with self._lock:
            self._conn.execute("INSERT INTO usage VALUES (?, ?, ?) ON CONFLICT(model) DO UPDATE SET "
                               "prompt_tokens = prompt_tokens + excluded.prompt_tokens, "
                               "completion_tokens = completion_tokens + excluded.completion_tokens",
                               (model, prompt_tokens, completion_tokens))
            self._conn.commit()

    def total_usage(self, model: str) -> int:
        with self._lock:
            row = self._conn.execute("SELECT prompt_tokens + completion_tokens FROM usage WHERE model=?", (model,)).fetchone()
        return int(row[0]) if row else 0

    def get(self, key: str) -> dict | None:
        with self._lock:
            row = self._conn.execute("SELECT payload FROM responses WHERE key=?", (key,)).fetchone()
        return json.loads(row[0]) if row else None

    def put(self, key: str, payload: dict) -> None:
        with self._lock:
            self._conn.execute("INSERT OR REPLACE INTO responses (key, payload) VALUES (?, ?)",
                               (key, json.dumps(payload, ensure_ascii=False)))
            self._conn.commit()

    def __len__(self) -> int:
        with self._lock:
            return self._conn.execute("SELECT COUNT(*) FROM responses").fetchone()[0]
