"""
LLM client abstract interface.
"""

from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional


class LLMClient(ABC):
    """Abstract base class for LLM clients. Supports backend switching for ablation studies."""

    @abstractmethod
    def chat(
        self,
        messages: List[Dict[str, str]],
        temperature: float = 0.3,
        max_tokens: int = 2048,
        **kwargs,
    ) -> str:
        """Send a chat request and return the text response."""
        ...

    @abstractmethod
    def chat_with_tools(
        self,
        messages: List[Dict[str, str]],
        tools: List[Dict[str, Any]],
        temperature: float = 0.3,
        max_tokens: int = 2048,
        **kwargs,
    ) -> Dict[str, Any]:
        """Send a function-calling request; returns the full response including tool_calls."""
        ...
