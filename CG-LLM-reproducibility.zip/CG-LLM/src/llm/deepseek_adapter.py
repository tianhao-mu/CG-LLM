"""
DeepSeek API adapter (OpenAI-compatible protocol).
"""

import logging
from typing import Any, Dict, List, Optional

from openai import OpenAI

from src.llm.client import LLMClient

logger = logging.getLogger(__name__)


class DeepSeekAdapter(LLMClient):
    """DeepSeek API client using the OpenAI-compatible interface."""

    def __init__(
        self,
        api_key: str,
        base_url: str = "https://api.deepseek.com",
        model: str = "deepseek-chat",
    ):
        self.model = model
        self.client = OpenAI(
            api_key=api_key,
            base_url=base_url,
        )
        logger.info(f"DeepSeekAdapter initialized: model={model}, base_url={base_url}")

    def chat(
        self,
        messages: List[Dict[str, str]],
        temperature: float = 0.3,
        max_tokens: int = 2048,
        **kwargs,
    ) -> str:
        """Single-turn chat: send messages and return the text content."""
        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=messages,  # type: ignore
                temperature=temperature,
                max_tokens=max_tokens,
                **kwargs,
            )
            content = response.choices[0].message.content or ""
            logger.debug(
                f"Chat response: {len(content)} chars, "
                f"usage={response.usage}"
            )
            return content

        except Exception as e:
            logger.error(f"DeepSeek chat error: {e}")
            raise

    def chat_with_tools(
        self,
        messages: List[Dict[str, str]],
        tools: List[Dict[str, Any]],
        temperature: float = 0.3,
        max_tokens: int = 2048,
        **kwargs,
    ) -> Dict[str, Any]:
        """Chat with function-calling support."""
        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=messages,  # type: ignore
                tools=tools,  # type: ignore
                temperature=temperature,
                max_tokens=max_tokens,
                **kwargs,
            )
            choice = response.choices[0]
            result: Dict[str, Any] = {
                "content": choice.message.content or "",
                "role": choice.message.role,
            }

            # Parse tool_calls
            if choice.message.tool_calls:
                result["tool_calls"] = [
                    {
                        "id": tc.id,
                        "name": tc.function.name,
                        "arguments": tc.function.arguments,
                    }
                    for tc in choice.message.tool_calls
                ]

            logger.debug(
                f"ChatWithTools response: has_tool_calls="
                f"{'tool_calls' in result}, usage={response.usage}"
            )
            return result

        except Exception as e:
            logger.error(f"DeepSeek chat_with_tools error: {e}")
            raise
