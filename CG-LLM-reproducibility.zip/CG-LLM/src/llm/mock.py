"""
Deterministic offline stand-in for a chat model.

Routes on the ``[TASK:...]`` tag of the system prompt and returns well-formed
outputs so every pipeline can be exercised end to end without an API key.
Its decisions carry no scientific meaning.
"""

from __future__ import annotations

import json
import random
import re
from datetime import datetime, timedelta


def _user(messages: list[dict]) -> str:
    return next((m["content"] for m in messages if m["role"] == "user"), "")


def _application(text: str) -> str:
    m = re.search(r"Application text:\n(.*?)(?:\n\n[A-Z][\w ]+:\n|\Z)", text, re.S)
    return m.group(1).strip() if m else text


def _extract(messages, rng: random.Random, noisy: bool) -> str:
    from src.pipelines.regex_extract import regex_extract
    app = _application(_user(messages))
    facts = regex_extract(app).to_json_dict()
    for k in ("time_start", "time_end"):
        if facts.get(k):
            facts[k] = facts[k][:16]
    if noisy and rng.random() < 0.3:
        k = rng.choice(["altitude_max_m", "liability_insurance", "pilot_license", "time_end", "real_name_registered"])
        if isinstance(facts.get(k), bool):
            facts[k] = not facts[k]
        elif isinstance(facts.get(k), float):
            facts[k] = facts[k] + 30
        else:
            facts[k] = None
    return json.dumps(facts, ensure_ascii=False)


def _decision(rng: random.Random) -> dict:
    d = rng.choice(["APPROVE", "MODIFY", "REJECT", "REJECT", "MODIFY"])
    return {"decision": d, "confidence": round(rng.uniform(0.5, 0.99), 2), "violated_constraints": [],
            "cited_articles": ["IR-2023:19"] if rng.random() < 0.7 else ["IR-2023:99"],
            "modification": None, "conditions": [], "explanation": f"Mock decision {d}."}


def respond(messages: list[dict], seed: int = 0, model: str = "mock-v1") -> str:
    rng = random.Random(seed)
    noisy = "noisy" in model
    system = messages[0]["content"] if messages else ""
    tag = re.match(r"\[TASK:(\w+)\]", system)
    tag = tag.group(1) if tag else ""
    user = _user(messages)

    if tag == "EXTRACT":
        return _extract(messages, rng, noisy)
    if tag == "REVIEW":
        m = re.search(r"Engine decision: (\w+)", user)
        eng = m.group(1) if m else "APPROVE"
        agree = rng.random() < (0.75 if noisy else 0.92)
        cites = re.findall(r"\[([A-Z0-9\-]+:[\w.]+)\]", system)[:2]
        return json.dumps({"decision": eng if agree else rng.choice(["APPROVE", "REJECT"]),
                           "extraction_errors": [] if agree else [{"field": "altitude_max_m", "correct_value": 200}],
                           "confidence": round(rng.uniform(0.6, 0.99), 2),
                           "cited_articles": cites, "explanation": f"The engine decision {eng} is consistent with the cited articles."})
    if tag == "SEPARATION":
        ops = re.findall(r"- (OP-\d+):", user)
        conflicts = [{"op_id": o, "severity": rng.choice(["LOW", "MEDIUM", "HIGH"])} for o in ops if rng.random() < 0.3]
        return json.dumps({"conflicts": conflicts})
    if tag == "MODIFY":
        m = re.search(r"Extracted facts:\n(\{.*?\})\n", user, re.S)
        f = json.loads(m.group(1)) if m else {}
        shift = timedelta(minutes=rng.choice([20, 30, 60]))
        out = {"altitude_min_m": f.get("altitude_min_m"), "altitude_max_m": min(120, f.get("altitude_max_m") or 120),
               "rationale": "mock"}
        for k in ("time_start", "time_end"):
            if f.get(k):
                out[k] = (datetime.fromisoformat(f[k]) + shift).isoformat(timespec="minutes")
        return json.dumps(out)
    if tag == "REACT":
        n_obs = sum("Observation:" in m["content"] for m in messages if m["role"] == "user")
        if n_obs == 0:
            from src.pipelines.regex_extract import regex_extract
            f = regex_extract(_application(user)).to_json_dict()
            return json.dumps({"thought": "check separation", "action": "check_separation",
                               "args": {k: (f.get(k) or "")[:16] if k.startswith("time") else f.get(k)
                                        for k in ("altitude_min_m", "altitude_max_m", "time_start", "time_end")}})
        if n_obs == 1:
            return json.dumps({"thought": "look up rules", "action": "search_regulations",
                               "args": {"query": "controlled airspace approval altitude 120 m"}})
        return json.dumps({"thought": "decide", "final": _decision(rng)})
    if tag == "DECIDE":
        return json.dumps(_decision(rng))
    if tag == "JUDGE":
        return json.dumps({k: rng.randint(3, 5) for k in ("faithfulness", "citation_support", "actionability", "clarity")}
                          | {"unsupported_claims": []})
    if tag == "COMPILE":
        return json.dumps({"check": "altitude", "effect": "MODIFY", "params": {"ceiling_m": 120}, "articles": ["IR-2023:19"]})
    # Untagged prompts (paraphrasing): echo the passage after the instruction.
    return user.split("\n\n", 1)[-1]
