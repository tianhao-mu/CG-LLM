"""
Multi-provider OpenAI-compatible chat client.

Models are declared in experiments/configs/models.yaml. Each entry gives the
provider endpoint, the env var holding the API key, a concurrency limit, the
price per million tokens (CNY) and how to disable "thinking" for that
provider. Responses are cached in sqlite keyed by the full request, so
re-running an experiment never re-bills a call.
"""

from __future__ import annotations

import logging
import os
import random
import threading
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

import yaml

from src.llm.cache import ResponseCache, cache_key

log = logging.getLogger(__name__)

ROOT = Path(__file__).resolve().parents[2]
DEFAULT_REGISTRY = ROOT / "experiments" / "configs" / "models.yaml"
DEFAULT_CACHE = ROOT / "results" / "cache" / "llm_cache.sqlite"

RETRY_MARKERS = ("1302", "1305", "rate limit", "overloaded", "too many requests", "429", "busy", "timeout")


@dataclass
class ModelSpec:
    key: str
    provider: str
    model: str
    base_url: str = ""
    api_key_env: str = ""
    concurrency: int = 1
    price_in: float = 0.0   # CNY per 1M input tokens
    price_out: float = 0.0  # CNY per 1M output tokens
    json_mode: bool = True
    thinking_param: dict | None = None  # merged into extra_body when thinking is disabled
    thinking_on_param: dict | None = None
    max_tokens: int = 1500
    timeout_s: float = 120.0
    token_budget: int | None = None  # hard cap on billed tokens (persisted in the cache db)
    notes: str = ""


@dataclass
class LLMResponse:
    text: str
    model: str
    prompt_tokens: int = 0
    completion_tokens: int = 0
    latency_s: float = 0.0
    cost_cny: float = 0.0
    cached: bool = False
    error: str = ""
    reasoning: str = ""
    retries: int = 0
    meta: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return asdict(self)


def load_registry(path: Path | str = DEFAULT_REGISTRY) -> dict[str, ModelSpec]:
    raw = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    specs = {}
    for key, d in raw["models"].items():
        specs[key] = ModelSpec(key=key, **d)
    return specs


class LLMClient:
    def __init__(self, registry: dict[str, ModelSpec] | None = None, cache_path: Path | str | None = DEFAULT_CACHE,
                 use_cache: bool = True):
        self.registry = registry or load_registry()
        self.cache = ResponseCache(cache_path) if (use_cache and cache_path) else None
        self._clients: dict[str, Any] = {}
        self._sems: dict[str, threading.Semaphore] = {}
        self._lock = threading.Lock()
        self.usage: dict[str, dict] = {}

    # ---------------------------------------------------------------- helpers
    def spec(self, key: str) -> ModelSpec:
        if key not in self.registry:
            raise KeyError(f"model '{key}' not in registry ({', '.join(self.registry)})")
        return self.registry[key]

    def _client(self, spec: ModelSpec):
        with self._lock:
            if spec.key not in self._clients:
                from openai import OpenAI
                api_key = os.environ.get(spec.api_key_env, "") if spec.api_key_env else "none"
                if not api_key:
                    raise RuntimeError(f"environment variable {spec.api_key_env} is not set for model {spec.key}")
                self._clients[spec.key] = OpenAI(api_key=api_key, base_url=spec.base_url, timeout=spec.timeout_s,
                                                 max_retries=0)
            return self._clients[spec.key]

    def _sem(self, spec: ModelSpec) -> threading.Semaphore:
        with self._lock:
            if spec.key not in self._sems:
                self._sems[spec.key] = threading.Semaphore(max(1, spec.concurrency))
            return self._sems[spec.key]

    def _account(self, key: str, r: LLMResponse) -> None:
        with self._lock:
            u = self.usage.setdefault(key, {"calls": 0, "cached": 0, "prompt_tokens": 0, "completion_tokens": 0,
                                            "cost_cny": 0.0, "errors": 0})
            u["calls"] += 1
            u["cached"] += int(r.cached)
            u["errors"] += int(bool(r.error))
            if not r.cached:
                u["prompt_tokens"] += r.prompt_tokens
                u["completion_tokens"] += r.completion_tokens
                u["cost_cny"] += r.cost_cny

    # ---------------------------------------------------------------- main
    def chat(self, model_key: str, messages: list[dict], temperature: float = 0.0, max_tokens: int | None = None,
             json_mode: bool = False, thinking: bool = False, sample_idx: int = 0, seed: int | None = None,
             max_retries: int = 8) -> LLMResponse:
        spec = self.spec(model_key)
        max_tokens = max_tokens or spec.max_tokens
        key = cache_key(provider=spec.provider, model=spec.model, messages=messages, temperature=temperature,
                        max_tokens=max_tokens, json_mode=json_mode and spec.json_mode, thinking=thinking,
                        sample_idx=sample_idx)
        if self.cache is not None:
            hit = self.cache.get(key)
            if hit is not None and not hit.get("error"):
                r = LLMResponse(**hit)
                r.cached = True
                self._account(model_key, r)
                return r

        if spec.provider == "mock":
            from src.llm.mock import respond
            t0 = time.time()
            text = respond(messages, seed=int(key[:8], 16) ^ (seed or 0), model=spec.model)
            r = LLMResponse(text=text, model=spec.model, prompt_tokens=sum(len(m["content"]) // 4 for m in messages),
                            completion_tokens=len(text) // 4, latency_s=time.time() - t0)
        elif spec.token_budget and self.cache is not None and self.cache.total_usage(spec.model) >= spec.token_budget:
            r = LLMResponse(text="", model=spec.model,
                            error=f"BudgetExhausted: {spec.model} reached its token budget of {spec.token_budget:,}")
        else:
            r = self._call(spec, messages, temperature, max_tokens, json_mode, thinking, seed, max_retries)
            if self.cache is not None and not r.error:
                self.cache.add_usage(spec.model, r.prompt_tokens, r.completion_tokens)

        if self.cache is not None and not r.error:
            self.cache.put(key, r.to_dict())
        self._account(model_key, r)
        return r

    def _call(self, spec: ModelSpec, messages, temperature, max_tokens, json_mode, thinking, seed,
              max_retries) -> LLMResponse:
        client = self._client(spec)
        kwargs: dict[str, Any] = {"model": spec.model, "messages": messages, "temperature": temperature,
                                  "max_tokens": max_tokens}
        if json_mode and spec.json_mode:
            kwargs["response_format"] = {"type": "json_object"}
        if seed is not None and spec.provider in ("deepseek", "ollama"):
            kwargs["seed"] = seed
        extra = dict(spec.thinking_on_param or {}) if thinking else dict(spec.thinking_param or {})
        if extra:
            kwargs["extra_body"] = extra

        last_err, attempt = "", 0
        for attempt in range(max_retries + 1):
            t0 = time.time()
            try:
                with self._sem(spec):
                    resp = client.chat.completions.create(**kwargs)
                latency = time.time() - t0
                msg = resp.choices[0].message
                text = msg.content or ""
                reasoning = getattr(msg, "reasoning_content", None) or ""
                usage = resp.usage
                pt = getattr(usage, "prompt_tokens", 0) or 0
                ct = getattr(usage, "completion_tokens", 0) or 0
                cost = (pt * spec.price_in + ct * spec.price_out) / 1e6
                return LLMResponse(text=text, model=spec.model, prompt_tokens=pt, completion_tokens=ct,
                                   latency_s=latency, cost_cny=cost, reasoning=reasoning, retries=attempt,
                                   meta={"finish_reason": resp.choices[0].finish_reason})
            except Exception as e:  # noqa: BLE001 - provider SDK raises many types
                last_err = f"{type(e).__name__}: {e}"
                retryable = any(m in last_err.lower() for m in RETRY_MARKERS) or type(e).__name__ in (
                    "RateLimitError", "APITimeoutError", "APIConnectionError", "InternalServerError")
                if not retryable or attempt == max_retries:
                    break
                wait = min(60.0, 2 ** attempt + random.random() * 2)
                log.warning("%s attempt %d failed (%s); retrying in %.1fs", spec.key, attempt + 1, last_err[:120], wait)
                time.sleep(wait)
        return LLMResponse(text="", model=spec.model, error=last_err, retries=attempt)

    def usage_summary(self) -> dict:
        return {k: dict(v, cost_cny=round(v["cost_cny"], 4)) for k, v in self.usage.items()}
