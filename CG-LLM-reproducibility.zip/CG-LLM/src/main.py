"""
CLI entry point — LLM-Powered Decision Support Agent for
Low-Altitude Airspace Management.

Usage:
    python -m src.main
    python -m src.main --interactive
"""

import logging
import sys
from pathlib import Path

import click
from rich.console import Console
from rich.panel import Panel
from rich.markdown import Markdown

# Ensure project root is on sys.path
PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from src.config import settings
from src.llm.deepseek_adapter import DeepSeekAdapter
from src.rag.embedder import Embedder
from src.rag.store import RegulationVectorStore
from src.rag.retriever import RegulationRetriever
from src.airspace.state import AirspaceStateManager
from src.airspace.conflict import detect_conflicts
from src.agent.prompts import build_v1_messages

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger(__name__)

import os
os.environ.setdefault("RICH_WINDOWS_CONSOLE", "0")
console = Console(force_terminal=False, color_system="standard")


def run_decision(
    request_text: str,
    area_wkt: str,
    area_desc: str,
    altitude_min: float,
    altitude_max: float,
    time_start: str,
    time_end: str,
    llm_client,
    retriever,
    airspace_manager,
) -> str:
    """Execute a single decision pipeline (Phase 1: single-turn LLM call).

    Returns:
        LLM-generated decision text.
    """
    from datetime import datetime

    # Step 1: Regulation retrieval
    console.print("[bold cyan]Searching regulations...[/bold cyan]")
    reg_results = retriever.search(
        query=f"{area_desc} {request_text}",
        top_k=5,
    )

    if reg_results:
        reg_context = "\n\n".join(
            f"[Regulation {i+1}] Source: {r['metadata'].get('doc_name', 'Unknown')} "
            f"(Relevance: {r['score']:.2f})\n{r['content']}"
            for i, r in enumerate(reg_results)
        )
    else:
        reg_context = "(No relevant regulatory provisions found. Ensure the regulation database has been properly ingested.)"

    # Step 2: Conflict detection
    console.print("[bold cyan]Checking airspace conflicts...[/bold cyan]")
    ts = datetime.fromisoformat(time_start)
    te = datetime.fromisoformat(time_end)

    active_ops = airspace_manager.get_active_operations(
        time_start=ts, time_end=te
    )
    console.print(f"  {len(active_ops)} active operation(s) in time window")

    conflict_result = detect_conflicts(
        request_area_wkt=area_wkt,
        request_alt_min=altitude_min,
        request_alt_max=altitude_max,
        request_time_start=ts,
        request_time_end=te,
        existing_operations=active_ops,
    )

    if conflict_result.has_conflict:
        conflict_context = "\n".join(
            f"{i}. {c.description}"
            for i, c in enumerate(conflict_result.conflicts, 1)
        )
        conflict_context = (
            f"WARNING: {conflict_result.conflict_count} conflict(s) detected:\n"
            + conflict_context
        )
    else:
        conflict_context = (
            "The 3D spatio-temporal conflict detection engine found ZERO conflicts. "
            "The requested airspace volume — horizontal area, altitude band "
            f"({altitude_min:.0f}–{altitude_max:.0f} m), and time window — "
            "is completely clear of any existing approved operations. "
            "No horizontal overlap, no altitude overlap, and no temporal overlap "
            "were detected with any of the currently active airspace operations. "
            "This is a strong positive signal for approval: there is no operational "
            "reason to modify or reject this request."
        )

    # Attach a regulatory altitude note when the ceiling is breached
    altitude_note = ""
    if altitude_max > 120.0:
        altitude_note = (
            f"\n\n[Regulatory Note] The requested maximum altitude ({altitude_max:.0f} m) "
            f"exceeds the 120 m AGL regulatory ceiling for small unmanned aircraft "
            f"under applicable civil aviation regulations. This must be addressed in "
            f"the regulatory analysis."
        )
        conflict_context += altitude_note

    # Step 3: Invoke LLM
    console.print("[bold cyan]Invoking AI decision engine...[/bold cyan]")
    messages = build_v1_messages(
        request_text=request_text,
        regulation_context=reg_context,
        conflict_context=conflict_context,
    )

    response = llm_client.chat(
        messages=messages,
        temperature=settings.LLM_TEMPERATURE,
        max_tokens=settings.LLM_MAX_TOKENS,
    )

    return response


@click.command()
@click.option(
    "--interactive", "-i",
    is_flag=True,
    help="Interactive mode: enter request details step by step.",
)
@click.option(
    "--example", "-e",
    type=int,
    default=1,
    help="Use a built-in example request (1–3).",
)
def main(interactive: bool, example: int):
    """LLM-Powered Decision Support Agent for Low-Altitude Airspace Management — CLI"""
    console.print()
    # Quadcopter drone icon (cyan body, yellow center)
    console.print("          [cyan].---.[/cyan]   [bold yellow]*[/bold yellow]   [cyan].---.[/cyan]")
    console.print("         [cyan](     )-[/cyan][bold yellow]*[/bold yellow][cyan]-(     )[/cyan]")
    console.print("          [cyan]`---`   [/cyan][bold yellow]*[/bold yellow]   [cyan]`---`[/cyan]")
    console.print()
    console.print(Panel.fit(
        "\n    [bold white]LLM-Powered Decision Support Agent[/bold white]\n"
        "    [bold cyan]for Low-Altitude Airspace Management[/bold cyan]\n",
        border_style="cyan", padding=(0, 6),
    ))
    console.print()

    # Validate configuration
    missing = settings.validate()
    if missing:
        console.print(
            f"[bold red]ERROR: Missing configuration: {', '.join(missing)}[/bold red]\n"
            f"Please create a .env file with the required settings (see .env.example)."
        )
        sys.exit(1)

    console.print(settings.summary())
    console.print()

    # Initialise components
    # IMPORTANT: Embedder must be loaded FIRST to avoid segfault
    # (Chroma/openai libraries initialise ONNX runtime threads that
    #  conflict with PyTorch if loaded before sentence-transformers)
    console.print("[dim]Initialising components...[/dim]")

    # Embedder — load model FIRST
    embedder = Embedder(
        model_name=settings.EMBEDDING_MODEL,
        device=settings.EMBEDDING_DEVICE,
    )
    _ = embedder.model  # pre-load to avoid lazy-load segfault

    # LLM
    llm = DeepSeekAdapter(
        api_key=settings.DEEPSEEK_API_KEY,
        base_url=settings.DEEPSEEK_BASE_URL,
        model=settings.DEEPSEEK_MODEL,
    )

    # RAG
    vector_store = RegulationVectorStore(
        persist_dir=settings.CHROMA_PERSIST_DIR,
    )
    retriever = RegulationRetriever(
        vector_store=vector_store,
        embedder=embedder,
    )

    # Airspace management
    airspace = AirspaceStateManager(
        db_path=settings.AIRSPACE_DB_PATH,
    )

    console.print(
        f"[dim]  Regulation DB: {vector_store.count()} entries | "
        f"Airspace ops: {airspace.count()} entries[/dim]\n"
    )

    # ========================================================
    # Example requests
    # ========================================================
    examples = {
        1: {
            "request_text": (
                "I am an operator from SF Express, applying to conduct "
                "drone delivery flights in the Nanshan Science Park area "
                "of Shenzhen. We use DJI FlyCart 30 drones, "
                "flight altitude 80–110 m, time window 9:00–11:00 on "
                "24 June 2026. The delivery route covers the area between "
                "Kejiyuan South Road and Keyuan Road."
            ),
            "area_wkt": (
                "POLYGON((113.945 22.540, 113.955 22.540, "
                "113.955 22.530, 113.945 22.530, 113.945 22.540))"
            ),
            "area_desc": "Nanshan Science Park, Shenzhen",
            "altitude_min": 80.0,
            "altitude_max": 110.0,
            "time_start": "2026-06-24T09:00:00",
            "time_end": "2026-06-24T11:00:00",
        },
        2: {
            "request_text": (
                "I am an operator from Meituan Unmanned Aerial Vehicles, "
                "applying to conduct food delivery flights in the Coastal "
                "City shopping district of Nanshan, Shenzhen. We use "
                "Meituan's proprietary delivery drones, flight altitude "
                "50–80 m, time window 14:00–16:00 on 24 June 2026. "
                "Delivery area covers a 2 km radius around Coastal City."
            ),
            "area_wkt": (
                "POLYGON((113.935 22.520, 113.945 22.520, "
                "113.945 22.515, 113.935 22.515, 113.935 22.520))"
            ),
            "area_desc": "Coastal City shopping district, Nanshan, Shenzhen",
            "altitude_min": 50.0,
            "altitude_max": 80.0,
            "time_start": "2026-06-24T14:00:00",
            "time_end": "2026-06-24T16:00:00",
        },
        3: {
            "request_text": (
                "I am from the DJI Innovation test team, applying to "
                "conduct flight tests of a new UAV model over Shenzhen Bay "
                "Park in Nanshan, Shenzhen. We use an undisclosed prototype, "
                "flight altitude 150–200 m, time window 8:00–12:00 on "
                "25 June 2026. The test area covers a 2 km coastal strip "
                "along Shenzhen Bay Park."
            ),
            "area_wkt": (
                "POLYGON((113.950 22.510, 113.960 22.510, "
                "113.960 22.505, 113.950 22.505, 113.950 22.510))"
            ),
            "area_desc": "Shenzhen Bay Park, Nanshan, Shenzhen",
            "altitude_min": 150.0,
            "altitude_max": 200.0,
            "time_start": "2026-06-25T08:00:00",
            "time_end": "2026-06-25T12:00:00",
        },
    }

    # Select request
    if interactive:
        console.print()
        console.print(Panel.fit(
            "[bold cyan]Interactive Request Entry[/bold cyan]\n\n"
            "[dim]Describe your drone operation in natural language.\n"
            "Press Enter to accept the default template values, or type your own.[/dim]",
            border_style="cyan",
        ))

        request_text = click.prompt(
            "\n[1/7] Request description",
            type=str,
            default="I am an operator from SF Express, applying to conduct drone delivery "
                    "flights in the Nanshan Science Park area of Shenzhen. "
                    "Flight altitude 80-110 m, time window 9:00-11:00 on 24 June 2026.",
        )

        area_wkt = click.prompt(
            "\n[2/7] Area WKT polygon\n"
            "       Format: POLYGON((lon lat, lon lat, ...))\n"
            "       Shenzhen Nanshan approx: lon 113.9~114.0, lat 22.50~22.55\n"
            "       Altitude range: 0~3000 m",
            type=str,
            default="POLYGON((113.945 22.540, 113.955 22.540, "
                    "113.955 22.530, 113.945 22.530, 113.945 22.540))",
        )

        area_desc = click.prompt(
            "\n[3/7] Area description",
            type=str,
            default="Nanshan Science Park, Shenzhen",
        )

        altitude_min = click.prompt(
            "\n[4/7] Minimum altitude (0~3000 m)",
            type=float,
            default=80.0,
        )

        altitude_max = click.prompt(
            "\n[5/7] Maximum altitude (0~3000 m)",
            type=float,
            default=110.0,
        )

        time_start = click.prompt(
            "\n[6/7] Start time",
            type=str,
            default="2026-06-24T09:00:00",
        )

        time_end = click.prompt(
            "\n[7/7] End time",
            type=str,
            default="2026-06-24T11:00:00",
        )
    else:
        ex = examples.get(example, examples[1])
        request_text = ex["request_text"]
        area_wkt = ex["area_wkt"]
        area_desc = ex["area_desc"]
        altitude_min = ex["altitude_min"]
        altitude_max = ex["altitude_max"]
        time_start = ex["time_start"]
        time_end = ex["time_end"]

        console.print("[bold]Request details:[/bold]")
        console.print(f"  {request_text[:120]}...")
        console.print(f"  Area: {area_desc}")
        console.print(f"  Altitude: {altitude_min}–{altitude_max} m")
        console.print(f"  Time: {time_start} ~ {time_end}")
        console.print()

    # Execute decision pipeline
    console.rule("Decision Pipeline")
    try:
        decision_text = run_decision(
            request_text=request_text,
            area_wkt=area_wkt,
            area_desc=area_desc,
            altitude_min=altitude_min,
            altitude_max=altitude_max,
            time_start=time_start,
            time_end=time_end,
            llm_client=llm,
            retriever=retriever,
            airspace_manager=airspace,
        )

        console.rule("AI Decision")
        console.print(Markdown(decision_text))

        # Human confirmation
        console.rule("Human Controller Confirmation")
        human_choice = click.prompt(
            "Confirm final decision",
            type=click.Choice(["approve", "reject", "modify"]),
            default="approve",
        )
        human_notes = click.prompt("Notes (optional)", default="", show_default=False)

        console.print(
            f"\n[bold green]Final decision: {human_choice.upper()}[/bold green]"
        )
        if human_notes:
            console.print(f"[dim]Notes: {human_notes}[/dim]")

    except Exception as e:
        console.print(f"[bold red]ERROR: {e}[/bold red]")
        logger.exception("Decision pipeline failed")
        sys.exit(1)


if __name__ == "__main__":
    main()
