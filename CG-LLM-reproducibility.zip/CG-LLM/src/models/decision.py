"""
Data models: Agent decision result and conflict detection result.
"""

from datetime import datetime
from typing import List, Optional
from uuid import uuid4

from pydantic import BaseModel, Field


class ConflictDetail(BaseModel):
    """Details of a single detected conflict."""

    operation_a_id: str = Field(description="ID of the requesting operation")
    operation_b_id: str = Field(description="ID of the conflicting existing operation")
    spatial_overlap_area_m2: float = Field(
        description="Horizontal overlap area (square metres)"
    )
    spatial_overlap_percent: float = Field(
        ge=0.0, le=100.0, description="Percentage of the request area overlapped"
    )
    altitude_overlap_min_m: float = Field(description="Lower bound of altitude overlap (metres)")
    altitude_overlap_max_m: float = Field(description="Upper bound of altitude overlap (metres)")
    has_altitude_overlap: bool = Field(description="Whether altitude overlap exists")
    temporal_overlap_minutes: float = Field(description="Duration of temporal overlap (minutes)")
    severity: str = Field(
        description="Conflict severity: LOW / MEDIUM / HIGH / CRITICAL"
    )
    description: str = Field(description="Human-readable conflict description")


class ConflictResult(BaseModel):
    """Result of conflict detection."""

    has_conflict: bool = Field(description="Whether any conflict exists")
    conflict_count: int = Field(default=0, description="Number of conflicts detected")
    conflicts: List[ConflictDetail] = Field(
        default_factory=list, description="List of conflict details"
    )


class AgentStep(BaseModel):
    """Single reasoning step record (ReAct trace)."""

    step_number: int = Field(description="Step number")
    thought: str = Field(description="LLM reasoning output")
    action: Optional[str] = Field(default=None, description="Name of the tool invoked")
    action_input: Optional[dict] = Field(
        default=None, description="Parameters passed to the tool"
    )
    observation: Optional[str] = Field(
        default=None, description="Summary of the tool's return value"
    )


class AgentDecision(BaseModel):
    """Final decision produced by the Agent."""

    decision_id: str = Field(default_factory=lambda: str(uuid4()))
    request_id: str = Field(description="Associated request ID")
    recommendation: str = Field(
        description="Approval recommendation: APPROVE / REJECT / MODIFY"
    )
    confidence: float = Field(
        ge=0.0, le=1.0, description="Confidence score"
    )
    summary: str = Field(
        description="Decision summary (for the human controller)"
    )
    detailed_reasoning: str = Field(
        description="Detailed reasoning trace"
    )
    supporting_regulations: List[str] = Field(
        default_factory=list, description="List of cited regulatory provisions"
    )
    conflicts_found: Optional[ConflictResult] = Field(
        default=None, description="Conflict detection result"
    )
    modified_suggestion: Optional[str] = Field(
        default=None,
        description="If recommendation is MODIFY, the suggested modifications"
    )
    reasoning_trace: List[AgentStep] = Field(
        default_factory=list, description="Full reasoning trace"
    )
    generated_at: datetime = Field(
        default_factory=datetime.now, description="Timestamp of decision generation"
    )
    human_decision: Optional[str] = Field(
        default=None,
        description="Final decision by the human controller (APPROVE / REJECT / MODIFY)"
    )
    human_notes: Optional[str] = Field(
        default=None, description="Notes from the human controller"
    )

    class Config:
        json_encoders = {datetime: lambda v: v.isoformat()}
