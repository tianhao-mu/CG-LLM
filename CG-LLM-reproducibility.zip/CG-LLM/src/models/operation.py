"""
Data model: Approved airspace operation.
"""

from datetime import datetime
from typing import Optional
from uuid import uuid4

from pydantic import BaseModel, Field


class ApprovedOperation(BaseModel):
    """An approved operation registered in the airspace management system."""

    operation_id: str = Field(default_factory=lambda: str(uuid4()))
    request_id: Optional[str] = Field(
        default=None, description="Associated original request ID"
    )
    operator_name: str = Field(description="Operator name")
    flight_purpose: str = Field(description="Flight purpose")

    # Airspace occupancy
    altitude_min_m: float = Field(ge=0, le=3000)
    altitude_max_m: float = Field(ge=0, le=3000)
    area_wkt: str = Field(description="WKT polygon of the approved area")
    area_description: Optional[str] = Field(
        default=None, description="Human-readable area description"
    )

    # Time occupancy
    time_start: datetime = Field(description="Operation start time")
    time_end: datetime = Field(description="Operation end time")

    # Approval metadata
    approved_at: datetime = Field(default_factory=datetime.now)
    approved_by: str = Field(description="Approver / system identifier")
    remarks: Optional[str] = Field(default=None, description="Additional conditions or notes")

    status: str = Field(
        default="ACTIVE",
        description="Operation status: ACTIVE / COMPLETED / CANCELLED"
    )

    class Config:
        json_encoders = {datetime: lambda v: v.isoformat()}
