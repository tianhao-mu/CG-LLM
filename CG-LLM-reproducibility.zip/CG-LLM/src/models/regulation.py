"""
Data model: Regulation document.
"""

from datetime import date
from typing import List, Optional
from uuid import uuid4

from pydantic import BaseModel, Field


class Regulation(BaseModel):
    """A regulation document entry."""

    regulation_id: str = Field(default_factory=lambda: str(uuid4()))
    title: str = Field(description="Regulation title")
    issuing_body: str = Field(description="Issuing body, e.g. 'Civil Aviation Administration of China'")
    effective_date: date = Field(description="Effective date")
    version: str = Field(default="1.0", description="Version number")

    # Article / provision info
    article_number: Optional[str] = Field(
        default=None, description="Specific article/chapter number"
    )
    full_text: str = Field(description="Full text of the provision")

    # Chunk info (for RAG)
    chunk_id: Optional[str] = Field(
        default=None, description="Retrieval chunk ID"
    )
    chunk_text: Optional[str] = Field(
        default=None, description="Chunk text used for embedding"
    )

    # Metadata
    keywords: List[str] = Field(
        default_factory=list, description="Extracted keywords"
    )
    category: str = Field(
        default="Operations Management",
        description="Regulation category: Registration / Airworthiness / Operations / "
                    "Airspace Management / Safety / Other"
    )

    class Config:
        json_encoders = {date: lambda v: v.isoformat()}
