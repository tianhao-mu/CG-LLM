"""
Data model: Airspace use request.
"""

from datetime import datetime
from typing import Optional
from uuid import UUID, uuid4

from pydantic import BaseModel, Field


class AirspaceRequest(BaseModel):
    """An airspace use request submitted by a UA operator."""

    request_id: str = Field(default_factory=lambda: str(uuid4()))
    raw_text: str = Field(
        description="Original natural-language text submitted by the operator"
    )
    operator_name: str = Field(description="Operator name / identity")
    operator_qualification: str = Field(
        default="Not provided",
        description="Operator qualification level (e.g., CAAC certificate number)"
    )
    flight_purpose: str = Field(
        description="Flight purpose: delivery / inspection / surveying / performance / other"
    )
    drone_model: Optional[str] = Field(
        default=None, description="UA model name"
    )

    # 3D airspace constraints
    altitude_min_m: float = Field(ge=0, le=3000, description="Minimum flight altitude (metres)")
    altitude_max_m: float = Field(ge=0, le=3000, description="Maximum flight altitude (metres)")

    # Horizontal area — stored as WKT Polygon string
    area_wkt: str = Field(
        description="WKT polygon of the requested flight area"
    )
    area_description: str = Field(
        description="Human-readable area description, e.g. 'Nanshan Science Park, Shenzhen'"
    )

    # Time window
    time_start: datetime = Field(description="Planned start time")
    time_end: datetime = Field(description="Planned end time")

    # Metadata
    submitted_at: datetime = Field(
        default_factory=datetime.now, description="Submission timestamp"
    )
    status: str = Field(
        default="PENDING",
        description="Processing status: PENDING / APPROVED / REJECTED / MODIFIED"
    )

    class Config:
        json_encoders = {datetime: lambda v: v.isoformat()}
