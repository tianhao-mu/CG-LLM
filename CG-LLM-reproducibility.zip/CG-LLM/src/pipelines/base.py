"""Pipeline base class and result record."""

from __future__ import annotations

import time
import traceback
from dataclasses import dataclass, field
from typing import Any, Optional

from src.benchmark.schema import Case
from src.llm.providers import LLMClient, LLMResponse
from src.policy.engine import INDETERMINATE, ESCALATE, RuleEngine
from src.policy.modification import verify_modification
from src.rag.hybrid import HybridRetriever


@dataclass
class RunContext:
    client: Optional[LLMClient]
    model: str
    temperature: float = 0.0
    lang: str = "en"
    thinking: bool = False
    engine: RuleEngine = field(default_factory=RuleEngine)
    retriever: Optional[HybridRetriever] = None
    top_k: int = 5


class Pipeline:
    name = "base"
    uses_llm = True

    def __init__(self, rc: RunContext, **options):
        self.rc = rc
        self.options = options
        self._calls: list[dict] = []

    # ------------------------------------------------------------------ llm
    def llm(self, messages: list[dict], json_mode: bool = True, sample_idx: int = 0, temperature: float | None = None,
            max_tokens: int | None = None, tag: str = "") -> LLMResponse:
        rc = self.rc
        r = rc.client.chat(rc.model, messages, temperature=rc.temperature if temperature is None else temperature,
                           json_mode=json_mode, thinking=rc.thinking, sample_idx=sample_idx, max_tokens=max_tokens)
        self._calls.append({"tag": tag, "prompt_tokens": r.prompt_tokens, "completion_tokens": r.completion_tokens,
                            "latency_s": round(r.latency_s, 3), "cost_cny": r.cost_cny, "cached": r.cached,
                            "error": r.error[:300], "retries": r.retries})
        return r

    # ------------------------------------------------------------------ run
    def decide(self, case: Case, repeat: int) -> dict:
        raise NotImplementedError

    def run(self, case: Case, repeat: int = 0) -> dict:
        self._calls = []
        t0 = time.time()
        rec: dict[str, Any] = {
            "case_id": case.case_id, "recipe": case.recipe, "split": case.split, "perturbation": case.perturbation,
            "parent_id": case.parent_id, "lang": self.rc.lang, "method": self.name,
            "model": self.rc.model if self.uses_llm else "none", "temperature": self.rc.temperature,
            "thinking": self.rc.thinking, "repeat": repeat, "gold_decision": case.gold.decision,
        }
        try:
            out = self.decide(case, repeat)
            rec.update(out)
        except Exception as e:  # noqa: BLE001 - one failing case must not stop a run
            rec.update({"decision": None, "error": f"{type(e).__name__}: {e}", "traceback": traceback.format_exc()[-1500:]})
        rec.setdefault("error", "")
        rec["decision"] = rec.get("decision") or None
        rec["llm_calls"] = self._calls
        rec["n_calls"] = len(self._calls)
        # Usage of the method itself, independent of whether this run hit the cache.
        rec["prompt_tokens"] = sum(c["prompt_tokens"] for c in self._calls)
        rec["completion_tokens"] = sum(c["completion_tokens"] for c in self._calls)
        rec["cost_cny"] = round(sum(c["cost_cny"] for c in self._calls), 6)
        rec["billed_cost_cny"] = round(sum(c["cost_cny"] for c in self._calls if not c["cached"]), 6)
        rec["llm_latency_s"] = round(sum(c["latency_s"] for c in self._calls), 3)
        rec["wall_s"] = round(time.time() - t0, 3)
        if any(c["error"] for c in self._calls) and not rec["error"]:
            rec["error"] = "llm: " + next(c["error"] for c in self._calls if c["error"])
        return rec

    # ------------------------------------------------------------------ helpers
    def check_modification(self, case: Case, proposal: dict | None) -> dict | None:
        """Verify a proposed modification against the gold facts and context."""
        if not proposal:
            return None
        return verify_modification(self.rc.engine, case.gold.request_facts(), case.context, proposal)


def engine_label(decision: str) -> str:
    return ESCALATE if decision == INDETERMINATE else decision
