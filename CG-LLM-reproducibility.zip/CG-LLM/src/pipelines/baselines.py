"""
Baselines.

llm_direct   LLM alone (role + decision semantics + authority records)
llm_rules    + the full constraint table in the prompt (prompt-only rules,
             as in the conference version)
llm_rag      + request-text retrieval of regulation articles (RAG baseline)
llm_rules_rag  rules + RAG
regex_engine regex extraction + rule engine (no LLM)
oracle_engine gold facts + rule engine (upper bound / sanity check)
"""

from __future__ import annotations

from src.benchmark.schema import Case
from src.pipelines.base import Pipeline, engine_label
from src.pipelines.parsing import as_list, decision_from_text, extract_json, normalize_articles, normalize_decision
from src.pipelines.prompts import decide_messages
from src.pipelines.regex_extract import regex_extract
from src.rag.hybrid import format_hits


def parse_decision_output(text: str) -> dict:
    obj = extract_json(text)
    if obj is None:
        return {"decision": decision_from_text(text), "parse_ok": False, "confidence": None,
                "violated_constraints": [], "cited_articles": [], "modification": None, "conditions": [],
                "explanation": text[-1500:]}
    conf = obj.get("confidence")
    try:
        conf = max(0.0, min(1.0, float(conf))) if conf is not None else None
    except (TypeError, ValueError):
        conf = None
    mod = obj.get("modification") if isinstance(obj.get("modification"), dict) else None
    return {"decision": normalize_decision(obj.get("decision")), "parse_ok": normalize_decision(obj.get("decision")) is not None,
            "confidence": conf, "violated_constraints": [str(v) for v in as_list(obj.get("violated_constraints"))],
            "cited_articles": normalize_articles(obj.get("cited_articles")), "modification": mod,
            "conditions": [str(c) for c in as_list(obj.get("conditions"))], "explanation": str(obj.get("explanation", ""))}


class LLMDirect(Pipeline):
    name = "llm_direct"
    with_rules = False
    with_rag = False

    def decide(self, case: Case, repeat: int) -> dict:
        rules = self.rc.engine.table.rules_text(self.rc.lang) if self.with_rules else None
        articles, retrieved = None, []
        if self.with_rag:
            hits = self.rc.retriever.retrieve(case.text(self.rc.lang), k=self.rc.top_k)
            retrieved = [h.article_id for h in hits]
            articles = format_hits(hits)
        r = self.llm(decide_messages(case, self.rc.lang, rules, articles), sample_idx=repeat, tag="decide")
        out = parse_decision_output(r.text)
        out["retrieved"] = retrieved
        out["pre_escalation_decision"] = out["decision"]
        out["escalated"] = out["decision"] == "ESCALATE"
        if out["decision"] == "MODIFY":
            out["modification_check"] = self.check_modification(case, out["modification"])
        return out


class LLMRules(LLMDirect):
    name = "llm_rules"
    with_rules = True


class LLMRag(LLMDirect):
    name = "llm_rag"
    with_rag = True


class LLMRulesRag(LLMDirect):
    name = "llm_rules_rag"
    with_rules = True
    with_rag = True


class RegexEngine(Pipeline):
    name = "regex_engine"
    uses_llm = False

    def decide(self, case: Case, repeat: int) -> dict:
        facts = regex_extract(case.text(self.rc.lang), self.rc.lang)
        d = self.rc.engine.evaluate(facts, case.context)
        label = engine_label(d.decision)
        return {"decision": label, "pre_escalation_decision": label, "escalated": label == "ESCALATE",
                "confidence": 1.0, "parse_ok": True, "facts": facts.to_json_dict(), "engine": d.to_dict(),
                "violated_constraints": d.trigger_ids, "cited_articles": d.articles, "modification": d.modification,
                "modification_check": self.check_modification(case, d.modification) if d.modification else None,
                "conditions": d.conditions, "explanation": d.to_text()}


class OracleEngine(Pipeline):
    name = "oracle_engine"
    uses_llm = False

    def decide(self, case: Case, repeat: int) -> dict:
        facts = case.gold.request_facts()
        d = self.rc.engine.evaluate(facts, case.context)
        label = engine_label(d.decision)
        return {"decision": label, "pre_escalation_decision": label, "escalated": label == "ESCALATE",
                "confidence": 1.0, "parse_ok": True, "facts": facts.to_json_dict(), "engine": d.to_dict(),
                "violated_constraints": d.trigger_ids, "cited_articles": d.articles, "modification": d.modification,
                "modification_check": self.check_modification(case, d.modification) if d.modification else None,
                "conditions": d.conditions, "explanation": d.to_text()}
