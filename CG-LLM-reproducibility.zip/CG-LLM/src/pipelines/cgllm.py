"""
Constraint-grounded LLM (CG-LLM), the proposed method, and its ablations.

  1. LLM extracts structured facts from the application text.
  2. The rule engine checks every constraint (credentials, altitude, filing,
     operations, geofences, 4D separation) and, for geometric issues,
     searches for a verified modification.
  3. Articles are attached by the constraint -> article map and augmented by
     constraint-guided retrieval.
  4. The LLM reviews facts + engine report and writes the explanation. If it
     disagrees with the engine, the case is escalated to a human.

Ablations (``variant``):
  no_review      stop after step 3 (template explanation)
  no_rag_review  review without regulation excerpts
  request_query  retrieval query = application text instead of constraints
  free_mod       LLM proposes the modification instead of the search
  llm_sep        LLM judges separation severities instead of the engine
  sc             3 extraction samples; field-wise vote; engine disagreement
                 across samples -> escalate
"""

from __future__ import annotations

from collections import Counter

from src.airspace.separation import PairAssessment, SeparationReport, Severity
from src.benchmark.schema import Case
from src.pipelines.base import Pipeline, engine_label
from src.pipelines.parsing import as_list, extract_json, normalize_articles, normalize_decision, parse_facts
from src.pipelines.prompts import extract_messages, modify_messages, review_messages, separation_messages
from src.policy.engine import EngineDecision
from src.policy.facts import RequestFacts
from src.rag.articles import Article
from src.rag.hybrid import format_hits


class CGLLM(Pipeline):
    name = "cgllm"
    variant = "full"

    # ------------------------------------------------------------ steps
    def extract(self, case: Case, sample_idx: int, temperature: float | None = None) -> tuple[RequestFacts, dict]:
        r = self.llm(extract_messages(case, self.rc.lang), sample_idx=sample_idx, temperature=temperature, tag="extract")
        facts, warnings = parse_facts(extract_json(r.text))
        return facts, {"warnings": warnings, "parse_ok": not any("no JSON" in w for w in warnings)}

    def extract_sc(self, case: Case, repeat: int, k: int = 3) -> tuple[RequestFacts, dict, list[RequestFacts]]:
        samples = [self.extract(case, sample_idx=repeat * 100 + i, temperature=max(self.rc.temperature, 0.7))[0]
                   for i in range(k)]
        voted = {}
        for field in RequestFacts.model_fields:
            vals = [getattr(s, field) for s in samples]
            keyed = Counter(repr(v) for v in vals)
            best = keyed.most_common(1)[0][0]
            voted[field] = next(v for v in vals if repr(v) == best)
        return RequestFacts.model_validate(voted), {"parse_ok": True, "warnings": []}, samples

    def llm_separation(self, case: Case, facts: RequestFacts) -> SeparationReport:
        r = self.llm(separation_messages(case, facts.to_json_dict(), self.rc.engine.table), tag="separation")
        obj = extract_json(r.text) or {}
        pairs = []
        for c in as_list(obj.get("conflicts")):
            if not isinstance(c, dict):
                continue
            try:
                sev = Severity(str(c.get("severity", "")).upper())
            except ValueError:
                continue
            pairs.append(PairAssessment("REQUEST", str(c.get("op_id", "?")), float("nan"), float("nan"), float("nan"),
                                        0.0, 0.0, sev))
        return SeparationReport("REQUEST", pairs)

    def articles_for(self, case: Case, d: EngineDecision) -> tuple[list[Article], list[str]]:
        """Mapped articles of the triggered constraints + retrieved context."""
        retr = self.rc.retriever
        mapped_ids = list(d.articles)
        mapped = [a for a in (retr.get(i) for i in mapped_ids) if a is not None] if retr else []
        retrieved_ids: list[str] = []
        if retr is not None:
            if self.variant == "request_query":
                query = case.text(self.rc.lang)
                hits = retr.retrieve(query, k=self.rc.top_k)
                mapped = []
            else:
                table = self.rc.engine.table
                parts = []
                for t in d.triggers:
                    c = table.by_id(t.constraint_id)
                    parts.append(f"{c.name}. {c.quote_en if self.rc.lang == 'en' else c.quote_zh} {c.exemption}")
                query = " ".join(parts) or "flight activity application approval controlled airspace"
                hits = retr.retrieve(query, k=self.rc.top_k)
            seen = {a.article_id for a in mapped}
            for h in hits:
                retrieved_ids.append(h.article_id)
                if h.article_id not in seen:
                    mapped.append(h.article)
                    seen.add(h.article_id)
        return mapped[: max(self.rc.top_k, len(mapped_ids))], retrieved_ids

    # ------------------------------------------------------------ main
    def decide(self, case: Case, repeat: int) -> dict:
        eng = self.rc.engine
        samples = None
        if self.variant == "sc":
            facts, ext, samples = self.extract_sc(case, repeat)
        else:
            facts, ext = self.extract(case, sample_idx=repeat)

        sep_override = self.llm_separation(case, facts) if self.variant == "llm_sep" and not eng.missing_facts(facts) else None
        d = eng.evaluate(facts, case.context, search=self.variant != "free_mod", separation_override=sep_override)

        if self.variant == "free_mod" and not d.missing:
            a = eng.assess(facts, case.context, separation_override=sep_override)
            if not a.rejects and a.geometric:
                d.triggers = a.triggers
                d.decision = "MODIFY"
                r = self.llm(modify_messages(case, self.rc.lang, facts.to_json_dict(), d.to_text()), tag="modify")
                obj = extract_json(r.text) or {}
                d.modification = {k: obj.get(k) for k in ("time_start", "time_end", "altitude_min_m", "altitude_max_m")}
        modification = d.modification

        label = engine_label(d.decision)
        confidence = 1.0
        sc_agreement = None
        if samples is not None:
            labels = [engine_label(eng.evaluate(s, case.context).decision) for s in samples]
            sc_agreement = Counter(labels).most_common(1)[0][1] / len(labels)
            confidence = sc_agreement

        out = {"facts": facts.to_json_dict(), "extract_parse_ok": ext["parse_ok"], "extract_warnings": ext["warnings"],
               "engine": d.to_dict(), "engine_decision": label, "violated_constraints": d.trigger_ids,
               "modification": modification, "conditions": d.conditions, "parse_ok": ext["parse_ok"],
               "sc_agreement": sc_agreement}
        if sep_override is not None:
            out["llm_separation"] = sep_override.to_dict()
        if modification:
            out["modification_check"] = self.check_modification(case, modification)

        arts, retrieved = self.articles_for(case, d) if label != "ESCALATE" else ([], [])
        out["retrieved"] = retrieved
        cited = list(d.articles)

        review = None
        if self.variant != "no_review" and label != "ESCALATE":
            excerpts = None if self.variant == "no_rag_review" else format_hits(_as_hits(arts))
            r = self.llm(review_messages(case, self.rc.lang, facts.to_json_dict(), d.to_text(), excerpts), tag="review")
            obj = extract_json(r.text)
            if obj is not None:
                corrections = _corrections(obj.get("extraction_errors"), facts)
                review = {"decision": normalize_decision(obj.get("decision")), "corrections": corrections,
                          "confidence": _float(obj.get("confidence")),
                          "cited_articles": normalize_articles(obj.get("cited_articles")),
                          "explanation": str(obj.get("explanation", ""))}
                if corrections:
                    corrected = facts.model_copy(update=corrections)
                    review["corrected_decision"] = engine_label(eng.evaluate(corrected, case.context).decision)
            else:
                review = {"decision": None, "corrections": {}, "confidence": None, "cited_articles": [],
                          "explanation": r.text[-1500:], "parse_error": True}
        out["review"] = review

        final = label
        if review is not None:
            # Escalate only on decision-relevant disagreement: a different decision, or
            # extraction corrections that change the engine outcome.
            reasons = []
            if review["decision"] not in (None, label):
                reasons.append("reviewer_decision")
            if review.get("corrected_decision") not in (None, label):
                reasons.append("fact_correction")
            review["escalation_reasons"] = reasons
            if reasons:
                final = "ESCALATE"
            if review["confidence"] is not None:
                confidence = min(confidence, review["confidence"]) if samples is not None else review["confidence"]
            cited = list(dict.fromkeys(cited + review["cited_articles"]))
            out["explanation"] = review["explanation"]
        else:
            out["explanation"] = d.to_text()
        if sc_agreement is not None and sc_agreement < 1.0 and final != "ESCALATE":
            final = "ESCALATE"
        out["pre_escalation_decision"] = label
        out["decision"] = final
        out["escalated"] = final == "ESCALATE"
        out["confidence"] = confidence
        out["cited_articles"] = cited
        return out


class _H:
    def __init__(self, a: Article):
        self.article = a


def _as_hits(arts: list[Article]):
    return [_H(a) for a in arts]


def _corrections(items, facts: RequestFacts) -> dict:
    """Validated {field: value} updates from the reviewer, ignoring no-op or unknown fields."""
    out = {}
    for it in as_list(items):
        if not isinstance(it, dict) or it.get("field") not in RequestFacts.model_fields:
            continue
        field, value = it["field"], it.get("correct_value")
        try:
            parsed = getattr(RequestFacts.model_validate({field: value}), field)
        except Exception:  # noqa: BLE001
            continue
        if field in ("time_start", "time_end") and parsed is None and value not in (None, "null"):
            from src.pipelines.parsing import parse_datetime
            parsed = parse_datetime(value, facts.time_start)
        if parsed != getattr(facts, field):
            out[field] = parsed
    return out


def _float(v):
    try:
        return max(0.0, min(1.0, float(v)))
    except (TypeError, ValueError):
        return None


def _variant(name: str, variant: str):
    return type(f"CGLLM_{variant}", (CGLLM,), {"name": name, "variant": variant})


CGLLM_NO_REVIEW = _variant("cgllm_no_review", "no_review")
CGLLM_NO_RAG_REVIEW = _variant("cgllm_no_rag_review", "no_rag_review")
CGLLM_REQUEST_QUERY = _variant("cgllm_request_query", "request_query")
CGLLM_FREE_MOD = _variant("cgllm_free_mod", "free_mod")
CGLLM_LLM_SEP = _variant("cgllm_llm_sep", "llm_sep")
CGLLM_SC = _variant("cgllm_sc", "sc")
