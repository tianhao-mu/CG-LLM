"""Tolerant parsing of LLM outputs."""

from __future__ import annotations

import json
import re
from datetime import datetime
from typing import Any, Optional

from src.policy.facts import RequestFacts

DECISION_WORDS = ("APPROVE", "MODIFY", "REJECT", "ESCALATE")
_ALIASES = {"APPROVED": "APPROVE", "ACCEPT": "APPROVE", "MODIFIED": "MODIFY", "CONDITIONAL": "MODIFY",
            "CONDITIONAL_APPROVAL": "MODIFY", "APPROVE_WITH_CONDITIONS": "MODIFY", "REJECTED": "REJECT",
            "DENY": "REJECT", "DENIED": "REJECT", "ESCALATED": "ESCALATE", "HUMAN_REVIEW": "ESCALATE",
            "批准": "APPROVE", "修改": "MODIFY", "有条件批准": "MODIFY", "拒绝": "REJECT", "驳回": "REJECT",
            "转人工": "ESCALATE"}


def strip_think(text: str) -> str:
    return re.sub(r"<think>.*?</think>", "", text or "", flags=re.S).strip()


def extract_json(text: str) -> Optional[dict]:
    """Return the first well-formed JSON object in ``text``."""
    text = strip_think(text)
    fence = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", text, re.S)
    if fence:
        try:
            return json.loads(fence.group(1))
        except json.JSONDecodeError:
            pass
    start = text.find("{")
    while start != -1:
        depth, in_str, esc = 0, False, False
        for i in range(start, len(text)):
            ch = text[i]
            if in_str:
                if esc:
                    esc = False
                elif ch == "\\":
                    esc = True
                elif ch == '"':
                    in_str = False
                continue
            if ch == '"':
                in_str = True
            elif ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    blob = text[start:i + 1]
                    for candidate in (blob, re.sub(r",\s*([}\]])", r"\1", blob)):
                        try:
                            obj = json.loads(candidate)
                            if isinstance(obj, dict):
                                return obj
                        except json.JSONDecodeError:
                            continue
                    break
        start = text.find("{", start + 1)
    return None


def normalize_decision(value: Any) -> Optional[str]:
    if value is None:
        return None
    s = str(value).strip().upper().replace(" ", "_").replace("-", "_")
    if s in DECISION_WORDS:
        return s
    if s in _ALIASES:
        return _ALIASES[s]
    for w in DECISION_WORDS:
        if w in s:
            return w
    return _ALIASES.get(str(value).strip())


def decision_from_text(text: str) -> Optional[str]:
    """Fallback when no JSON is present: last explicit decision keyword."""
    text = strip_think(text)
    m = re.findall(r"\b(APPROVE|MODIFY|REJECT|ESCALATE)\b", text.upper())
    return m[-1] if m else None


def parse_datetime(value: Any, ref_date: Optional[datetime] = None) -> Optional[datetime]:
    if value in (None, "", "null"):
        return None
    if isinstance(value, datetime):
        return value
    s = str(value).strip().replace("Z", "")
    s = re.sub(r"[+-]\d{2}:\d{2}$", "", s)
    for fmt in ("%Y-%m-%dT%H:%M:%S", "%Y-%m-%dT%H:%M", "%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y/%m/%d %H:%M"):
        try:
            return datetime.strptime(s, fmt)
        except ValueError:
            continue
    m = re.fullmatch(r"(\d{1,2}):(\d{2})", s)
    if m and ref_date is not None:
        return ref_date.replace(hour=int(m.group(1)), minute=int(m.group(2)), second=0, microsecond=0)
    return None


def parse_facts(obj: Optional[dict]) -> tuple[RequestFacts, list[str]]:
    """Validate an extraction JSON into RequestFacts; returns (facts, warnings)."""
    warnings: list[str] = []
    if not obj:
        return RequestFacts(), ["no JSON in extraction output"]
    data = dict(obj.get("facts", obj)) if isinstance(obj.get("facts", obj), dict) else dict(obj)
    start = parse_datetime(data.get("time_start"))
    data["time_start"] = start
    data["time_end"] = parse_datetime(data.get("time_end"), start)
    try:
        return RequestFacts.model_validate(data), warnings
    except Exception as e:  # noqa: BLE001
        warnings.append(f"validation: {e}")
        clean = {}
        for k, v in data.items():
            try:
                RequestFacts.model_validate({k: v})
                clean[k] = v
            except Exception:  # noqa: BLE001
                warnings.append(f"dropped field {k}")
        return RequestFacts.model_validate(clean), warnings


def as_list(value: Any) -> list:
    if value is None:
        return []
    if isinstance(value, list):
        return [v for v in value if v not in (None, "")]
    return [value]


ARTICLE_RE = re.compile(r"\b([A-Z]{2,5}-\d{2,4}|CCAR-92)\s*[:：]\s*(?:Art(?:icle)?\.?\s*)?(s?\d+(?:\.\d+)*|p\d+)", re.I)


def normalize_articles(values: Any) -> list[str]:
    out = []
    for v in as_list(values):
        for m in ARTICLE_RE.finditer(str(v)):
            out.append(f"{m.group(1).upper()}:{m.group(2)}")
    return list(dict.fromkeys(out))
