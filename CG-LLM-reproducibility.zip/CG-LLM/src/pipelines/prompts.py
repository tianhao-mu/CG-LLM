"""
Prompt builders. Every system prompt starts with a ``[TASK:...]`` tag, which
the offline mock model uses for routing.

Geometry is presented to the LLM as rectangles in metres relative to the
requested area's centre (east, north), so LLM-only baselines receive the
same information as the engine in a form they can reason about.
"""

from __future__ import annotations

import json

from src.airspace.geofence import load_zones
from src.benchmark.schema import Case
from src.geo.projection import polygon_lonlat_to_metric
from src.policy.constraints import ConstraintTable
from src.policy.engine import DEFAULT_GEOFENCE

FACT_FIELDS = """{
  "operator_name": string or null,
  "operator_type": "entity" | "individual" | null,
  "commercial": true | false | null     (true only if the text says the flight is commercial / for a paying client; false only if it says non-commercial; otherwise null),
  "purpose": one of [aerial_photography, delivery, infrastructure_inspection, airport_inspection, surveying, agriculture, emergency_rescue, environmental_monitoring, training, performance, recreation, other] or null,
  "uas_model": string or null,
  "mtow_kg": number or null            (maximum take-off weight in kilograms; convert grams),
  "real_name_registered": true | false | null,
  "operation_certificate": true | false | null   (Civil UA Operation Certificate of the operator),
  "pilot_license": true | false | null           (remote pilot licence),
  "agri_operating_certificate": true | false | null,
  "liability_insurance": true | false | null,
  "airworthiness_certificate": true | false | null,
  "survey_qualification": true | false | null,
  "altitude_min_m": number or null     (metres above ground; 0 if only a maximum is given; convert feet: 1 ft = 0.3048 m),
  "altitude_max_m": number or null,
  "time_start": "YYYY-MM-DDTHH:MM" or null (24-hour local time),
  "time_end": "YYYY-MM-DDTHH:MM" or null,
  "emergency": true | null,
  "bvlos": true | false | null          (beyond visual line of sight),
  "daa_capability": true | false | null (detect-and-avoid / traffic awareness equipment),
  "lighting": true | false | null       (navigation / anti-collision lights),
  "prohibited_activity": true | null    (e.g. photographing military or classified facilities)
}"""

DECISION_SCHEMA = """{
  "decision": "APPROVE" | "MODIFY" | "REJECT" | "ESCALATE",
  "confidence": number between 0 and 1,
  "violated_constraints": [constraint ids or short descriptions],
  "cited_articles": ["<DOC>:<article>", ...],
  "modification": {"time_start": "YYYY-MM-DDTHH:MM", "time_end": "YYYY-MM-DDTHH:MM", "altitude_min_m": number, "altitude_max_m": number} or null,
  "conditions": [strings],
  "explanation": string
}"""

DOC_LIST = ("IR-2023 (Interim Regulations on UA Flight Management), CCAR-92 (UAS Operation Safety Rules), "
            "AC-2015, LAU-2014, RNR-2017, SZ-2024 (Shenzhen Low-Altitude Economy Regulations)")

ROLE = ("You are an airspace authorization officer reviewing low-altitude UAS flight applications in Shenzhen, China, "
        "under the Interim Regulations on the Flight Management of Unmanned Aircraft (2023) and related rules.")

DECISION_SEMANTICS = (
    "Decision meanings: APPROVE = approve as submitted; MODIFY = approvable only with conditions (e.g. missing "
    "documents to be provided, lighting) or with a changed time window / altitude band; REJECT = not approvable; "
    "ESCALATE = essential information (altitude, time window or aircraft weight) is missing or the case needs a "
    "human reviewer.")


# --------------------------------------------------------------------- geometry text
def _bbox_desc(coords, origin) -> str:
    poly = polygon_lonlat_to_metric(coords)
    x0, y0, x1, y1 = poly.bounds
    cx, cy = (x0 + x1) / 2 - origin[0], (y0 + y1) / 2 - origin[1]
    return f"rectangle centred {cx:+.0f} m E, {cy:+.0f} m N, size {x1 - x0:.0f} m x {y1 - y0:.0f} m"


_ZONES = None


def _zones():
    global _ZONES
    if _ZONES is None:
        _ZONES = load_zones(DEFAULT_GEOFENCE)
    return _ZONES


def render_context(case: Case, radius_m: float = 6000) -> str:
    ctx = case.context
    area = polygon_lonlat_to_metric(ctx.area_coordinates)
    x0, y0, x1, y1 = area.bounds
    origin = ((x0 + x1) / 2, (y0 + y1) / 2)
    lines = [f"Submission time: {ctx.submitted_at:%Y-%m-%d %H:%M}",
             f"Requested area: {ctx.area_name}; rectangle centred 0 m E, 0 m N, size {x1 - x0:.0f} m x {y1 - y0:.0f} m "
             f"(all positions below are metres east/north of this centre)."]
    lines.append("Approved operations in the airspace database:")
    if ctx.approved_ops:
        for op in ctx.approved_ops:
            lines.append(f"- {op.op_id}: {_bbox_desc(op.coordinates, origin)}, altitude {op.altitude_min_m:g}-"
                         f"{op.altitude_max_m:g} m, {op.time_start:%Y-%m-%d %H:%M}-{op.time_end:%H:%M}")
    else:
        lines.append("- none")
    lines.append(f"Geofence zones within {radius_m / 1000:g} km:")
    near = []
    for z in _zones():
        if z.polygon.distance(area) <= radius_m:
            x0z, y0z, x1z, y1z = z.polygon.bounds
            desc = (f"rectangle centred {(x0z + x1z) / 2 - origin[0]:+.0f} m E, {(y0z + y1z) / 2 - origin[1]:+.0f} m N, "
                    f"size {x1z - x0z:.0f} m x {y1z - y0z:.0f} m")
            ex = f"; exempt purposes: {', '.join(z.exempt_purposes)}" if z.exempt_purposes else ""
            near.append(f"- {z.name} [{z.zone_type.value}]: {desc}{ex}")
    for t in ctx.temporary_zones:
        near.append(f"- {t.name} [TEMPORARY]: {_bbox_desc(t.coordinates, origin)}, active "
                    f"{t.active_start:%Y-%m-%d %H:%M}-{t.active_end:%H:%M}")
    lines += near or ["- none"]
    return "\n".join(lines)


# --------------------------------------------------------------------- prompts
def decide_messages(case: Case, lang: str, rules: str | None = None, articles: str | None = None,
                    react_tools: str | None = None) -> list[dict]:
    sys = [("[TASK:REACT] " if react_tools else "[TASK:DECIDE] ") + ROLE, DECISION_SEMANTICS]
    if rules:
        sys.append("Apply the following machine-checkable rules. Any REJECT effect -> REJECT; otherwise any MODIFY "
                   "effect -> MODIFY; otherwise APPROVE.\n" + rules)
    if articles:
        sys.append("Relevant regulation excerpts:\n" + articles)
    sys.append(f"Cite articles as <DOC>:<article number>, e.g. IR-2023:19. Documents: {DOC_LIST}.")
    if react_tools:
        sys.append(react_tools)
    else:
        sys.append("Respond with a single JSON object and nothing else:\n" + DECISION_SCHEMA)
    user = f"Application text:\n{case.text(lang)}\n\nAuthority records:\n{render_context(case)}"
    return [{"role": "system", "content": "\n\n".join(sys)}, {"role": "user", "content": user}]


def extract_messages(case: Case, lang: str) -> list[dict]:
    sys = ("[TASK:EXTRACT] You convert a UAS flight application into structured facts. Report only what the text "
           "states. Use true when a document/capability is stated as held, false when it is stated as not held, "
           "expired, revoked, lapsed or pending, and null when it is not mentioned. Do not infer missing values. "
           "Respond with a single JSON object with exactly these keys:\n" + FACT_FIELDS)
    user = f"Submission time (for reference): {case.context.submitted_at:%Y-%m-%d %H:%M}\n\nApplication text:\n{case.text(lang)}"
    return [{"role": "system", "content": sys}, {"role": "user", "content": user}]


REVIEW_SCHEMA = """{
  "extraction_errors": [{"field": <fact key>, "correct_value": <value the application text actually states>}],
  "decision": "APPROVE" | "MODIFY" | "REJECT" | "ESCALATE",
  "confidence": number between 0 and 1,
  "cited_articles": ["<DOC>:<article>", ...],
  "explanation": string (3-6 sentences addressed to the applicant, citing articles)
}"""


def review_messages(case: Case, lang: str, facts: dict, engine_report: str, articles: str | None) -> list[dict]:
    sys = [
        "[TASK:REVIEW] " + ROLE,
        "A deterministic compliance engine has evaluated the structured facts extracted from the application. "
        "Your job: (1) compare each extracted fact with the application text and list in extraction_errors only "
        "the fields whose extracted value differs from what the text states, with the correct value (a fact that "
        "is correctly extracted but violates a rule is NOT an extraction error; use null as correct_value if the "
        "text does not mention it); (2) give your decision: repeat the engine decision unless a regulation has "
        "clearly been misapplied; (3) write the explanation for the applicant. An empty extraction_errors list is "
        "the normal case.",
        DECISION_SEMANTICS,
    ]
    if articles:
        sys.append("Regulation excerpts:\n" + articles)
    sys.append("Respond with a single JSON object and nothing else:\n" + REVIEW_SCHEMA)
    user = (f"Application text:\n{case.text(lang)}\n\nExtracted facts:\n{json.dumps(facts, ensure_ascii=False)}\n\n"
            f"Engine verification report:\n{engine_report}")
    return [{"role": "system", "content": "\n\n".join(sys)}, {"role": "user", "content": user}]


SEPARATION_SCHEMA = """{"conflicts": [{"op_id": string, "severity": "CRITICAL" | "HIGH" | "MEDIUM" | "LOW"}]}"""


def separation_messages(case: Case, facts: dict, table: ConstraintTable) -> list[dict]:
    m = table.minima
    sys = ("[TASK:SEPARATION] You assess separation between a requested UAS operation and approved operations. "
           "For each approved operation compute the horizontal gap (m), vertical gap (m) and time gap (min); a gap is "
           "0 when the two overlap in that dimension. Severity: CRITICAL = overlap in all three dimensions covering "
           f"more than {m.critical_overlap_ratio:g} of the smaller volume; HIGH = overlap in all three dimensions; "
           f"MEDIUM = all gaps below the minima ({m.horizontal_m:g} m, {m.vertical_m:g} m, {m.temporal_min:g} min); "
           f"LOW = all gaps below {m.advisory_factor:g} x the minima. List only operations with a severity. "
           "Respond with a single JSON object:\n" + SEPARATION_SCHEMA)
    user = (f"Requested altitude {facts.get('altitude_min_m')}-{facts.get('altitude_max_m')} m, time "
            f"{facts.get('time_start')} to {facts.get('time_end')}.\n\n{render_context(case)}")
    return [{"role": "system", "content": sys}, {"role": "user", "content": user}]


MODIFY_SCHEMA = """{"time_start": "YYYY-MM-DDTHH:MM", "time_end": "YYYY-MM-DDTHH:MM", "altitude_min_m": number, "altitude_max_m": number, "rationale": string}"""


def modify_messages(case: Case, lang: str, facts: dict, engine_report: str) -> list[dict]:
    sys = ("[TASK:MODIFY] " + ROLE + " The request cannot be approved as submitted. Propose the smallest change to "
           "the time window and/or altitude band (keep the same area and the same duration) that resolves every "
           "issue in the report. Respond with a single JSON object:\n" + MODIFY_SCHEMA)
    user = (f"Application text:\n{case.text(lang)}\n\nExtracted facts:\n{json.dumps(facts, ensure_ascii=False)}\n\n"
            f"Issues:\n{engine_report}\n\nAuthority records:\n{render_context(case)}")
    return [{"role": "system", "content": sys}, {"role": "user", "content": user}]


REACT_TOOLS = """You can use tools. At each step respond with ONE JSON object, either
{"thought": string, "action": tool_name, "args": {...}}
or, when you are ready to decide,
{"thought": string, "final": <decision object>}
Tools:
- search_regulations(query: string): returns relevant regulation articles.
- check_separation(altitude_min_m, altitude_max_m, time_start, time_end): computes separation between the requested area (with the given altitude band and time window) and all approved operations.
- check_geofence(altitude_min_m, altitude_max_m, time_start, time_end): lists geofence zones the requested volume enters.
The decision object has this schema:
""" + DECISION_SCHEMA


JUDGE_SCHEMA = """{"faithfulness": 1-5, "citation_support": 1-5, "actionability": 1-5, "clarity": 1-5, "unsupported_claims": [strings]}"""


def judge_messages(case: Case, engine_report: str, explanation: str, articles: str) -> list[dict]:
    sys = ("[TASK:JUDGE] You grade explanations written for UAS flight applicants. Score 1-5 on: faithfulness (agrees "
           "with the verified engine report, no invented facts), citation_support (cited articles actually support the "
           "claims), actionability (applicant knows what to change), clarity. List unsupported claims. Respond with a "
           "single JSON object:\n" + JUDGE_SCHEMA)
    user = (f"Application:\n{case.text('en')}\n\nVerified engine report:\n{engine_report}\n\nCited article texts:\n"
            f"{articles}\n\nExplanation to grade:\n{explanation}")
    return [{"role": "system", "content": sys}, {"role": "user", "content": user}]
