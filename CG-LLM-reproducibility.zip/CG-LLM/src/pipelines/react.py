"""
ReAct tool-using agent (the conference-version architecture with corrected
tools). The LLM decides; tools only provide retrieval and geometry. Actions
are JSON text, so the agent runs on any chat model without native
function-calling support.
"""

from __future__ import annotations

import json

from src.airspace.separation import Volume
from src.benchmark.schema import Case
from src.pipelines.base import Pipeline
from src.pipelines.baselines import parse_decision_output
from src.pipelines.parsing import extract_json, parse_datetime
from src.pipelines.prompts import REACT_TOOLS, decide_messages
from src.rag.hybrid import format_hits


class ReActAgent(Pipeline):
    name = "react"

    def _volume(self, case: Case, args: dict) -> Volume:
        start = parse_datetime(args.get("time_start"))
        end = parse_datetime(args.get("time_end"), start)
        if start is None or end is None:
            raise ValueError("time_start/time_end must be YYYY-MM-DDTHH:MM")
        return Volume.from_lonlat("REQUEST", case.context.area_coordinates, float(args.get("altitude_min_m") or 0),
                                  float(args["altitude_max_m"]), start, end)

    def tool(self, case: Case, name: str, args: dict) -> str:
        try:
            if name == "search_regulations":
                hits = self.rc.retriever.retrieve(str(args.get("query", "")), k=self.rc.top_k)
                self._retrieved += [h.article_id for h in hits]
                return format_hits(hits, max_chars=500)
            if name == "check_separation":
                sep, _ = self.rc.engine.build_world(case.context)
                return sep.assess(self._volume(case, args)).to_text()
            if name == "check_geofence":
                _, gf = self.rc.engine.build_world(case.context)
                hits = gf.check(self._volume(case, args), self._purpose)
                return "\n".join("- " + h.to_text() for h in hits) or "No geofence zone entered."
            return f"Unknown tool '{name}'."
        except Exception as e:  # noqa: BLE001
            return f"Tool error: {e}"

    def decide(self, case: Case, repeat: int) -> dict:
        max_steps = int(self.options.get("max_steps", 6))
        self._retrieved: list[str] = []
        self._purpose = self.options.get("purpose_hint")
        messages = decide_messages(case, self.rc.lang, react_tools=REACT_TOOLS)
        trace = []
        final = None
        for step in range(max_steps):
            r = self.llm(messages, sample_idx=repeat, tag=f"react_{step}")
            obj = extract_json(r.text) or {}
            if "final" in obj and isinstance(obj["final"], dict):
                final = obj["final"]
                trace.append({"step": step, "final": True})
                break
            if "decision" in obj:
                final = obj
                trace.append({"step": step, "final": True})
                break
            action, args = obj.get("action"), obj.get("args") or {}
            if not action:
                trace.append({"step": step, "error": "no action"})
                messages += [{"role": "assistant", "content": r.text},
                             {"role": "user", "content": "Respond with one JSON object containing either an action or final."}]
                continue
            observation = self.tool(case, str(action), args if isinstance(args, dict) else {})
            trace.append({"step": step, "action": action, "args": args, "observation": observation[:400]})
            messages += [{"role": "assistant", "content": r.text},
                         {"role": "user", "content": f"Observation:\n{observation}"}]
        if final is None:
            messages.append({"role": "user", "content": "Give your final decision now as {\"thought\": ..., \"final\": {...}}."})
            r = self.llm(messages, sample_idx=repeat, tag="react_force")
            obj = extract_json(r.text) or {}
            final = obj.get("final", obj) if isinstance(obj.get("final", obj), dict) else {}
        out = parse_decision_output(json.dumps(final, ensure_ascii=False))
        out["trace"] = trace
        out["retrieved"] = list(dict.fromkeys(self._retrieved))
        out["pre_escalation_decision"] = out["decision"]
        out["escalated"] = out["decision"] == "ESCALATE"
        if out["decision"] == "MODIFY":
            out["modification_check"] = self.check_modification(case, out["modification"])
        return out
