"""
Rule-based (regex) fact extractor for English and Chinese applications.

This is the non-LLM extraction baseline. It is written against the phrasing
families of the benchmark templates and is expected to degrade on
paraphrased text; that degradation is one of the measured results.
"""

from __future__ import annotations

import re
from datetime import datetime
from typing import Optional

from src.policy.facts import RequestFacts

MONTHS = {m: i + 1 for i, m in enumerate(["january", "february", "march", "april", "may", "june", "july", "august",
                                           "september", "october", "november", "december"])}
MONTHS.update({m[:3]: i for m, i in list(MONTHS.items())})

NEG_EN = re.compile(r"\b(not|no|never|expired|lapsed|revoked|pending|under review|without)\b", re.I)
NEG_ZH = re.compile(r"(未|尚未|没有|过期|失效|吊销|审查中|还没有|无任何)")

CRED_EN = [
    ("agri_operating_certificate", re.compile(r"agricultural\s+(?:UAS\s+)?operating certificate", re.I)),
    ("survey_qualification", re.compile(r"surveying (?:and mapping )?qualification|qualified for surveying", re.I)),
    ("operation_certificate", re.compile(r"operation certificate", re.I)),
    ("airworthiness_certificate", re.compile(r"airworthiness", re.I)),
    ("liability_insurance", re.compile(r"insurance", re.I)),
    ("pilot_license", re.compile(r"licen[cs]e|licensed", re.I)),
    ("real_name_registered", re.compile(r"real-name|real name|registered", re.I)),
]
CRED_ZH = [
    ("agri_operating_certificate", re.compile(r"农用无人机操作证书")),
    ("survey_qualification", re.compile(r"测绘资质")),
    ("operation_certificate", re.compile(r"运营合格证")),
    ("airworthiness_certificate", re.compile(r"适航")),
    ("liability_insurance", re.compile(r"责任险|责任保险")),
    ("pilot_license", re.compile(r"执照")),
    ("real_name_registered", re.compile(r"实名")),
]

PURPOSE_EN = [
    ("airport_inspection", r"airport navigation|airport"), ("infrastructure_inspection", r"inspection of the facility|facility we operate"),
    ("agriculture", r"spraying|crop"), ("surveying", r"survey"), ("delivery", r"delivery"),
    ("emergency_rescue", r"rescue"), ("environmental_monitoring", r"water-quality|monitoring"),
    ("training", r"training"), ("performance", r"light show"), ("recreation", r"recreational"),
    ("aerial_photography", r"photograph|filming"),
]
PURPOSE_ZH = [
    ("airport_inspection", r"机场导航"), ("infrastructure_inspection", r"设施的巡检|巡检"), ("agriculture", r"植保|喷洒"),
    ("surveying", r"测绘作业|地形测绘|开展测绘|实施测绘"), ("delivery", r"物流配送"), ("emergency_rescue", r"搜救"),
    ("environmental_monitoring", r"水质监测"), ("training", r"培训"), ("performance", r"灯光表演"),
    ("recreation", r"休闲"), ("aerial_photography", r"航拍"),
]


def _sentences(text: str, lang: str) -> list[str]:
    if lang == "zh":
        return [s for s in re.split(r"(?<=[。！？])", text) if s.strip()]
    return [s for s in re.split(r"(?<=[.!?])\s+(?=[A-Z])", text) if s.strip()]


def _first(pattern: str, text: str, flags=re.I):
    return re.search(pattern, text, flags)


def _parse_en(text: str) -> dict:
    f: dict = {}
    low = text.lower()
    f["operator_type"] = "individual" if re.search(r"private individual|\b[Mm]y name is\b|\bI,\s|\bI am\b", text) else "entity"
    if "non-commercial" in low:
        f["commercial"] = False
    elif re.search(r"\bcommercial\b", low):
        f["commercial"] = True
    purpose_sentence = next((s for s in _sentences(text, "en") if re.search(r"\bpurpose\b|plan to conduct|\bmission\b", s, re.I)), text)
    for p, pat in PURPOSE_EN:
        if re.search(pat, purpose_sentence, re.I):
            f["purpose"] = p
            break
    m = _first(r"(\d+(?:\.\d+)?)\s*kg\b", text)
    if m:
        f["mtow_kg"] = float(m.group(1))
    else:
        m = _first(r"(\d+(?:\.\d+)?)\s*(?:g|grams)\b", text)
        if m:
            f["mtow_kg"] = float(m.group(1)) / 1000
    m = _first(r"(?:aircraft|use an?|is an?)\s*:?\s*(?:a |an )?([A-Z][\w\- ]+?)(?:,| with| \(| weighing)", text, 0)
    if m:
        f["uas_model"] = m.group(1).strip()

    for s in _sentences(text, "en"):
        for field, pat in CRED_EN:
            if pat.search(s) and field not in f:
                if field == "real_name_registered" and not re.search(r"real-name|real name", s, re.I):
                    continue
                f[field] = not bool(NEG_EN.search(s))
                break

    m = _first(r"(\d+(?:\.\d+)?)\s*(?:-|–|to|and)\s*(\d+(?:\.\d+)?)\s*(m|ft|metres|meters|feet)\b", text)
    if m:
        k = 0.3048 if m.group(3) in ("ft", "feet") else 1.0
        f["altitude_min_m"], f["altitude_max_m"] = round(float(m.group(1)) * k, 2), round(float(m.group(2)) * k, 2)
    else:
        m = _first(r"(?:up to|maximum altitude:?)\s*(\d+(?:\.\d+)?)\s*(m|ft|metres|meters|feet)\b", text)
        if m:
            k = 0.3048 if m.group(2) in ("ft", "feet") else 1.0
            f["altitude_min_m"], f["altitude_max_m"] = 0.0, round(float(m.group(1)) * k, 2)

    day = None
    m = _first(r"(\d{4})-(\d{2})-(\d{2})", text)
    if m:
        day = datetime(int(m.group(1)), int(m.group(2)), int(m.group(3)))
    else:
        m = _first(r"(\d{1,2})\s+([A-Za-z]{3,9})\s+(\d{4})", text)
        if m and m.group(2).lower() in MONTHS:
            day = datetime(int(m.group(3)), MONTHS[m.group(2).lower()], int(m.group(1)))
    if day:
        times = re.findall(r"(\d{1,2}):(\d{2})\s*(am|pm)?", text, re.I)
        if len(times) >= 2:
            def to_dt(h, mi, ap):
                h = int(h)
                if ap:
                    h = h % 12 + (12 if ap.lower() == "pm" else 0)
                return day.replace(hour=h, minute=int(mi))
            f["time_start"], f["time_end"] = to_dt(*times[0]), to_dt(*times[1])

    if re.search(r"beyond visual line of sight|\bBVLOS\b", text, re.I):
        f["bvlos"] = True
    elif re.search(r"visual line of sight", text, re.I):
        f["bvlos"] = False
    for s in _sentences(text, "en"):
        if re.search(r"detect-and-avoid|detect and avoid", s, re.I):
            f["daa_capability"] = not bool(NEG_EN.search(s))
        if re.search(r"(?:strobe|navigation|anti-collision|position)[\w\s-]*lights?\b", s, re.I):
            f["lighting"] = not bool(NEG_EN.search(s))
    if re.search(r"emergency (?:request|operation)|\bURGENT\b", text, re.I):
        f["emergency"] = True
    if re.search(r"military", text, re.I):
        f["prohibited_activity"] = True
    return f


def _zh_time(s: str, day: datetime) -> Optional[datetime]:
    m = re.fullmatch(r"(上午|下午|晚上)?(\d{1,2}):(\d{2})", s)
    if not m:
        return None
    h = int(m.group(2))
    if m.group(1) in ("下午", "晚上") and h < 12:
        h += 12
    return day.replace(hour=h, minute=int(m.group(3)))


def _parse_zh(text: str) -> dict:
    f: dict = {}
    f["operator_type"] = "individual" if re.search(r"（个人）|本人", text) else "entity"
    if re.search(r"非经营性|不属于经营性", text):
        f["commercial"] = False
    elif re.search(r"经营性|商业作业", text):
        f["commercial"] = True
    for p, pat in PURPOSE_ZH:
        if re.search(pat, text):
            f["purpose"] = p
            break
    m = re.search(r"(\d+(?:\.\d+)?)\s*千克", text)
    if m:
        f["mtow_kg"] = float(m.group(1))
    else:
        m = re.search(r"(\d+(?:\.\d+)?)\s*克", text)
        if m:
            f["mtow_kg"] = float(m.group(1)) / 1000
    for s in _sentences(text, "zh"):
        for field, pat in CRED_ZH:
            if pat.search(s) and field not in f:
                f[field] = not bool(NEG_ZH.search(s))
                break
    m = re.search(r"(\d+(?:\.\d+)?)\s*(?:米|英尺)?\s*(?:至|-|到)\s*(\d+(?:\.\d+)?)\s*(米|英尺)", text)
    if m:
        k = 0.3048 if m.group(3) == "英尺" else 1.0
        f["altitude_min_m"], f["altitude_max_m"] = round(float(m.group(1)) * k, 2), round(float(m.group(2)) * k, 2)
    else:
        m = re.search(r"(?:不超过|最大飞行高度：)真高(\d+(?:\.\d+)?)(米|英尺)", text)
        if m:
            k = 0.3048 if m.group(2) == "英尺" else 1.0
            f["altitude_min_m"], f["altitude_max_m"] = 0.0, round(float(m.group(1)) * k, 2)
    m = re.search(r"(\d{4})年(\d{1,2})月(\d{1,2})日", text)
    if m:
        day = datetime(int(m.group(1)), int(m.group(2)), int(m.group(3)))
        times = re.findall(r"((?:上午|下午|晚上)?\d{1,2}:\d{2})", text)
        if len(times) >= 2:
            f["time_start"], f["time_end"] = _zh_time(times[0], day), _zh_time(times[1], day)
    if "超视距" in text:
        f["bvlos"] = True
    elif re.search(r"视距内|目视可见", text):
        f["bvlos"] = False
    for s in _sentences(text, "zh"):
        if re.search(r"探测避让|探测与避让", s):
            f["daa_capability"] = not bool(NEG_ZH.search(s))
        if re.search(r"航行灯|频闪灯|防撞灯", s):
            f["lighting"] = not bool(NEG_ZH.search(s))
    if re.search(r"应急飞行|紧急", text):
        f["emergency"] = True
    if "军事" in text:
        f["prohibited_activity"] = True
    return f


def regex_extract(text: str, lang: str = "en") -> RequestFacts:
    data = _parse_zh(text) if lang == "zh" or re.search(r"[\u4e00-\u9fff]", text[:40]) else _parse_en(text)
    return RequestFacts.model_validate(data)
