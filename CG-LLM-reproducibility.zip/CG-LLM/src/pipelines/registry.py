"""Method name -> pipeline class."""

from src.pipelines.baselines import LLMDirect, LLMRag, LLMRules, LLMRulesRag, OracleEngine, RegexEngine
from src.pipelines.cgllm import (CGLLM, CGLLM_FREE_MOD, CGLLM_LLM_SEP, CGLLM_NO_RAG_REVIEW, CGLLM_NO_REVIEW,
                                 CGLLM_REQUEST_QUERY, CGLLM_SC)
from src.pipelines.react import ReActAgent

METHODS = {cls.name: cls for cls in [
    LLMDirect, LLMRules, LLMRag, LLMRulesRag, ReActAgent, RegexEngine, OracleEngine,
    CGLLM, CGLLM_NO_REVIEW, CGLLM_NO_RAG_REVIEW, CGLLM_REQUEST_QUERY, CGLLM_FREE_MOD, CGLLM_LLM_SEP, CGLLM_SC,
]}

NEEDS_RETRIEVER = {"llm_rag", "llm_rules_rag", "react", "cgllm", "cgllm_no_rag_review", "cgllm_request_query",
                   "cgllm_free_mod", "cgllm_llm_sep", "cgllm_sc", "cgllm_no_review"}
