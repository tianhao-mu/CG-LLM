"""Loader for the machine-checkable constraint table (data/constraints)."""

from __future__ import annotations

from dataclasses import dataclass, field
from functools import lru_cache
from pathlib import Path

import yaml

from src.airspace.separation import SeparationMinima

DEFAULT_PATH = Path(__file__).resolve().parents[2] / "data" / "constraints" / "constraints.yaml"


@dataclass
class Constraint:
    id: str
    name: str
    check: str
    effect: dict
    articles: list[str]
    basis: str = "regulation"
    quote_zh: str = ""
    quote_en: str = ""
    condition_text: str = ""
    exemption: str = ""
    params: dict = field(default_factory=dict)


@dataclass
class ConstraintTable:
    version: str
    constraints: list[Constraint]
    minima: SeparationMinima
    approval_articles: list[str]

    def __post_init__(self):
        self._by_check = {c.check: c for c in self.constraints}
        self._by_id = {c.id: c for c in self.constraints}

    def by_check(self, check: str) -> Constraint:
        return self._by_check[check]

    def by_id(self, cid: str) -> Constraint:
        return self._by_id[cid]

    def rules_text(self, lang: str = "en") -> str:
        """Human-readable rule list used inside prompts."""
        lines = []
        for c in self.constraints:
            effects = ", ".join(f"{k} -> {v}" for k, v in c.effect.items())
            quote = c.quote_en if lang == "en" else c.quote_zh
            line = f"- {c.id} ({', '.join(c.articles)}): {c.name}. Effect: {effects}."
            if c.params:
                line += " Params: " + ", ".join(f"{k}={v}" for k, v in c.params.items()) + "."
            if c.exemption:
                line += f" Exemption: {c.exemption}"
            if quote:
                line += f' Source: "{quote}"'
            lines.append(line)
        m = self.minima
        lines.append(f"- Separation minima: horizontal {m.horizontal_m:g} m, vertical {m.vertical_m:g} m, "
                     f"temporal {m.temporal_min:g} min; advisory band = {m.advisory_factor:g} x minima.")
        return "\n".join(lines)


def load_constraints(path: Path | str = DEFAULT_PATH) -> ConstraintTable:
    raw = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    cons = [Constraint(**{k: v for k, v in c.items() if k in Constraint.__dataclass_fields__})
            for c in raw["constraints"]]
    return ConstraintTable(
        version=str(raw.get("version", "")),
        constraints=cons,
        minima=SeparationMinima.from_dict(raw.get("separation_minima")),
        approval_articles=list(raw.get("approval_articles", [])),
    )


@lru_cache(maxsize=1)
def default_table() -> ConstraintTable:
    return load_constraints(DEFAULT_PATH)
