"""
Deterministic rule engine.

Given extracted facts and the case context, every constraint in the table is
checked and produces zero or more triggers. Triggers are of three kinds:

  reject     non-remediable violation -> REJECT
  condition  approvable once a condition is attached (missing document,
             lighting, detect-and-avoid) -> MODIFY
  geometric  approvable only after changing the 4D volume -> MODIFY if the
             modification search finds a verified alternative, else REJECT

Decision policy: any reject -> REJECT; else geometric triggers -> search;
else any condition -> MODIFY; else APPROVE. Missing essential facts ->
INDETERMINATE (escalated to a human reviewer by the pipelines).
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import datetime, timedelta
from functools import lru_cache
from pathlib import Path
from typing import Optional

from src.airspace.geofence import RESTRICTED_TYPES, GeofenceChecker, Zone, ZoneType, load_zones
from src.airspace.separation import SeparationEngine, SeparationReport, Severity, Volume
from src.policy.constraints import ConstraintTable, default_table
from src.policy.facts import CaseContext, RequestFacts

DEFAULT_GEOFENCE = Path(__file__).resolve().parents[2] / "data" / "geofences" / "nanshan.geojson"

APPROVE, MODIFY, REJECT, INDETERMINATE, ESCALATE = "APPROVE", "MODIFY", "REJECT", "INDETERMINATE", "ESCALATE"
DECISIONS = (APPROVE, MODIFY, REJECT)


@dataclass
class Trigger:
    constraint_id: str
    kind: str  # reject | condition | geometric
    effect: str
    detail: str
    articles: list[str]
    condition_text: str = ""

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class Assessment:
    triggers: list[Trigger]
    separation: Optional[SeparationReport]
    zone_hits: list
    missing: list[str]

    @property
    def rejects(self):
        return [t for t in self.triggers if t.kind == "reject"]

    @property
    def geometric(self):
        return [t for t in self.triggers if t.kind == "geometric"]

    @property
    def conditions(self):
        return [t for t in self.triggers if t.kind == "condition"]


@dataclass
class EngineDecision:
    decision: str
    triggers: list[Trigger] = field(default_factory=list)
    modification: Optional[dict] = None
    conditions: list[str] = field(default_factory=list)
    articles: list[str] = field(default_factory=list)
    separation: Optional[dict] = None
    geofence: list[dict] = field(default_factory=list)
    missing: list[str] = field(default_factory=list)

    @property
    def trigger_ids(self) -> list[str]:
        return sorted({t.constraint_id for t in self.triggers})

    def to_dict(self) -> dict:
        return {
            "decision": self.decision,
            "triggers": [t.to_dict() for t in self.triggers],
            "trigger_ids": self.trigger_ids,
            "modification": self.modification,
            "conditions": self.conditions,
            "articles": self.articles,
            "separation": self.separation,
            "geofence": self.geofence,
            "missing": self.missing,
        }

    def to_text(self) -> str:
        """Compact verification report shown to the reviewing LLM."""
        lines = [f"Engine decision: {self.decision}"]
        if self.missing:
            lines.append("Missing essential facts: " + ", ".join(self.missing))
        for t in self.triggers:
            lines.append(f"- {t.constraint_id} [{t.kind} -> {t.effect}] {t.detail} (articles: {', '.join(t.articles)})")
        if self.modification:
            m = self.modification
            label = "Verified modification" if "summary" in m else "Proposed modification (unverified)"
            line = (f"{label}: time {m.get('time_start')} to {m.get('time_end')}, altitude "
                    f"{m.get('altitude_min_m')}-{m.get('altitude_max_m')} m")
            lines.append(line + (f" ({m['summary']})" if m.get("summary") else ""))
        if self.conditions:
            lines.append("Conditions: " + "; ".join(self.conditions))
        if not self.triggers and not self.missing:
            lines.append("No constraint triggered.")
        return "\n".join(lines)


@lru_cache(maxsize=4)
def _static_zones(path: str) -> tuple[Zone, ...]:
    return tuple(load_zones(path))


def _night_minutes(start: datetime, end: datetime, night_start: int, night_end: int) -> int:
    n, t = 0, start
    while t < end:
        if t.hour >= night_start or t.hour < night_end:
            n += 1
        t += timedelta(minutes=1)
    return n


class RuleEngine:
    def __init__(self, table: ConstraintTable | None = None, geofence_path: Path | str | None = DEFAULT_GEOFENCE,
                 use_index: bool = True, search_config: dict | None = None):
        self.table = table or default_table()
        self.static_zones = list(_static_zones(str(geofence_path))) if geofence_path else []
        self.use_index = use_index
        self.search_config = search_config or {}

    # ------------------------------------------------------------------ setup
    def build_world(self, ctx: CaseContext) -> tuple[SeparationEngine, GeofenceChecker]:
        approved = [Volume.from_lonlat(op.op_id, op.coordinates, op.altitude_min_m, op.altitude_max_m,
                                       op.time_start, op.time_end) for op in ctx.approved_ops]
        sep = SeparationEngine(approved, self.table.minima, use_index=self.use_index)
        temp = [Zone.from_dict(z.model_dump()) for z in ctx.temporary_zones]
        return sep, GeofenceChecker(self.static_zones + temp)

    @staticmethod
    def missing_facts(facts: RequestFacts) -> list[str]:
        missing = []
        for f in ("altitude_max_m", "time_start", "time_end"):
            if getattr(facts, f) is None:
                missing.append(f)
        if facts.effective_class is None:
            missing.append("mtow_kg")
        if facts.time_start and facts.time_end and facts.time_end <= facts.time_start:
            missing.append("valid_time_window")
        if facts.altitude_max_m is not None and (facts.altitude_min_m or 0) > facts.altitude_max_m:
            missing.append("valid_altitude_band")
        return missing

    @staticmethod
    def request_volume(facts: RequestFacts, ctx: CaseContext) -> Volume:
        return Volume.from_lonlat("REQUEST", ctx.area_coordinates, facts.altitude_min_m or 0.0,
                                  facts.altitude_max_m, facts.time_start, facts.time_end)

    # ------------------------------------------------------------------ checks
    def _credential(self, check: str, value: Optional[bool], label: str) -> list[Trigger]:
        c = self.table.by_check(check)
        if value is True:
            return []
        if value is False:
            return [Trigger(c.id, "reject", c.effect["explicit_negative"], f"{label} stated as not held",
                            c.articles)]
        effect = c.effect["not_stated"]
        kind = "reject" if effect == REJECT else "condition"
        return [Trigger(c.id, kind, effect, f"{label} not stated in the application", c.articles,
                        c.condition_text)]

    def _credential_triggers(self, f: RequestFacts) -> list[Trigger]:
        cls = f.effective_class
        heavy = cls in ("small", "medium", "large")
        agri = f.purpose == "agriculture"
        out = self._credential("real_name", f.real_name_registered, "Real-name registration")
        agri_exempt = agri and cls in ("micro", "light", "small", "medium")
        if cls != "micro" and f.operator_type != "individual" and not agri_exempt:
            out += self._credential("operation_certificate", f.operation_certificate, "Operation Certificate")
        if f.commercial or heavy:
            out += self._credential("insurance", f.liability_insurance, "Liability insurance")
        if heavy:
            if agri:
                vals = [f.pilot_license, f.agri_operating_certificate]
                val = True if True in vals else (False if False in vals else None)
                out += self._credential("pilot_license", val, "Pilot licence / agricultural operating certificate")
            else:
                out += self._credential("pilot_license", f.pilot_license, "Remote pilot licence")
        if cls in ("medium", "large"):
            out += self._credential("airworthiness", f.airworthiness_certificate, "Airworthiness certificate")
        if f.purpose == "surveying":
            out += self._credential("survey_qualification", f.survey_qualification, "Surveying qualification")
        return out

    def ceiling_for(self, facts: RequestFacts) -> float:
        p = self.table.by_check("altitude").params
        return float(p["micro_ceiling_m"] if facts.effective_class == "micro" else p["ceiling_m"])

    def _altitude_triggers(self, f: RequestFacts) -> list[Trigger]:
        c = self.table.by_check("altitude")
        p = c.params
        ceiling = self.ceiling_for(f)
        if f.altitude_max_m <= ceiling:
            return []
        within = f.altitude_max_m <= ceiling + p["modify_margin_m"] and (f.altitude_min_m or 0) <= ceiling - p["min_band_m"]
        detail = f"Requested ceiling {f.altitude_max_m:g} m exceeds {ceiling:g} m"
        if within:
            return [Trigger(c.id, "geometric", c.effect["within_margin"], detail + " (within margin)",
                            c.articles, c.condition_text)]
        return [Trigger(c.id, "reject", c.effect["beyond_margin"], detail + " (beyond margin)", c.articles)]

    def _filing_triggers(self, f: RequestFacts, ctx: CaseContext) -> list[Trigger]:
        c = self.table.by_check("filing")
        p = c.params
        if f.emergency:
            deadline = f.time_start - timedelta(minutes=p["emergency_lead_min"])
            rule = f"emergency filing at least {p['emergency_lead_min']} min before take-off"
        else:
            day_before = (f.time_start - timedelta(days=1)).date()
            deadline = datetime.combine(day_before, datetime.min.time()).replace(hour=p["routine_deadline_hour"])
            rule = f"filing before {p['routine_deadline_hour']}:00 on the day before the flight"
        if ctx.submitted_at > deadline:
            return [Trigger(c.id, "reject", c.effect["violation"],
                            f"Submitted {ctx.submitted_at:%Y-%m-%d %H:%M}; requires {rule} ({deadline:%Y-%m-%d %H:%M})",
                            c.articles)]
        return []

    def _ops_triggers(self, f: RequestFacts) -> list[Trigger]:
        out = []
        c = self.table.by_check("night_lighting")
        p = c.params
        if f.lighting is not True and _night_minutes(f.time_start, f.time_end, p["night_start_hour"], p["night_end_hour"]) > 0:
            out.append(Trigger(c.id, "condition", c.effect["violation"], "Operation extends into night hours "
                               "without a stated lighting system", c.articles, c.condition_text))
        c = self.table.by_check("bvlos")
        if f.bvlos and f.daa_capability is not True:
            out.append(Trigger(c.id, "condition", c.effect["violation"], "BVLOS operation without stated "
                               "traffic-awareness capability", c.articles, c.condition_text))
        c = self.table.by_check("prohibited_activity")
        if f.prohibited_activity:
            out.append(Trigger(c.id, "reject", c.effect["violation"], "Request involves a prohibited activity",
                               c.articles))
        return out

    def _geofence_triggers(self, hits) -> list[Trigger]:
        out = []
        for h in hits:
            if h.exempt:
                continue
            if h.zone_type in RESTRICTED_TYPES:
                c = self.table.by_check("geofence_restricted")
                out.append(Trigger(c.id, "reject", c.effect["violation"], f"Area intersects {h.to_text()}", c.articles))
            elif h.zone_type == ZoneType.INFRASTRUCTURE:
                c = self.table.by_check("geofence_infrastructure")
                out.append(Trigger(c.id, "reject", c.effect["violation"], f"Area intersects {h.to_text()}", c.articles))
            elif h.zone_type == ZoneType.TEMPORARY:
                c = self.table.by_check("geofence_temporary")
                out.append(Trigger(c.id, "geometric", c.effect["resolvable"], f"Overlaps {h.to_text()}",
                                   c.articles, c.condition_text))
        return out

    def _separation_triggers(self, rep: SeparationReport) -> list[Trigger]:
        out = []
        for p in rep.conflicts:
            if p.severity in (Severity.HIGH, Severity.CRITICAL):
                c = self.table.by_check("separation_severe")
                out.append(Trigger(c.id, "reject", c.effect["violation"], p.to_text(), c.articles))
            else:
                c = self.table.by_check("separation_minor")
                out.append(Trigger(c.id, "geometric", c.effect["resolvable"], p.to_text(), c.articles,
                                   c.condition_text))
        return out

    # ------------------------------------------------------------------ main
    def assess(self, facts: RequestFacts, ctx: CaseContext, world=None, separation_override=None) -> Assessment:
        missing = self.missing_facts(facts)
        if missing:
            return Assessment([], None, [], missing)
        sep, gf = world or self.build_world(ctx)
        vol = self.request_volume(facts, ctx)
        triggers = self._credential_triggers(facts)
        triggers += self._altitude_triggers(facts)
        triggers += self._filing_triggers(facts, ctx)
        triggers += self._ops_triggers(facts)
        hits = gf.check(vol, facts.purpose)
        triggers += self._geofence_triggers(hits)
        if separation_override is not None:
            rep = separation_override
        else:
            rep = sep.assess(vol)
        triggers += self._separation_triggers(rep)
        return Assessment(triggers, rep, hits, [])

    def evaluate(self, facts: RequestFacts, ctx: CaseContext, search: bool = True,
                 separation_override: SeparationReport | None = None) -> EngineDecision:
        from src.policy.modification import search_modification

        world = self.build_world(ctx)
        a = self.assess(facts, ctx, world, separation_override)
        if a.missing:
            return EngineDecision(INDETERMINATE, missing=a.missing)

        geo = [h.to_dict() for h in a.zone_hits]
        sep = a.separation.to_dict() if a.separation else None
        triggers = list(a.triggers)
        modification = None
        conditions = [t.condition_text for t in a.conditions if t.condition_text]

        if a.rejects:
            decision = REJECT
        elif a.geometric:
            modification = search_modification(self, facts, ctx, world, **self.search_config) if search else None
            if modification is None:
                decision = REJECT
                triggers = [Trigger(t.constraint_id, "reject", REJECT, t.detail + " (no verified modification found)",
                                    t.articles) if t.kind == "geometric" else t for t in triggers]
            else:
                decision = MODIFY
                for cond in modification.get("conditions", []):
                    if cond not in conditions:
                        conditions.append(cond)
        elif a.conditions:
            decision = MODIFY
        else:
            decision = APPROVE

        articles = sorted({art for t in triggers for art in t.articles}) or list(self.table.approval_articles)
        return EngineDecision(decision, triggers, modification, conditions, articles, sep, geo)
