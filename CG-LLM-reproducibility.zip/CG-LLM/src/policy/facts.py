"""
Structured facts of an airspace authorization request.

``RequestFacts`` holds what must be read from the free-text application (the
LLM extraction target). ``CaseContext`` holds what the authority already has
in structured form: the submitted area, submission time and the current
airspace picture. Credential fields are tri-state: True (stated as held),
False (stated as not held / expired) and None (not mentioned).
"""

from __future__ import annotations

from datetime import date, datetime, time
from enum import Enum
from typing import Any, Optional

from pydantic import BaseModel, ConfigDict, Field, field_validator


class UASClass(str, Enum):
    MICRO = "micro"
    LIGHT = "light"
    SMALL = "small"
    MEDIUM = "medium"
    LARGE = "large"


class Purpose(str, Enum):
    AERIAL_PHOTOGRAPHY = "aerial_photography"
    DELIVERY = "delivery"
    INFRASTRUCTURE_INSPECTION = "infrastructure_inspection"
    AIRPORT_INSPECTION = "airport_inspection"
    SURVEYING = "surveying"
    AGRICULTURE = "agriculture"
    EMERGENCY_RESCUE = "emergency_rescue"
    ENVIRONMENTAL_MONITORING = "environmental_monitoring"
    TRAINING = "training"
    PERFORMANCE = "performance"
    RECREATION = "recreation"
    OTHER = "other"


CREDENTIAL_FIELDS = [
    "real_name_registered",
    "operation_certificate",
    "pilot_license",
    "agri_operating_certificate",
    "liability_insurance",
    "airworthiness_certificate",
    "survey_qualification",
]


def classify_mtow(mtow_kg: float | None) -> Optional[UASClass]:
    """UA class by maximum take-off weight (IR-2023 Art. 62, simplified to MTOW)."""
    if mtow_kg is None:
        return None
    if mtow_kg < 0.25:
        return UASClass.MICRO
    if mtow_kg <= 7:
        return UASClass.LIGHT
    if mtow_kg <= 25:
        return UASClass.SMALL
    if mtow_kg <= 150:
        return UASClass.MEDIUM
    return UASClass.LARGE


def _to_bool(v: Any) -> Optional[bool]:
    if v is None or isinstance(v, bool):
        return v
    s = str(v).strip().lower()
    if s in {"true", "yes", "y", "1", "held", "valid", "是", "有"}:
        return True
    if s in {"false", "no", "n", "0", "not held", "expired", "否", "无"}:
        return False
    return None


class RequestFacts(BaseModel):
    model_config = ConfigDict(use_enum_values=True, extra="ignore")

    operator_name: Optional[str] = None
    operator_type: Optional[str] = Field(None, description="entity | individual")
    commercial: Optional[bool] = None
    purpose: Optional[Purpose] = None
    uas_model: Optional[str] = None
    mtow_kg: Optional[float] = None
    uas_class: Optional[UASClass] = None

    real_name_registered: Optional[bool] = None
    operation_certificate: Optional[bool] = None
    pilot_license: Optional[bool] = None
    agri_operating_certificate: Optional[bool] = None
    liability_insurance: Optional[bool] = None
    airworthiness_certificate: Optional[bool] = None
    survey_qualification: Optional[bool] = None

    altitude_min_m: Optional[float] = None
    altitude_max_m: Optional[float] = None
    time_start: Optional[datetime] = None
    time_end: Optional[datetime] = None

    emergency: Optional[bool] = None
    bvlos: Optional[bool] = None
    daa_capability: Optional[bool] = None
    lighting: Optional[bool] = None
    prohibited_activity: Optional[bool] = None

    @field_validator("commercial", "emergency", "bvlos", "daa_capability", "lighting",
                     "prohibited_activity", *CREDENTIAL_FIELDS, mode="before")
    @classmethod
    def _bool(cls, v):
        return _to_bool(v)

    @field_validator("purpose", mode="before")
    @classmethod
    def _purpose(cls, v):
        if v in (None, ""):
            return None
        s = str(v).strip().lower().replace(" ", "_").replace("-", "_")
        return s if s in {p.value for p in Purpose} else Purpose.OTHER.value

    @field_validator("uas_class", mode="before")
    @classmethod
    def _cls(cls, v):
        if v in (None, ""):
            return None
        s = str(v).strip().lower()
        return s if s in {c.value for c in UASClass} else None

    @field_validator("mtow_kg", "altitude_min_m", "altitude_max_m", mode="before")
    @classmethod
    def _num(cls, v):
        if v in (None, ""):
            return None
        try:
            return float(v)
        except (TypeError, ValueError):
            return None

    @property
    def effective_class(self) -> Optional[str]:
        """MTOW-derived class takes precedence over a stated class."""
        derived = classify_mtow(self.mtow_kg)
        if derived is not None:
            return derived.value
        return self.uas_class

    def to_json_dict(self) -> dict:
        return self.model_dump(mode="json")


class ApprovedOp(BaseModel):
    op_id: str
    operator: str = ""
    coordinates: list[list[float]]
    altitude_min_m: float
    altitude_max_m: float
    time_start: datetime
    time_end: datetime


class TemporaryZone(BaseModel):
    zone_id: str
    name: str
    coordinates: list[list[float]]
    active_start: datetime
    active_end: datetime
    alt_floor_m: float = 0.0
    alt_ceiling_m: float = 10_000.0
    zone_type: str = "TEMPORARY"
    exempt_purposes: list[str] = Field(default_factory=list)


class CaseContext(BaseModel):
    """Structured data the authority holds independently of the request text."""
    case_id: str
    area_name: str = ""
    area_coordinates: list[list[float]]
    submitted_at: datetime
    approved_ops: list[ApprovedOp] = Field(default_factory=list)
    temporary_zones: list[TemporaryZone] = Field(default_factory=list)


def combine(d: date, t: time) -> datetime:
    return datetime.combine(d, t)
