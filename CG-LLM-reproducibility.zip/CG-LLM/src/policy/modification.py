"""
Verified modification search for MODIFY decisions.

Candidates combine a time shift with an altitude-band change. Each candidate
is re-checked by the full rule engine; it is valid only if no reject or
geometric trigger remains (condition-type triggers are allowed and attached
to the decision). The least-cost valid candidate is returned.

The same verifier scores modifications proposed by LLM-only pipelines.
"""

from __future__ import annotations

from datetime import datetime, timedelta
from typing import TYPE_CHECKING, Optional

from src.policy.facts import CaseContext, RequestFacts

if TYPE_CHECKING:
    from src.policy.engine import RuleEngine

TIME_SHIFTS_MIN = (0, 15, -15, 30, -30, 45, -45, 60, -60, 90, -90, 120, -120, 180, -180, 240, -240)
ALT_SHIFTS_M = (0, -10, 10, -20, 20, -30, 30, -40, 40, -50, 50, -60, 60, -80, 80, -100, 100)


def modification_cost(orig: RequestFacts, alt_min: float, alt_max: float, shift_min: float, n_new_conditions: int) -> float:
    d_alt = (abs(alt_min - (orig.altitude_min_m or 0.0)) + abs(alt_max - orig.altitude_max_m)) / 2
    lost_band = max(0.0, (orig.altitude_max_m - (orig.altitude_min_m or 0.0)) - (alt_max - alt_min))
    return abs(shift_min) / 60.0 + d_alt / 50.0 + lost_band / 50.0 + 0.5 * n_new_conditions


def apply_modification(facts: RequestFacts, alt_min: float, alt_max: float,
                       start: datetime, end: datetime) -> RequestFacts:
    return facts.model_copy(update={"altitude_min_m": alt_min, "altitude_max_m": alt_max,
                                    "time_start": start, "time_end": end})


def _candidate_bands(engine: "RuleEngine", facts: RequestFacts) -> list[tuple[float, float]]:
    ceiling = engine.ceiling_for(facts)
    lo, hi = facts.altitude_min_m or 0.0, facts.altitude_max_m
    if hi > ceiling:
        hi = ceiling
    thickness = hi - lo
    bands = []
    for d in ALT_SHIFTS_M:
        a, b = lo + d, hi + d
        if a < 0 or b > ceiling or thickness <= 0:
            continue
        bands.append((a, b))
    return bands or [(lo, hi)]


def _remaining_blockers(engine: "RuleEngine", facts: RequestFacts, ctx: CaseContext, world) -> tuple[bool, list[str]]:
    a = engine.assess(facts, ctx, world)
    if a.missing or a.rejects or a.geometric:
        return False, []
    return True, [t.condition_text for t in a.conditions if t.condition_text]


def search_modification(engine: "RuleEngine", facts: RequestFacts, ctx: CaseContext, world=None,
                        time_shifts=TIME_SHIFTS_MIN, max_candidates: int | None = None) -> Optional[dict]:
    world = world or engine.build_world(ctx)
    base = engine.assess(facts, ctx, world)
    base_conditions = {t.condition_text for t in base.conditions}

    candidates = []
    for a, b in _candidate_bands(engine, facts):
        for s in time_shifts:
            if s == 0 and a == (facts.altitude_min_m or 0.0) and b == facts.altitude_max_m:
                continue
            candidates.append((modification_cost(facts, a, b, s, 0), a, b, s))
    candidates.sort()
    if max_candidates:
        candidates = candidates[:max_candidates]

    best = None
    for cost, a, b, s in candidates:
        if best is not None and cost >= best["cost"]:
            break
        start = facts.time_start + timedelta(minutes=s)
        end = facts.time_end + timedelta(minutes=s)
        ok, conds = _remaining_blockers(engine, apply_modification(facts, a, b, start, end), ctx, world)
        if not ok:
            continue
        new_conds = [c for c in conds if c not in base_conditions]
        total = modification_cost(facts, a, b, s, len(new_conds))
        if best is None or total < best["cost"]:
            parts = []
            if s:
                parts.append(f"shift time by {s:+d} min")
            if (a, b) != (facts.altitude_min_m or 0.0, facts.altitude_max_m):
                parts.append(f"altitude {facts.altitude_min_m or 0:g}-{facts.altitude_max_m:g} m -> {a:g}-{b:g} m")
            best = {"time_start": start.isoformat(timespec="minutes"), "time_end": end.isoformat(timespec="minutes"),
                    "altitude_min_m": a, "altitude_max_m": b, "time_shift_min": s,
                    "conditions": new_conds, "cost": round(total, 4), "summary": "; ".join(parts)}
    return best


def verify_modification(engine: "RuleEngine", facts: RequestFacts, ctx: CaseContext, proposal: dict | None) -> dict:
    """Check an externally proposed modification.

    ``proposal`` may contain new ``time_start``/``time_end`` (ISO strings) and
    ``altitude_min_m``/``altitude_max_m``; omitted fields keep the original.
    """
    if not proposal:
        return {"valid": False, "reason": "no proposal"}
    if engine.missing_facts(facts):
        return {"valid": False, "reason": "facts incomplete"}
    try:
        start = datetime.fromisoformat(str(proposal.get("time_start") or facts.time_start.isoformat()))
        end = datetime.fromisoformat(str(proposal.get("time_end") or facts.time_end.isoformat()))
        a = float(proposal["altitude_min_m"]) if proposal.get("altitude_min_m") is not None else (facts.altitude_min_m or 0.0)
        b = float(proposal["altitude_max_m"]) if proposal.get("altitude_max_m") is not None else facts.altitude_max_m
    except (TypeError, ValueError) as e:
        return {"valid": False, "reason": f"unparseable proposal: {e}"}
    if end <= start or b <= a:
        return {"valid": False, "reason": "empty volume"}
    changed = (start, end, a, b) != (facts.time_start, facts.time_end, facts.altitude_min_m or 0.0, facts.altitude_max_m)
    ok, conds = _remaining_blockers(engine, apply_modification(facts, a, b, start, end), ctx, None)
    shift = (start - facts.time_start).total_seconds() / 60
    return {"valid": ok, "changed": changed, "conditions": conds,
            "cost": round(modification_cost(facts, a, b, shift, 0), 4),
            "reason": "" if ok else "blocking constraints remain after modification"}
