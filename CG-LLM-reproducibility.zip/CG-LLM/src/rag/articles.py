"""
Article-level segmentation of the regulatory corpus.

Each provision becomes one retrievable unit with a stable id
``<DOC_ID>:<article>`` (e.g. ``IR-2023:19``). The same ids are used by the
constraint table and as gold labels in the retrieval evaluation, so a hit is
an exact clause match rather than a fuzzy chunk overlap.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable

DOC_IDS = {
    "CAAC-2023-无人驾驶航空器飞行管理暂行条例": "IR-2023",
    "CAAC-2024-民用无人驾驶航空器运行安全管理规则": "CCAR-92",
    "CAAC-2015-轻小无人机运行规定": "AC-2015",
    "CAAC-2014-低空空域使用管理规定": "LAU-2014",
    "CAAC-2017-民用无人驾驶航空器实名制登记管理规定": "RNR-2017",
    "SZRD-2024-深圳经济特区低空经济产业促进条例": "SZ-2024",
    "SAMR-2025-低空经济标准体系建设指南": "STD-2025",
    "SAC-2021-无人驾驶航空器系统标准体系建设指南": "STD-2021",
    "NDRC-2025-低空经济及其核心产业统计分类": "NDRC-2025",
}

DOC_TITLES_EN = {
    "IR-2023": "Interim Regulations on the Flight Management of Unmanned Aircraft (2023)",
    "CCAR-92": "Civil UAS Operation Safety Management Rules (CCAR-92, 2024)",
    "AC-2015": "Operating Rules for Light and Small UAS (2015)",
    "LAU-2014": "Regulations on Low-Altitude Airspace Use (Trial, 2014)",
    "RNR-2017": "Real-Name Registration of Civil UA (2017)",
    "SZ-2024": "Shenzhen SEZ Low-Altitude Economy Promotion Regulations (2024)",
    "STD-2025": "Guidelines for the Low-Altitude Economy Standard System (2025)",
    "STD-2021": "Guidelines for the UAS Standard System (2021)",
    "NDRC-2025": "Statistical Classification of the Low-Altitude Economy (2025)",
}

_ZH_DIGITS = {"零": 0, "〇": 0, "一": 1, "二": 2, "两": 2, "三": 3, "四": 4,
              "五": 5, "六": 6, "七": 7, "八": 8, "九": 9}
_ZH_UNITS = {"十": 10, "百": 100, "千": 1000}

_EN_ARTICLE = re.compile(r"^\s*(?:\*\*)?Article\s+(\d+(?:\.\d+)?)\b")
_ZH_ARTICLE = re.compile(r"^\s*第\s*([零〇一二两三四五六七八九十百千]+|\d+(?:\.\d+)?)\s*条")
_SECTION = re.compile(r"^\s*(?:\*\*)?(\d+(?:\.\d+)*)\.?\s+(?!\.)\S")
_TOC_LINE = re.compile(r"\.{5,}|…{3,}")


def zh_numeral_to_int(text: str) -> int:
    """Convert a Chinese numeral such as 二十一 or 一百零二 to an int."""
    if text.isdigit():
        return int(text)
    total, current = 0, 0
    for ch in text:
        if ch in _ZH_DIGITS:
            current = _ZH_DIGITS[ch]
        elif ch in _ZH_UNITS:
            total += (current or 1) * _ZH_UNITS[ch]
            current = 0
    return total + current


@dataclass
class Article:
    article_id: str
    doc_id: str
    number: str
    lang: str
    text: str
    title: str = ""
    meta: dict = field(default_factory=dict)

    def header(self) -> str:
        label = f"Art. {self.number}" if not self.number.startswith("p") else self.number
        return f"[{self.article_id}] {DOC_TITLES_EN.get(self.doc_id, self.doc_id)}, {label}"


def doc_id_for(stem: str) -> str:
    stem = stem.removesuffix("_en")
    return DOC_IDS.get(stem, stem)


def _split_by(lines: list[str], pattern: re.Pattern, to_number) -> list[tuple[str, list[str]]]:
    blocks: list[tuple[str, list[str]]] = []
    current_no, current = None, []
    for line in lines:
        m = pattern.match(line)
        if m and not _TOC_LINE.search(line):
            if current_no is not None:
                blocks.append((current_no, current))
            current_no, current = to_number(m.group(1)), [line]
        elif current_no is not None:
            current.append(line)
    if current_no is not None:
        blocks.append((current_no, current))
    return blocks


def _paragraph_windows(text: str, max_chars: int = 900) -> list[tuple[str, list[str]]]:
    paragraphs = [p.strip() for p in re.split(r"\n\s*\n", text) if p.strip()]
    windows, buf, size = [], [], 0
    for p in paragraphs:
        if buf and size + len(p) > max_chars:
            windows.append(buf)
            buf, size = [], 0
        buf.append(p)
        size += len(p)
    if buf:
        windows.append(buf)
    return [(f"p{i + 1}", w) for i, w in enumerate(windows)]


def split_articles(doc_id: str, text: str, lang: str) -> list[Article]:
    """Split one document into articles, falling back to sections or windows."""
    lines = text.splitlines()
    if lang == "zh":
        blocks = _split_by(lines, _ZH_ARTICLE, lambda g: g if "." in g else str(zh_numeral_to_int(g)))
    else:
        blocks = _split_by(lines, _EN_ARTICLE, lambda g: g)
    if len(blocks) < 3:
        blocks = _split_by(lines, _SECTION, lambda g: f"s{g}")
    if len(blocks) < 3:
        blocks = _paragraph_windows(text)

    merged: dict[str, list[str]] = {}
    for number, block in blocks:
        body = "\n".join(block).strip()
        # Repeated numbers (e.g. a table of contents) keep the longest body.
        if number not in merged or len(body) > len("\n".join(merged[number])):
            merged[number] = [body]

    articles = []
    for number, body in merged.items():
        content = re.sub(r"\n{3,}", "\n\n", body[0]).strip()
        if len(content) < 15:
            continue
        articles.append(Article(
            article_id=f"{doc_id}:{number}",
            doc_id=doc_id,
            number=number,
            lang=lang,
            text=content,
        ))
    return articles


def load_corpus(reg_dir: Path, lang: str = "en") -> list[Article]:
    """Load every regulation file of one language as a list of articles."""
    files: Iterable[Path]
    if lang == "en":
        files = sorted(reg_dir.glob("*_en.txt"))
    else:
        files = sorted(p for p in reg_dir.glob("*.txt") if not p.stem.endswith("_en"))
    articles: list[Article] = []
    for path in files:
        text = path.read_text(encoding="utf-8")
        articles.extend(split_articles(doc_id_for(path.stem), text, lang))
    return articles
