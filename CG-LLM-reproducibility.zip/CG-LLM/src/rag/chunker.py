"""
Chinese/English-aware text chunker.

Uses RecursiveCharacterTextSplitter with Chinese + English punctuation
separators to keep chunks within a reasonable size without truncating
mid-sentence.
"""

import logging
from typing import List

from langchain_text_splitters import RecursiveCharacterTextSplitter

logger = logging.getLogger(__name__)

# Chinese/English priority separator list
# Higher-priority separators appear first — the splitter tries them in order.
CHINESE_SEPARATORS = [
    "\n\n\n",   # Chapter break
    "\n\n",     # Paragraph break
    "\n",       # Line break
    "。",       # Chinese full stop — preferred sentence boundary
    ". ",       # English period + space — English sentence boundary
    "；",       # Chinese semicolon
    "，",       # Chinese comma
    "、",       # Chinese enumeration comma
    " ",        # Space
    "",         # Character-level fallback
]


def create_chinese_chunker(
    chunk_size: int = 800,
    chunk_overlap: int = 100,
) -> RecursiveCharacterTextSplitter:
    """Create a Chinese/English-optimised text chunker.

    Args:
        chunk_size: Maximum characters per chunk (~400–500 tokens for
                    Chinese; ~200–300 tokens for English).
        chunk_overlap: Overlap characters between consecutive chunks.

    Returns:
        A configured RecursiveCharacterTextSplitter.
    """
    return RecursiveCharacterTextSplitter(
        separators=CHINESE_SEPARATORS,
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
        length_function=len,
        is_separator_regex=False,
    )


def chunk_documents(
    documents: List[tuple],
    chunk_size: int = 800,
    chunk_overlap: int = 100,
) -> List[dict]:
    """Chunk a list of regulation documents.

    Args:
        documents: List of (doc_name, content) tuples.
        chunk_size: Chunk size in characters.
        chunk_overlap: Overlap in characters.

    Returns:
        List of dicts: {doc_name, chunk_id, chunk_text, metadata}.
    """
    splitter = create_chinese_chunker(chunk_size, chunk_overlap)
    chunks = []

    for doc_name, content in documents:
        doc_chunks = splitter.create_documents(
            texts=[content],
            metadatas=[{"doc_name": doc_name, "source": doc_name}],
        )

        for i, chunk in enumerate(doc_chunks):
            chunks.append({
                "doc_name": doc_name,
                "chunk_id": f"{doc_name}_chunk_{i:04d}",
                "chunk_text": chunk.page_content,
                "metadata": chunk.metadata,
            })

        logger.debug(f"  {doc_name}: {len(doc_chunks)} chunks")

    logger.info(f"Total chunks: {len(chunks)} from {len(documents)} documents")
    return chunks
