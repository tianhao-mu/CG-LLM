"""
Embedding model wrapper.

Defaults to BAAI/bge-m3, which supports Chinese and English multilingual
embeddings. Supports offline (local) model loading for air-gapped
environments.
"""

import logging
from pathlib import Path
from typing import List, Optional

import numpy as np

logger = logging.getLogger(__name__)


class Embedder:
    """Text embedding model wrapper."""

    def __init__(
        self,
        model_name: str = "BAAI/bge-m3",
        device: str = "cpu",
        normalize: bool = True,
    ):
        """
        Args:
            model_name: HuggingFace model name or SentenceTransformer model name,
                        or a local path to a pre-downloaded model.
            device: 'cpu' or 'cuda'.
            normalize: Whether to L2-normalise the embedding vectors.
        """
        self.model_name = model_name
        self.device = device
        self.normalize = normalize
        self._model = None
        logger.info(f"Embedder config: model={model_name}, device={device}")

    @property
    def model(self):
        """Lazy-load the SentenceTransformer model."""
        if self._model is None:
            from sentence_transformers import SentenceTransformer

            logger.info(f"Loading embedding model: {self.model_name}...")

            # If model path exists locally, load offline (no network required)
            local_path = Path(self.model_name)
            kwargs = {"device": self.device}
            if local_path.exists():
                kwargs["local_files_only"] = True
                logger.info("  Local model detected, loading in offline mode.")

            self._model = SentenceTransformer(self.model_name, **kwargs)
            logger.info("Embedding model loaded.")
        return self._model

    def embed_texts(self, texts: List[str]) -> np.ndarray:
        """Batch-embed a list of texts.

        Args:
            texts: List of text strings.

        Returns:
            numpy array of shape (len(texts), embedding_dim).
        """
        embeddings = self.model.encode(
            texts,
            normalize_embeddings=self.normalize,
            show_progress_bar=(len(texts) > 100),
        )
        return np.array(embeddings)

    def embed_query(self, query: str) -> np.ndarray:
        """Embed a single query string.

        Args:
            query: Query text.

        Returns:
            numpy array of shape (embedding_dim,).
        """
        embedding = self.model.encode(
            query,
            normalize_embeddings=self.normalize,
        )
        return np.array(embedding)

    @property
    def dimension(self) -> int:
        """Embedding vector dimensionality."""
        return self.model.get_sentence_embedding_dimension()
