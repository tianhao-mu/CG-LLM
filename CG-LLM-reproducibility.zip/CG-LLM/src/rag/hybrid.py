"""
Article-level hybrid retrieval: BM25 + dense (optional) fused by RRF, with an
optional cross-encoder reranker.

Dense retrieval and reranking need ``sentence-transformers``; when it is not
installed the retriever runs in BM25-only mode and says so in ``describe()``.
Dense embeddings are cached under data/index/.
"""

from __future__ import annotations

import hashlib
import logging
import re
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import Sequence

import numpy as np
from rank_bm25 import BM25Okapi

from src.rag.articles import Article, load_corpus

log = logging.getLogger(__name__)

ROOT = Path(__file__).resolve().parents[2]
REG_DIR = ROOT / "data" / "regulations"
INDEX_DIR = ROOT / "data" / "index"

_EN_STOP = set("""a an the of to in on for and or by with is are be shall may this that these those as at from
it its into such any other than which who whom whose where when not no under within without per their there
been has have had was were will would can could should must all each""".split())


def tokenize(text: str, lang: str) -> list[str]:
    if lang == "zh":
        import jieba
        jieba.setLogLevel(logging.WARNING)
        toks = [t.strip() for t in jieba.lcut(text)]
        return [t for t in toks if t and not re.fullmatch(r"[\W_]+", t)]
    toks = re.findall(r"[a-z0-9]+(?:\.[0-9]+)?", text.lower())
    return [t for t in toks if t not in _EN_STOP]


@dataclass
class Hit:
    article: Article
    score: float
    rank: int
    source: str

    @property
    def article_id(self) -> str:
        return self.article.article_id


def rrf(rankings: Sequence[Sequence[int]], k: int = 60) -> dict[int, float]:
    scores: dict[int, float] = {}
    for ranking in rankings:
        for r, idx in enumerate(ranking):
            scores[idx] = scores.get(idx, 0.0) + 1.0 / (k + r + 1)
    return scores


class HybridRetriever:
    def __init__(self, lang: str = "en", mode: str = "hybrid", dense_model: str = "BAAI/bge-m3",
                 reranker_model: str | None = None, rrf_k: int = 60, max_per_doc: int | None = None,
                 articles: list[Article] | None = None, reg_dir: Path = REG_DIR, device: str = "cpu"):
        self.lang = lang
        self.articles = articles if articles is not None else load_corpus(reg_dir, lang)
        self.rrf_k = rrf_k
        self.max_per_doc = max_per_doc
        self.device = device
        self.bm25 = BM25Okapi([tokenize(a.text, lang) for a in self.articles])
        self.dense_model_name = dense_model
        self.reranker_model_name = reranker_model
        self._dense = None
        self._emb = None
        self._reranker = None
        self._lock = threading.Lock()
        self.mode = mode
        if mode in ("dense", "hybrid") and not self._ensure_dense():
            log.warning("sentence-transformers unavailable; falling back to BM25 only")
            self.mode = "bm25"

    # ---------------------------------------------------------------- dense
    def _ensure_dense(self) -> bool:
        if self._emb is not None:
            return True
        try:
            from sentence_transformers import SentenceTransformer
        except ImportError:
            return False
        key = hashlib.sha1(("\n".join(a.article_id + a.text[:64] for a in self.articles) + self.dense_model_name)
                           .encode()).hexdigest()[:12]
        cache = INDEX_DIR / f"dense_{self.lang}_{key}.npy"
        self._dense = SentenceTransformer(self.dense_model_name, device=self.device)
        if cache.exists():
            self._emb = np.load(cache)
        else:
            self._emb = self._dense.encode([a.text for a in self.articles], batch_size=16,
                                           normalize_embeddings=True, show_progress_bar=True)
            INDEX_DIR.mkdir(parents=True, exist_ok=True)
            np.save(cache, self._emb)
        return True

    def _dense_rank(self, query: str, n: int) -> list[int]:
        with self._lock:
            q = self._dense.encode([query], normalize_embeddings=True)[0]
        return list(np.argsort(-(self._emb @ q))[:n])

    def _bm25_rank(self, query: str, n: int) -> list[int]:
        scores = self.bm25.get_scores(tokenize(query, self.lang))
        order = np.argsort(-scores)
        return [int(i) for i in order[:n] if scores[i] > 0]

    def _rerank(self, query: str, idxs: list[int]) -> list[tuple[int, float]]:
        with self._lock:
            if self._reranker is None:
                from sentence_transformers import CrossEncoder
                self._reranker = CrossEncoder(self.reranker_model_name, device=self.device)
            scores = self._reranker.predict([(query, self.articles[i].text[:1500]) for i in idxs])
        return sorted(zip(idxs, map(float, scores)), key=lambda x: -x[1])

    # ---------------------------------------------------------------- public
    def describe(self) -> str:
        s = f"{self.mode}"
        if self.reranker_model_name:
            s += f"+rerank({self.reranker_model_name})"
        return s

    def retrieve(self, query: str, k: int = 5, pool: int = 50) -> list[Hit]:
        if self.mode == "bm25":
            fused = [(i, 1.0 / (self.rrf_k + r + 1)) for r, i in enumerate(self._bm25_rank(query, pool))]
        elif self.mode == "dense":
            fused = [(i, 1.0 / (self.rrf_k + r + 1)) for r, i in enumerate(self._dense_rank(query, pool))]
        else:
            s = rrf([self._bm25_rank(query, pool), self._dense_rank(query, pool)], self.rrf_k)
            fused = sorted(s.items(), key=lambda x: -x[1])[:pool]
        if self.reranker_model_name and fused:
            fused = self._rerank(query, [i for i, _ in fused[: max(20, k * 4)]])

        hits, per_doc = [], {}
        for i, score in fused:
            art = self.articles[i]
            if self.max_per_doc and per_doc.get(art.doc_id, 0) >= self.max_per_doc:
                continue
            per_doc[art.doc_id] = per_doc.get(art.doc_id, 0) + 1
            hits.append(Hit(art, float(score), len(hits) + 1, self.describe()))
            if len(hits) >= k:
                break
        return hits

    def get(self, article_id: str) -> Article | None:
        for a in self.articles:
            if a.article_id == article_id:
                return a
        return None


def format_hits(hits: Sequence[Hit], max_chars: int = 700) -> str:
    blocks = []
    for h in hits:
        text = h.article.text
        if len(text) > max_chars:
            text = text[:max_chars] + " ..."
        blocks.append(f"{h.article.header()}\n{text}")
    return "\n\n".join(blocks)
