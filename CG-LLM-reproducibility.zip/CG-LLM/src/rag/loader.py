"""
Regulation document loader.

Supports .txt and .pdf files, converting them to plain text.
"""

import logging
from pathlib import Path
from typing import List, Tuple

logger = logging.getLogger(__name__)


def load_text_file(filepath: Path) -> str:
    """Load a plain-text regulation file (UTF-8 encoding)."""
    with open(filepath, "r", encoding="utf-8") as f:
        return f.read()


def load_pdf_file(filepath: Path) -> str:
    """Load a PDF regulation file (using pypdf)."""
    try:
        from pypdf import PdfReader

        reader = PdfReader(str(filepath))
        texts = []
        for page in reader.pages:
            text = page.extract_text()
            if text:
                texts.append(text)
        return "\n\n".join(texts)
    except ImportError:
        logger.warning(
            "pypdf not installed, PDF support disabled. "
            "Install with: pip install pypdf"
        )
        return ""


def load_regulations(
    data_dir: Path, glob_pattern: str = "*.txt"
) -> List[Tuple[str, str]]:
    """Load all regulation documents from a directory.

    Args:
        data_dir: Directory containing regulation files.
        glob_pattern: File matching pattern.

    Returns:
        List of (filename, content) tuples.
    """
    docs = []
    for filepath in sorted(data_dir.glob(glob_pattern)):
        if filepath.suffix == ".txt":
            content = load_text_file(filepath)
        elif filepath.suffix == ".pdf":
            content = load_pdf_file(filepath)
        else:
            continue

        if content.strip():
            docs.append((filepath.stem, content))
            logger.info(f"Loaded: {filepath.name} ({len(content)} chars)")

    logger.info(f"Total loaded: {len(docs)} documents")
    return docs
