"""
Regulation retriever.

Encapsulates embedding + retrieval logic, providing a clean
search interface.
"""

import logging
from typing import List, Optional

from src.rag.embedder import Embedder
from src.rag.store import RegulationVectorStore

logger = logging.getLogger(__name__)


class RegulationRetriever:
    """Regulation retriever — combines Embedder + VectorStore."""

    def __init__(
        self,
        vector_store: RegulationVectorStore,
        embedder: Embedder,
    ):
        self.store = vector_store
        self.embedder = embedder

    def search(
        self,
        query: str,
        top_k: int = 5,
    ) -> List[dict]:
        """Retrieve the most relevant regulatory provisions.

        Args:
            query: Natural-language query string.
            top_k: Number of results to return.

        Returns:
            List of dicts:
                {"content": regulation text,
                 "metadata": source metadata,
                 "score": similarity score (1 - distance, higher = more relevant)}
        """
        query_emb = self.embedder.embed_query(query)
        result = self.store.search(
            query_embedding=query_emb.tolist(),
            top_k=top_k,
        )

        # Format results
        formatted = []
        if result["documents"] and result["documents"][0]:
            for i in range(len(result["documents"][0])):
                doc = result["documents"][0][i]
                meta = (
                    result["metadatas"][0][i]
                    if result["metadatas"]
                    else {}
                )
                distance = (
                    result["distances"][0][i]
                    if result["distances"]
                    else 1.0
                )
                # Chroma cosine distance → similarity
                score = 1.0 - min(distance, 1.0)

                formatted.append({
                    "content": doc,
                    "metadata": meta,
                    "score": round(score, 4),
                })

        logger.debug(
            f"Retrieved {len(formatted)} results for query: {query[:50]}..."
        )
        return formatted
