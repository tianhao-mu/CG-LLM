"""
Chroma vector store manager.
"""

import logging
from typing import List, Optional

import chromadb
from chromadb.config import Settings

logger = logging.getLogger(__name__)


class RegulationVectorStore:
    """Chroma vector store for regulation documents."""

    def __init__(
        self,
        persist_dir: str = "data/chroma_db",
        collection_name: str | None = None,
    ):
        if collection_name is None:
            from src.config import settings
            collection_name = settings.REGULATION_COLLECTION
        self.persist_dir = persist_dir
        self.collection_name = collection_name

        self._client = chromadb.PersistentClient(
            path=persist_dir,
            settings=Settings(anonymized_telemetry=False),
        )
        self._collection = None
        logger.info(f"VectorStore: persist_dir={persist_dir}")

    @property
    def collection(self):
        if self._collection is None:
            # Get or create collection
            try:
                self._collection = self._client.get_collection(
                    self.collection_name
                )
                logger.info(
                    f"Opened existing collection '{self.collection_name}' "
                    f"({self._collection.count()} docs)"
                )
            except Exception:
                self._collection = self._client.create_collection(
                    name=self.collection_name,
                    metadata={"hnsw:space": "cosine"},
                )
                logger.info(
                    f"Created new collection '{self.collection_name}'"
                )
        return self._collection

    def add_chunks(
        self,
        chunk_ids: List[str],
        chunk_texts: List[str],
        embeddings: List[List[float]],
        metadatas: List[dict],
    ) -> None:
        """Batch-add chunks to the vector store."""
        self.collection.add(
            ids=chunk_ids,
            documents=chunk_texts,
            embeddings=embeddings,
            metadatas=metadatas,
        )
        logger.info(f"Added {len(chunk_ids)} chunks to vector store")

    def search(
        self,
        query_embedding: List[float],
        top_k: int = 5,
    ) -> dict:
        """Similarity search.

        Args:
            query_embedding: Query embedding vector.
            top_k: Number of results to return.

        Returns:
            Chroma query result dict.
        """
        return self.collection.query(
            query_embeddings=[query_embedding],
            n_results=top_k,
            include=["documents", "metadatas", "distances"],
        )

    def count(self) -> int:
        """Return the number of stored documents."""
        return self.collection.count()

    def reset(self) -> None:
        """Delete and recreate the collection."""
        try:
            self._client.delete_collection(self.collection_name)
            logger.info(f"Deleted collection '{self.collection_name}'")
        except Exception:
            pass
        self._collection = None
