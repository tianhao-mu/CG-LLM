"""
Tool base class.

Defines the common interface for Agent tools.
Phase 1 uses a simple functional interface; Phase 2 upgrades to
a LangChain-compatible Tool interface.
"""

from abc import ABC, abstractmethod
from typing import Any, Dict


class BaseTool(ABC):
    """Abstract base class for Agent tools."""

    @property
    @abstractmethod
    def name(self) -> str:
        """Unique tool name."""
        ...

    @property
    @abstractmethod
    def description(self) -> str:
        """Tool description (presented to the LLM)."""
        ...

    @property
    @abstractmethod
    def parameters(self) -> Dict[str, Any]:
        """Parameter schema in OpenAI function-calling format."""
        ...

    @abstractmethod
    def execute(self, **kwargs) -> str:
        """Execute the tool and return a formatted result string."""
        ...
