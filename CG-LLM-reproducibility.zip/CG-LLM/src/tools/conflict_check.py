"""
Conflict detection tool.
"""

import logging
from datetime import datetime
from typing import Any, Dict

from src.airspace.conflict import detect_conflicts
from src.tools.base import BaseTool

logger = logging.getLogger(__name__)


class ConflictCheckTool(BaseTool):
    """Detect spatio-temporal conflicts for a proposed airspace operation."""

    def __init__(self, airspace_manager):
        """
        Args:
            airspace_manager: An AirspaceStateManager instance.
        """
        self._manager = airspace_manager

    @property
    def name(self) -> str:
        return "check_conflicts"

    @property
    def description(self) -> str:
        return (
            "Detect spatio-temporal conflicts between a proposed airspace "
            "operation and existing approved operations. Checks 3D spatial "
            "overlap (horizontal area + altitude band) and temporal overlap."
        )

    @property
    def parameters(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "area_wkt": {
                    "type": "string",
                    "description": "WKT polygon of the proposed operation area",
                },
                "altitude_min_m": {
                    "type": "number",
                    "description": "Minimum flight altitude (metres)",
                },
                "altitude_max_m": {
                    "type": "number",
                    "description": "Maximum flight altitude (metres)",
                },
                "time_start": {
                    "type": "string",
                    "description": "Planned start time (ISO 8601 format)",
                },
                "time_end": {
                    "type": "string",
                    "description": "Planned end time (ISO 8601 format)",
                },
            },
            "required": [
                "area_wkt", "altitude_min_m", "altitude_max_m",
                "time_start", "time_end",
            ],
        }

    def execute(
        self,
        area_wkt: str,
        altitude_min_m: float,
        altitude_max_m: float,
        time_start: str,
        time_end: str,
        **kwargs,
    ) -> str:
        """Execute conflict detection."""
        logger.info(
            f"check_conflicts: alt=[{altitude_min_m}, {altitude_max_m}], "
            f"time=[{time_start}, {time_end}]"
        )

        # Parse time
        try:
            ts = datetime.fromisoformat(time_start)
            te = datetime.fromisoformat(time_end)
        except ValueError as e:
            return f"Time format error: {e}. Please use ISO 8601 format, e.g. '2026-06-24T09:00:00'."

        # Get operations active during the time window
        active_ops = self._manager.get_active_operations(
            time_start=ts, time_end=te
        )
        logger.info(f"  Active operations in time window: {len(active_ops)}")

        # Run conflict detection
        result = detect_conflicts(
            request_area_wkt=area_wkt,
            request_alt_min=altitude_min_m,
            request_alt_max=altitude_max_m,
            request_time_start=ts,
            request_time_end=te,
            existing_operations=active_ops,
        )

        if not result.has_conflict:
            return (
                f"No conflicts detected. {len(active_ops)} approved "
                f"operation(s) are active in the specified time window; "
                f"none overlap with your request."
            )

        # Format conflict details
        output_parts = [
            f"⚠️  Detected {result.conflict_count} conflict(s):\n"
        ]
        for i, c in enumerate(result.conflicts, 1):
            output_parts.append(f"{i}. {c.description}")

        return "\n".join(output_parts)
