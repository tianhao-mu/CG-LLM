"""
Regulation search tool.
"""

import logging
from typing import Any, Dict

from src.tools.base import BaseTool

logger = logging.getLogger(__name__)


class RegulationSearchTool(BaseTool):
    """Search China's low-altitude airspace management regulations."""

    def __init__(self, retriever):
        """
        Args:
            retriever: A RegulationRetriever instance.
        """
        self._retriever = retriever

    @property
    def name(self) -> str:
        return "search_regulations"

    @property
    def description(self) -> str:
        return (
            "Search China's low-altitude airspace management regulations. "
            "Accepts a natural-language query (e.g., 'What permits are required "
            "for flight above 120 m?') and returns the most relevant "
            "regulatory provisions."
        )

    @property
    def parameters(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Natural-language query describing the regulatory question to look up",
                },
                "top_k": {
                    "type": "integer",
                    "description": "Number of results to return (default 5)",
                    "default": 5,
                },
            },
            "required": ["query"],
        }

    def execute(self, query: str, top_k: int = 5, **kwargs) -> str:
        """Execute regulation search."""
        logger.info(f"search_regulations: query='{query[:60]}...', top_k={top_k}")
        results = self._retriever.search(query=query, top_k=top_k)

        if not results:
            return "No relevant regulatory provisions found. Try adjusting your search terms."

        output_parts = [f"Found {len(results)} relevant regulation(s):\n"]
        for i, r in enumerate(results, 1):
            doc_name = r["metadata"].get("doc_name", "Unknown document")
            output_parts.append(
                f"[{i}] Source: {doc_name} | Relevance: {r['score']:.2f}\n"
                f"{r['content']}\n"
            )

        return "\n".join(output_parts)
