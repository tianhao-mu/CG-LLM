"""
Gradio Web UI — LLM-Powered Decision Support Agent
for Low-Altitude Airspace Management.

TRB Annual Conference Paper Demo.
Single-page pipeline: Submit Request → AI Analysis → Human Confirmation.

Usage:
    cd "d:/Tianhao Mu/1科研/TRB-2"
    $env:PYTHONIOENCODING="utf-8"; $env:HF_HUB_OFFLINE="1"; $env:OMP_NUM_THREADS="1"
    C:/Users/Admin/AppData/Local/Python/pythoncore-3.10-64/python.exe -m src.ui.app

    # With public share link:
    C:/Users/Admin/AppData/Local/Python/pythoncore-3.10-64/python.exe -m src.ui.app --share
"""

from __future__ import annotations

import logging
import os
import re
import sys
import traceback
from datetime import datetime
from pathlib import Path
from typing import Optional

import gradio as gr

# ---------------------------------------------------------------------------
# Environment — must be set before any heavy imports
# ---------------------------------------------------------------------------
os.environ.setdefault("PYTHONIOENCODING", "utf-8")
os.environ.setdefault("HF_HUB_OFFLINE", "1")
os.environ.setdefault("OMP_NUM_THREADS", "1")

# Ensure project root on sys.path
PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger("trb2.ui")

# ---------------------------------------------------------------------------
# Custom CSS — Aviation Radar Room aesthetic
# Inspired by ATC workstations and glass cockpit displays.
#
# Design Tokens:
#   navy-deep:    #0D1B2A   main background
#   navy-surface: #162A42   cards / panels
#   navy-input:   #1B3456   input fields
#   atc-cyan:     #00BCD4   primary accent (radar-sweep colour)
#   amber:        #F59E0B   warnings / conflicts / modify
#   green:        #10B981   approvals / safe
#   red:          #EF4444   rejections
#   text-primary: #E9EDF2   high-contrast body
#   text-muted:   #7B8EA8   secondary labels
#   border:       #1E3B5A   subtle borders
#
# Signature element: Radar-grid header pattern + monospace flight-strip
# section labels. The boldness is in the header; everything else is
# disciplined and functional (Chanel's rule: one accessory).
# ---------------------------------------------------------------------------

CUSTOM_CSS = """
/* ---- Global ---- */
/* Professional system font stack — no external dependencies.
   Clean sans-serif for a tool/dashboard look, not a cyberpunk AI product. */
.gradio-container {
    max-width: 960px !important;
    margin: 0 auto !important;
    background: #0D1B2A !important;
    font-family: 'Segoe UI', 'Helvetica Neue', 'Microsoft YaHei', 'PingFang SC', -apple-system, sans-serif !important;
    color: #E9EDF2 !important;
}

/* Override Gradio's default body background */
body, .gradio-container-4-6-0, #root {
    background: #0D1B2A !important;
}

footer { display: none !important; }

/* ---- Header ---- */
.app-header {
    display: flex;
    align-items: center;
    gap: 20px;
    padding: 28px 32px;
    margin-bottom: 28px;
    border-radius: 10px;
    background: #111F33;
    border: 1px solid #1E3B5A;
}
.app-header .logo-col {
    flex-shrink: 0;
}
.app-header .logo-col svg {
    display: block;
}
.app-header .text-col {
    display: flex;
    flex-direction: column;
    gap: 4px;
}
.app-header .title-main {
    font-family: 'Segoe UI', 'Helvetica Neue', 'Microsoft YaHei', 'PingFang SC', sans-serif;
    font-size: 22px;
    font-weight: 700;
    color: #FFFFFF;
    margin: 0;
    line-height: 1.25;
}
.app-header .title-sub {
    font-family: 'Segoe UI', 'Helvetica Neue', 'Microsoft YaHei', 'PingFang SC', sans-serif;
    font-size: 13px;
    font-weight: 400;
    color: #7B8EA8;
    margin: 0;
    letter-spacing: 0.02em;
}

/* ---- Section labels ---- */
.section-label {
    font-family: 'Segoe UI', 'Helvetica Neue', 'Microsoft YaHei', sans-serif;
    font-size: 11px;
    font-weight: 700;
    letter-spacing: 0.08em;
    color: #5A7A9A;
    border-bottom: 1px solid #1E3B5A;
    padding-bottom: 8px;
    margin-bottom: 16px;
    text-transform: uppercase;
}

/* ---- Preset buttons ---- */
.preset-row button {
    font-size: 12px !important;
    padding: 6px 14px !important;
    background: transparent !important;
    border: 1px solid #1E3B5A !important;
    color: #7B8EA8 !important;
    border-radius: 6px !important;
    transition: all 0.2s !important;
}
.preset-row button:hover {
    border-color: #00BCD4 !important;
    color: #00BCD4 !important;
    background: rgba(0,188,212,0.06) !important;
}

/* ---- Primary action button ---- */
#analyze-btn {
    background: linear-gradient(135deg, #008BA8, #00BCD4) !important;
    border: none !important;
    color: #0D1B2A !important;
    font-weight: 600 !important;
    font-size: 15px !important;
    letter-spacing: 0.04em !important;
    padding: 14px 0 !important;
    border-radius: 8px !important;
    transition: all 0.25s !important;
}
#analyze-btn:hover {
    background: linear-gradient(135deg, #00A0C0, #00D4EE) !important;
    box-shadow: 0 0 24px rgba(0,188,212,0.25) !important;
    transform: translateY(-1px) !important;
}

/* ---- Form inputs ---- */
.gr-textbox input, .gr-textbox textarea, textarea, input[type="text"],
input[type="number"], input[type="datetime-local"], select {
    background: #1B3456 !important;
    border: 1px solid #1E3B5A !important;
    color: #E9EDF2 !important;
    border-radius: 6px !important;
}
.gr-textbox input:focus, .gr-textbox textarea:focus, textarea:focus, input:focus {
    border-color: #00BCD4 !important;
    box-shadow: 0 0 0 2px rgba(0,188,212,0.15) !important;
}
.gr-textbox label, .gr-dropdown label, .gr-number label, .gr-slider label {
    color: #7B8EA8 !important;
    font-size: 12px !important;
    font-weight: 500 !important;
    text-transform: uppercase !important;
    letter-spacing: 0.06em !important;
}

/* ---- Dropdown ---- */
.gr-dropdown .wrap, select {
    background: #1B3456 !important;
    border: 1px solid #1E3B5A !important;
    color: #E9EDF2 !important;
}

/* ---- Slider ---- */
.gr-slider input[type="range"] {
    accent-color: #00BCD4;
}

/* ---- Accordion ---- */
.gr-accordion {
    background: #162A42 !important;
    border: 1px solid #1E3B5A !important;
    border-radius: 8px !important;
    margin-bottom: 8px !important;
    color: #E9EDF2 !important;
}
.gr-accordion .label-wrap {
    color: #E9EDF2 !important;
    font-weight: 500 !important;
}
.gr-accordion .label-wrap.open {
    color: #00BCD4 !important;
}
/* Force accordion panel (the expandable body) to dark background */
.gr-accordion > div[role="region"],
.gr-accordion .panel,
.gr-accordion > .wrap > div {
    background: #162A42 !important;
    color: #E9EDF2 !important;
}

/* ---- Markdown inside accordions ---- */
.gr-accordion .prose, .gr-markdown {
    color: #C8D6E5 !important;
}
.gr-accordion h1, .gr-accordion h2, .gr-accordion h3, .gr-accordion h4,
.gr-markdown h1, .gr-markdown h2, .gr-markdown h3, .gr-markdown h4 {
    color: #E9EDF2 !important;
    font-family: 'Segoe UI', 'Helvetica Neue', 'Microsoft YaHei', sans-serif !important;
    font-weight: 700 !important;
}
.gr-markdown strong {
    color: #E9EDF2 !important;
}

/* ---- Group (card) containers ---- */
.gr-group, .gr-box {
    background: #111F33 !important;
    border: 1px solid #1E3B5A !important;
    border-radius: 10px !important;
    padding: 20px !important;
    margin-bottom: 16px !important;
}

/* ---- Loading animation override ---- */
#analyze-btn:disabled {
    opacity: 0.6 !important;
    cursor: wait !important;
}

/* ---- Result content inside accordions ---- */
.result-content {
    color: #C8D6E5 !important;
    font-size: 14px !important;
    line-height: 1.6 !important;
    padding: 4px 0 !important;
}
.result-content h2, .result-content h3 {
    color: #7B8EA8 !important;
    font-weight: 600 !important;
    font-size: 13px !important;
    letter-spacing: 0.03em !important;
    margin: 16px 0 6px 0 !important;
    text-transform: uppercase !important;
}
.result-content ul, .result-content ol {
    padding-left: 18px !important;
    margin: 6px 0 !important;
    list-style-type: square !important;
}
.result-content li {
    margin: 3px 0 !important;
    color: #C8D6E5 !important;
}
.result-content li::marker {
    color: #1E3B5A !important;
}
.result-content p {
    margin: 6px 0 !important;
    color: #C8D6E5 !important;
}

/* ---- Recommendation badge ---- */
.rec-badge {
    display: inline-block !important;
    padding: 6px 18px !important;
    border-radius: 4px !important;
    font-weight: 600 !important;
    font-size: 15px !important;
    letter-spacing: 0.06em !important;
    margin-bottom: 14px !important;
}
.rec-badge.recommendation-approve {
    background: rgba(16,185,129,0.15) !important;
    color: #10B981 !important;
    border: 1px solid rgba(16,185,129,0.3) !important;
}
.rec-badge.recommendation-reject {
    background: rgba(239,68,68,0.12) !important;
    color: #EF4444 !important;
    border: 1px solid rgba(239,68,68,0.25) !important;
}
.rec-badge.recommendation-modify {
    background: rgba(245,158,11,0.12) !important;
    color: #F59E0B !important;
    border: 1px solid rgba(245,158,11,0.25) !important;
}

/* ---- Confidence badge ---- */
.conf-badge {
    display: inline-block !important;
    padding: 4px 14px !important;
    border-radius: 4px !important;
    background: rgba(0,188,212,0.08) !important;
    color: #00BCD4 !important;
    border: 1px solid rgba(0,188,212,0.2) !important;
    font-weight: 500 !important;
    font-size: 14px !important;
    letter-spacing: 0.04em !important;
    margin-bottom: 12px !important;
}

/* ---- Severity keyword colors ---- */
.sev-high {
    color: #EF4444 !important;
    font-weight: 500 !important;
}
.sev-medium {
    color: #F59E0B !important;
    font-weight: 500 !important;
}
.sev-low {
    color: #10B981 !important;
    font-weight: 500 !important;
}
/* Horizontal rules (--- in markdown) */
.result-content hr {
    border: none !important;
    border-top: 1px solid #1E3B5A !important;
    margin: 16px 0 !important;
}
/* Tables */
.result-content table {
    border-collapse: collapse !important;
    width: 100% !important;
    margin: 12px 0 !important;
}
.result-content th {
    background: #1B3456 !important;
    color: #00BCD4 !important;
    padding: 8px 10px !important;
    text-align: left !important;
    font-weight: 600 !important;
    border-bottom: 2px solid #00BCD4 !important;
    font-size: 13px !important;
}
.result-content td {
    padding: 6px 10px !important;
    color: #E9EDF2 !important;
    border-bottom: 1px solid #1E3B5A !important;
    font-size: 13px !important;
}
.result-content tr:nth-child(even) td {
    background: rgba(0,188,212,0.03) !important;
}
/* Inline code */
.result-content code {
    background: #1B3456 !important;
    color: #00BCD4 !important;
    padding: 2px 6px !important;
    border-radius: 4px !important;
    font-family: 'Consolas', 'Courier New', monospace !important;
    font-size: 13px !important;
}
/* Force accordion panel backgrounds to dark (Gradio 6 compat) */
.gr-accordion > div {
    background: #162A42 !important;
}
.gr-accordion [data-testid="accordion-item"] {
    background: #162A42 !important;
    color: #E9EDF2 !important;
}

/* ---- Misc ---- */
#request-status {
    font-family: 'Segoe UI', 'Helvetica Neue', 'Microsoft YaHei', sans-serif;
    font-size: 12px;
    color: #7B8EA8;
}
.gr-prose h2, .gr-prose h3 {
    font-family: 'Segoe UI', 'Helvetica Neue', 'Microsoft YaHei', sans-serif !important;
    font-weight: 700 !important;
}
"""

# ---------------------------------------------------------------------------
# Preset example data (mirrors src/main.py examples)
# ---------------------------------------------------------------------------

PRESETS = {
    1: {
        "operator_name": "SF Express",
        "flight_purpose": "delivery",
        "drone_model": "DJI FlyCart 30",
        "area_desc": "Nanshan Science Park, Shenzhen",
        "area_wkt": (
            "POLYGON((113.945 22.540, 113.955 22.540, "
            "113.955 22.530, 113.945 22.530, 113.945 22.540))"
        ),
        "altitude_min": 80,
        "altitude_max": 110,
        "time_start": "2026-06-24T09:00:00",
        "time_end": "2026-06-24T11:00:00",
        "request_text": (
            "I am an operator from SF Express, applying to conduct "
            "drone delivery flights in the Nanshan Science Park area "
            "of Shenzhen. We use DJI FlyCart 30 drones, "
            "flight altitude 80–110 m, time window 9:00–11:00 on "
            "24 June 2026. The delivery route covers the area between "
            "Kejiyuan South Road and Keyuan Road."
        ),
    },
    2: {
        "operator_name": "Meituan UAV",
        "flight_purpose": "delivery",
        "drone_model": "Meituan Delivery Drone V3",
        "area_desc": "Coastal City shopping district, Nanshan, Shenzhen",
        "area_wkt": (
            "POLYGON((113.935 22.520, 113.945 22.520, "
            "113.945 22.515, 113.935 22.515, 113.935 22.520))"
        ),
        "altitude_min": 50,
        "altitude_max": 80,
        "time_start": "2026-06-24T14:00:00",
        "time_end": "2026-06-24T16:00:00",
        "request_text": (
            "I am an operator from Meituan Unmanned Aerial Vehicles, "
            "applying to conduct food delivery flights in the Coastal "
            "City shopping district of Nanshan, Shenzhen. We use "
            "Meituan's proprietary delivery drones, flight altitude "
            "50–80 m, time window 14:00–16:00 on 24 June 2026. "
            "Delivery area covers a 2 km radius around Coastal City."
        ),
    },
    3: {
        "operator_name": "DJI Innovation",
        "flight_purpose": "testing",
        "drone_model": "DJI Prototype (undisclosed)",
        "area_desc": "Shenzhen Bay Park, Nanshan, Shenzhen",
        "area_wkt": (
            "POLYGON((113.950 22.510, 113.960 22.510, "
            "113.960 22.505, 113.950 22.505, 113.950 22.510))"
        ),
        "altitude_min": 150,
        "altitude_max": 200,
        "time_start": "2026-06-25T08:00:00",
        "time_end": "2026-06-25T12:00:00",
        "request_text": (
            "I am from the DJI Innovation test team, applying to "
            "conduct flight tests of a new UAV model over Shenzhen Bay "
            "Park in Nanshan, Shenzhen. We use an undisclosed prototype, "
            "flight altitude 150–200 m, time window 8:00–12:00 on "
            "25 June 2026. The test area covers a 2 km coastal strip "
            "along Shenzhen Bay Park."
        ),
    },
}

# ---------------------------------------------------------------------------
# Lazy-initialised globals
# ---------------------------------------------------------------------------

_components: Optional[dict] = None  # {"llm": ..., "retriever": ..., "airspace": ...}


def _init_components() -> dict:
    """Initialise backend services (embedder first to avoid segfault)."""
    global _components
    if _components is not None:
        return _components

    from src.config import settings
    from src.llm.deepseek_adapter import DeepSeekAdapter
    from src.rag.embedder import Embedder
    from src.rag.store import RegulationVectorStore
    from src.rag.retriever import RegulationRetriever
    from src.airspace.state import AirspaceStateManager

    logger.info("Initialising backend services (this may take a moment)...")

    # 1. Embedder — MUST load first (Chroma/onnx vs PyTorch segfault avoidance)
    embedder = Embedder(
        model_name=settings.EMBEDDING_MODEL,
        device=settings.EMBEDDING_DEVICE,
    )
    _ = embedder.model  # force eager load

    # 2. LLM client
    llm = DeepSeekAdapter(
        api_key=settings.DEEPSEEK_API_KEY,
        base_url=settings.DEEPSEEK_BASE_URL,
        model=settings.DEEPSEEK_MODEL,
    )

    # 3. RAG
    vector_store = RegulationVectorStore(persist_dir=settings.CHROMA_PERSIST_DIR)
    retriever = RegulationRetriever(vector_store=vector_store, embedder=embedder)

    # 4. Airspace manager
    airspace = AirspaceStateManager(db_path=settings.AIRSPACE_DB_PATH)

    logger.info(
        "Backend ready: %d regulation chunks, %d airspace ops",
        vector_store.count(),
        airspace.count(),
    )

    _components = {
        "llm": llm,
        "retriever": retriever,
        "airspace": airspace,
        "vector_store": vector_store,
    }
    return _components


# ---------------------------------------------------------------------------
# Helpers — parse LLM markdown output
# ---------------------------------------------------------------------------

SECTION_NAMES = [
    "Request Summary",
    "Regulatory Analysis",
    "Conflict Analysis",
    "Risk Assessment",
    "Recommendation",
    "Decision Confidence",
]


def _parse_sections(decision_text: str) -> dict[str, str]:
    """Extract named sections from the LLM's markdown output.

    The system prompt instructs the LLM to output:
        ### Request Summary
        ### Regulatory Analysis
        ### Conflict Analysis
        ### Risk Assessment
        ### Recommendation
        ### Decision Confidence

    Returns a dict mapping underscored keys to markdown content.
    """
    sections: dict[str, str] = {}
    # Normalise: collapse heading levels to ###
    normalised = re.sub(r"^#{1,4}\s+", "### ", decision_text, flags=re.MULTILINE)

    for i, name in enumerate(SECTION_NAMES):
        # Match "### Name" … up to the next "### " or end of string
        escaped = re.escape(name)
        pattern = rf"###\s+{escaped}\s*\n(.*?)(?=###\s+(?:{'|'.join(re.escape(n) for n in SECTION_NAMES)})|\Z)"
        match = re.search(pattern, normalised, re.DOTALL | re.IGNORECASE)
        if match:
            key = name.lower().replace(" ", "_")
            sections[key] = match.group(1).strip()

    return sections


def _extract_recommendation(text: str) -> str:
    """Return APPROVE / REJECT / APPROVE_WITH_MODIFICATIONS / UNKNOWN."""
    # Bold form: **APPROVE WITH MODIFICATIONS**
    m = re.search(
        r"\*\*\s*(APPROVE\s+WITH\s+MODIFICATIONS|APPROVE|REJECT)\s*\*\*",
        text,
        re.IGNORECASE,
    )
    if m:
        return m.group(1).upper().replace(" ", "_")
    # Plain form
    m = re.search(
        r"(APPROVE\s+WITH\s+MODIFICATIONS|APPROVE|REJECT)",
        text,
        re.IGNORECASE,
    )
    if m:
        return m.group(1).upper().replace(" ", "_")
    return "UNKNOWN"


def _extract_confidence(text: str) -> Optional[float]:
    """Try to extract a numeric confidence score (0.0–1.0)."""
    m = re.search(r"(\d+\.\d+)\s*/\s*1\.0", text)
    if m:
        return float(m.group(1))
    m = re.search(r"confidence[:\s]+(\d+\.\d+)", text, re.IGNORECASE)
    if m:
        return float(m.group(1))
    m = re.search(r"(\d+)%\s*confiden", text, re.IGNORECASE)
    if m:
        return float(m.group(1)) / 100.0
    return None


# ---------------------------------------------------------------------------
# Markdown → HTML converter (basic; avoids Gradio 6.19 Markdown-in-Accordion bug)
# ---------------------------------------------------------------------------

import re as _re

def _md_to_html(text: str) -> str:
    """Convert basic markdown to HTML for use inside gr.HTML components."""
    if not text:
        return ""
    html = text

    # ---- Horizontal rules (must come first: --- → <hr>) ----
    html = _re.sub(r"^---+$", r"<hr>", html, flags=_re.MULTILINE)

    # ---- Tables: detect | col | col | row and convert ----
    # Split into lines; if we find a separator line like |---|---|, convert
    # the preceding line + separator + following rows into <table>.
    lines = html.split("\n")
    i = 0
    output_lines = []
    while i < len(lines):
        line = lines[i].strip()
        if "|" in line and i + 1 < len(lines) and _re.match(r"^\|?[\s\-:|]+\|?$", lines[i + 1].strip()):
            # Table detected: lines[i] = header, lines[i+1] = separator,
            # lines[i+2...] = body until a blank or non-| line.
            header = line
            rows = []
            j = i + 2
            while j < len(lines) and "|" in lines[j]:
                rows.append(lines[j].strip())
                j += 1
            # Build <table>
            table_html = "<table>"
            # Header row
            table_html += "<tr>"
            for cell in _split_table_cells(header):
                table_html += f"<th>{_md_inline(cell)}</th>"
            table_html += "</tr>"
            # Body rows
            for row in rows:
                table_html += "<tr>"
                for cell in _split_table_cells(row):
                    table_html += f"<td>{_md_inline(cell)}</td>"
                table_html += "</tr>"
            table_html += "</table>"
            output_lines.append(table_html)
            i = j
        else:
            output_lines.append(lines[i])
            i += 1
    html = "\n".join(output_lines)

    # ---- Inline formatting (minimal: only headings, lists, no aggressive bold) ----
    # Strip ** markers entirely (LLM over-uses bold; we use color for emphasis instead)
    html = _re.sub(r"\*\*(.+?)\*\*", r"\1", html)
    # ### headings
    html = _re.sub(r"^### (.+)$", r"<h3>\1</h3>", html, flags=_re.MULTILINE)
    html = _re.sub(r"^## (.+)$", r"<h2>\1</h2>", html, flags=_re.MULTILINE)
    # Unordered list items: "- text"
    html = _re.sub(r"^- (.+)$", r"<li>\1</li>", html, flags=_re.MULTILINE)
    # Ordered list items: "1. text"
    html = _re.sub(r"^\d+\.\s+(.+)$", r"<li>\1</li>", html, flags=_re.MULTILINE)
    # Wrap consecutive <li> in <ul>
    html = _re.sub(r"(<li>.*?</li>\n?)+", r"<ul>\g<0></ul>", html)
    # Double newlines → paragraph breaks
    html = _re.sub(r"\n\n+", "</p>\n<p>", html)
    # Wrap in <p>
    html = f"<p>{html}</p>"
    # Clean up empty <p></p>, <p><table> → <table>, </table></p> → </table>
    html = _re.sub(r"<p>\s*</p>", "", html)
    html = _re.sub(r"<p>(<table>)", r"\1", html)
    html = _re.sub(r"(</table>)</p>", r"\1", html)
    html = _re.sub(r"<p>\s*</p>\s*(<hr>)", r"\1", html)
    html = _re.sub(r"<p>(<hr>)</p>", r"\1", html)
    html = _highlight_severity(html)
    return html


def _split_table_cells(row: str) -> list[str]:
    """Split a markdown table row like '| a | b | c |' into ['a', 'b', 'c']."""
    # Strip leading/trailing pipe, split on pipe
    row = row.strip()
    if row.startswith("|"):
        row = row[1:]
    if row.endswith("|"):
        row = row[:-1]
    return [c.strip() for c in row.split("|")]


def _md_inline(text: str) -> str:
    """Strip markdown formatting from inline table cell content."""
    text = _re.sub(r"\*\*(.+?)\*\*", r"\1", text)
    return text


def _highlight_severity(html: str) -> str:
    """Color-code severity keywords in the output (HIGH→red, MEDIUM→amber, LOW→green)."""
    html = _re.sub(
        r"\bHIGH\b", r'<span class="sev-high">HIGH</span>', html
    )
    html = _re.sub(
        r"\bMEDIUM\b", r'<span class="sev-medium">MEDIUM</span>', html
    )
    html = _re.sub(
        r"\bLOW\b", r'<span class="sev-low">LOW</span>', html
    )
    return html


# ---------------------------------------------------------------------------
# Callbacks
# ---------------------------------------------------------------------------


def _do_analyze(
    operator_name: str,
    flight_purpose: str,
    drone_model: str,
    area_desc: str,
    area_wkt: str,
    altitude_min: float,
    altitude_max: float,
    time_start: str,
    time_end: str,
    request_text: str,
) -> tuple:
    """Run the full decision pipeline.  Returns values for 7 result components."""

    def _err_html(msg: str) -> str:
        return f'<div class="result-content"><p style="color:#EF4444;">{msg}</p></div>'

    if not request_text.strip():
        empty = _err_html("No request submitted.")
        return (empty,) * 7

    try:
        comps = _init_components()
    except Exception as exc:
        err = _err_html(f"Initialisation failed: {exc}")
        logger.exception("Backend init failed")
        return (err,) * 7

    from src.main import run_decision

    try:
        decision_text = run_decision(
            request_text=request_text,
            area_wkt=area_wkt,
            area_desc=area_desc,
            altitude_min=float(altitude_min),
            altitude_max=float(altitude_max),
            time_start=time_start,
            time_end=time_end,
            llm_client=comps["llm"],
            retriever=comps["retriever"],
            airspace_manager=comps["airspace"],
        )
    except Exception as exc:
        logger.exception("Decision pipeline failed")
        err_html = _err_html(f"Pipeline error: {exc}")
        return (err_html,) * 7

    rec = _extract_recommendation(decision_text)

    # Parse sections
    sections = _parse_sections(decision_text)
    summary_raw = sections.get("request_summary", "*No summary extracted.*")
    reg_raw = sections.get("regulatory_analysis", "*No regulatory analysis extracted.*")
    conflict_raw = sections.get("conflict_analysis", "*No conflict analysis extracted.*")
    risk_raw = sections.get("risk_assessment", "*No risk assessment extracted.*")
    rec_text_raw = sections.get("recommendation", "*No recommendation extracted.*")
    conf_raw = sections.get("decision_confidence", "*No confidence score extracted.*")

    # Convert markdown → HTML wrapper
    def _wrap(inner_html: str, extra_class: str = "") -> str:
        cls = f'result-content {extra_class}'.strip()
        return f'<div class="{cls}">{_md_to_html(inner_html)}</div>'

    # Clean rec_text_raw: strip leading bold recommendation to avoid
    # duplicate with the colored badge (e.g. "**REJECT**\n\nGrounds..." → "Grounds...")
    import re as _re2
    rec_body = _re2.sub(
        r"^\s*\*\*\s*(APPROVE\s*WITH\s*MODIFICATIONS|APPROVE|REJECT)\s*\*\*\s*[\n\r]*",
        "", rec_text_raw, flags=_re2.IGNORECASE
    ).strip()

    # Recommendation display: colored badge header + clean body
    badge_styles = {
        "APPROVE": "recommendation-approve",
        "REJECT": "recommendation-reject",
        "APPROVE_WITH_MODIFICATIONS": "recommendation-modify",
    }
    badge = badge_styles.get(rec, "")
    rec_label = rec.replace("_", " ")
    rec_html = (
        f'<div class="result-content">'
        f'<div class="rec-badge {badge}">{rec_label}</div>'
        f'{_md_to_html(rec_body)}'
        f'</div>'
    )

    # Confidence — simple score badge, then body
    score = _extract_confidence(conf_raw)
    if score is not None:
        pct = f"{score:.0%}"
        conf_body = _re2.sub(
            r"\*\*\s*[Cc]onfidence\s*[Ss]core:?\s*\**\s*\d+\.?\d*\s*\**",
            "", conf_raw, flags=_re2.IGNORECASE
        ).strip()
        conf_html = (
            f'<div class="result-content">'
            f'<div class="conf-badge">Confidence {pct}</div>'
            f'{_md_to_html(conf_body)}'
            f'</div>'
        )
    else:
        conf_html = _wrap(conf_raw)

    return (
        _wrap(summary_raw),
        _wrap(reg_raw),
        _wrap(conflict_raw),
        _wrap(risk_raw),
        rec_html,
        conf_html,
        _wrap(decision_text),
    )


def _fill_preset(preset_id: int) -> tuple:
    """Return form values for a preset scenario."""
    p = PRESETS.get(preset_id, PRESETS[1])
    return (
        p["operator_name"],
        p["flight_purpose"],
        p["drone_model"],
        p["area_desc"],
        p["area_wkt"],
        p["altitude_min"],
        p["altitude_max"],
        p["time_start"],
        p["time_end"],
        p["request_text"],
    )


# ---------------------------------------------------------------------------
# UI Definition
# ---------------------------------------------------------------------------


def create_ui() -> gr.Blocks:
    """Build the Gradio Blocks UI."""

    demo = gr.Blocks(
        title="Decision Support for Low-Altitude Airspace — TRB Demo",
    )

    with demo:
        # ==================================================================
        # HEADER — SVG geometric logo + bold titles
        # ==================================================================
        gr.HTML(
            """
<div class="app-header">
  <div class="logo-col">
    <svg width="64" height="64" viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <!-- Subtle radial gradient for the core -->
        <radialGradient id="coreGlow" cx="32" cy="32" r="14" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stop-color="#00BCD4" stop-opacity="0.18"/>
          <stop offset="100%" stop-color="#00BCD4" stop-opacity="0"/>
        </radialGradient>
        <radialGradient id="dotGlow" cx="0.5" cy="0.5" r="0.5">
          <stop offset="0%" stop-color="#FFFFFF"/>
          <stop offset="100%" stop-color="#00BCD4"/>
        </radialGradient>
      </defs>
      <!-- Background core glow -->
      <circle cx="32" cy="32" r="16" fill="url(#coreGlow)"/>
      <!-- Outer hex: airspace sector boundary (thin, precise) -->
      <polygon points="32,5 55.8,18.5 55.8,45.5 32,59 8.2,45.5 8.2,18.5"
               fill="none" stroke="#00BCD4" stroke-width="1.2" opacity="0.55"/>
      <!-- Mid hex: dashed — represents regulated / managed airspace -->
      <polygon points="32,10 50.2,20.5 50.2,43.5 32,54 13.8,43.5 13.8,20.5"
               fill="none" stroke="#00BCD4" stroke-width="0.8" opacity="0.3"
               stroke-dasharray="2.5 3"/>
      <!-- Inner hex: active monitoring zone -->
      <polygon points="32,16 45,23.5 45,40.5 32,48 19,40.5 19,23.5"
               fill="none" stroke="#00BCD4" stroke-width="1.6" opacity="0.7"/>
      <!-- Sector dividing lines — airspace partitioned into 6 sectors -->
      <line x1="32" y1="16" x2="32" y2="48" stroke="#00BCD4" stroke-width="0.5" opacity="0.25"/>
      <line x1="19" y1="23.5" x2="45" y2="40.5" stroke="#00BCD4" stroke-width="0.5" opacity="0.25"/>
      <line x1="45" y1="23.5" x2="19" y2="40.5" stroke="#00BCD4" stroke-width="0.5" opacity="0.25"/>
      <!-- Connected nodes: 3 anchor points around the inner hex -->
      <circle cx="32" cy="12" r="2" fill="none" stroke="#00BCD4" stroke-width="1.2" opacity="0.6"/>
      <circle cx="51" cy="36" r="2" fill="none" stroke="#00BCD4" stroke-width="1.2" opacity="0.6"/>
      <circle cx="13" cy="36" r="2" fill="none" stroke="#00BCD4" stroke-width="1.2" opacity="0.6"/>
      <!-- Flight path arcs connecting nodes → center -->
      <path d="M32,14 Q32,24 32,30" fill="none" stroke="#00BCD4" stroke-width="0.9" opacity="0.35"/>
      <path d="M34,22 Q39,26 44,31" fill="none" stroke="#00BCD4" stroke-width="0.9" opacity="0.3"/>
      <path d="M30,22 Q25,26 20,31" fill="none" stroke="#00BCD4" stroke-width="0.9" opacity="0.3"/>
      <!-- Central decision node: diamond shape -->
      <polygon points="32,25 37,32 32,39 27,32"
               fill="#0D1B2A" stroke="#00BCD4" stroke-width="2" opacity="0.95"/>
      <!-- Inner dot: the decision point -->
      <circle cx="32" cy="32" r="2.8" fill="url(#dotGlow)"/>
      <!-- Amber accent ring: alert / decision signal -->
      <circle cx="32" cy="32" r="5" fill="none" stroke="#F59E0B" stroke-width="0.7" opacity="0.55"/>
    </svg>
  </div>
  <div class="text-col">
    <div class="title-main">Decision Support for Low-Altitude Airspace Management</div>
    <div class="title-sub">Human-AI Collaborative Decision Pipeline</div>
  </div>
</div>
"""
        )

        # Gradio 6 accordion body background override — ensures dark theme
        # inside all expandable panels (Gradio defaults to light bg)
        gr.HTML(
            """<style>
            .gr-accordion > div { background: #162A42 !important; }
            .gr-accordion .panel { background: #162A42 !important; color: #E9EDF2 !important; }
            </style>"""
        )

        # ==================================================================
        # PRESET BUTTONS
        # ==================================================================
        gr.Markdown(
            '<div class="section-label">Quick Presets</div>'
        )
        with gr.Row(elem_classes="preset-row"):
            preset1 = gr.Button("Preset 1 · SF Express Delivery", size="sm")
            preset2 = gr.Button("Preset 2 · Meituan Food Delivery", size="sm")
            preset3 = gr.Button("Preset 3 · DJI Test Flight (>120m)", size="sm")

        # ==================================================================
        # SECTION 1 — APPLICATION FORM
        # ==================================================================
        gr.Markdown(
            '<div class="section-label">01 · Flight Request Form</div>'
        )

        with gr.Row():
            operator_name = gr.Textbox(
                label="Operator Name",
                placeholder="e.g. SF Express",
                value="SF Express",
                scale=2,
            )
            flight_purpose = gr.Dropdown(
                label="Flight Purpose",
                choices=["delivery", "inspection", "surveying", "testing", "other"],
                value="delivery",
                scale=1,
            )

        drone_model = gr.Textbox(
            label="Drone Model",
            placeholder="e.g. DJI FlyCart 30",
            value="DJI FlyCart 30",
        )

        with gr.Row():
            area_desc = gr.Textbox(
                label="Area Description",
                placeholder="e.g. Nanshan Science Park, Shenzhen",
                value="Nanshan Science Park, Shenzhen",
                scale=2,
            )
            area_wkt = gr.Textbox(
                label="Area WKT Polygon",
                placeholder="POLYGON((lon lat, ...))",
                value=(
                    "POLYGON((113.945 22.540, 113.955 22.540, "
                    "113.955 22.530, 113.945 22.530, 113.945 22.540))"
                ),
                scale=2,
            )

        with gr.Row():
            altitude_min = gr.Slider(
                label="Minimum Altitude (m)",
                minimum=0,
                maximum=3000,
                value=80,
                step=5,
                scale=1,
            )
            altitude_max = gr.Slider(
                label="Maximum Altitude (m)",
                minimum=0,
                maximum=3000,
                value=110,
                step=5,
                scale=1,
            )

        with gr.Row():
            time_start = gr.Textbox(
                label="Start Time (ISO 8601)",
                value="2026-06-24T09:00:00",
                placeholder="YYYY-MM-DDTHH:MM:SS",
                scale=1,
            )
            time_end = gr.Textbox(
                label="End Time (ISO 8601)",
                value="2026-06-24T11:00:00",
                placeholder="YYYY-MM-DDTHH:MM:SS",
                scale=1,
            )

        request_text = gr.Textbox(
            label="Request Description (Natural Language, English)",
            placeholder=(
                "Describe the drone operation in natural language...\n"
                "e.g. I am an operator from SF Express, applying to conduct "
                "drone delivery flights in Nanshan..."
            ),
            lines=4,
            value=PRESETS[1]["request_text"],
        )

        # ==================================================================
        # ANALYSE BUTTON
        # ==================================================================
        gr.Markdown("")
        analyze_btn = gr.Button(
            "Analyze Request",
            variant="primary",
            elem_id="analyze-btn",
            size="lg",
        )
        gr.Markdown(
            '<div id="request-status"></div>'
        )

        # ==================================================================
        # SECTION 2 — RESULTS
        # ==================================================================
        gr.Markdown(
            '<div class="section-label">02 · AI Analysis Results</div>'
        )

        with gr.Accordion("Request Summary", open=True,
                          elem_id="accordion-summary"):
            result_summary = gr.HTML(
                '<div class="result-content">⏳ <em>Pending analysis...</em></div>'
            )

        with gr.Accordion("Regulatory Analysis", open=True,
                          elem_id="accordion-regulatory"):
            result_regulatory = gr.HTML(
                '<div class="result-content">⏳ <em>Pending analysis...</em></div>'
            )

        with gr.Accordion("Conflict Analysis", open=True,
                          elem_id="accordion-conflict"):
            result_conflict = gr.HTML(
                '<div class="result-content">⏳ <em>Pending analysis...</em></div>'
            )

        with gr.Accordion("Risk Assessment", open=True,
                          elem_id="accordion-risk"):
            result_risk = gr.HTML(
                '<div class="result-content">⏳ <em>Pending analysis...</em></div>'
            )

        with gr.Accordion("Recommendation", open=True,
                          elem_id="accordion-recommendation"):
            result_recommendation = gr.HTML(
                '<div class="result-content">⏳ <em>Pending analysis...</em></div>'
            )

        with gr.Accordion("Confidence Score", open=True,
                          elem_id="accordion-confidence"):
            result_confidence = gr.HTML(
                '<div class="result-content">⏳ <em>Pending analysis...</em></div>'
            )

        # Hidden full-text backup
        result_full = gr.HTML(visible=False)

        # ==================================================================
        # EVENT WIRING
        # ==================================================================

        # Preset buttons → fill form
        form_outputs = [
            operator_name, flight_purpose, drone_model,
            area_desc, area_wkt,
            altitude_min, altitude_max,
            time_start, time_end,
            request_text,
        ]
        preset1.click(
            fn=lambda: _fill_preset(1),
            outputs=form_outputs,
        )
        preset2.click(
            fn=lambda: _fill_preset(2),
            outputs=form_outputs,
        )
        preset3.click(
            fn=lambda: _fill_preset(3),
            outputs=form_outputs,
        )

        # Analyze button → run pipeline
        result_outputs = [
            result_summary,
            result_regulatory,
            result_conflict,
            result_risk,
            result_recommendation,
            result_confidence,
            result_full,
        ]
        analyze_btn.click(
            fn=_do_analyze,
            inputs=[
                operator_name, flight_purpose, drone_model,
                area_desc, area_wkt,
                altitude_min, altitude_max,
                time_start, time_end,
                request_text,
            ],
            outputs=result_outputs,
        )

    return demo


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(
        description="TRB-2 Gradio Web UI"
    )
    parser.add_argument(
        "--share",
        action="store_true",
        help="Create a public share link (gradio.live URL, 72h expiry).",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=7860,
        help="Local port (default: 7860).",
    )
    args = parser.parse_args()

    print("=" * 56)
    print("  TRB-2  LLM Decision Support Agent — Web UI")
    print("  Low-Altitude Airspace Management")
    print("=" * 56)
    print()
    print("Initialising backend services (first launch may take ~30s)...")
    print("  → Loading BGE-M3 embedding model (offline)")
    print("  → Connecting to DeepSeek API")
    print("  → Opening Chroma vector store + SQLite airspace DB")
    print()

    demo = create_ui()

    print()
    print(f"Starting Gradio server on http://0.0.0.0:{args.port}")
    if args.share:
        print("Share link will be generated (valid for 72 hours)...")
    print("Press Ctrl+C to stop.")
    print()

    demo.launch(
        share=args.share,
        server_name="0.0.0.0",
        server_port=args.port,
        css=CUSTOM_CSS,
        show_error=True,
        head='<meta name="google" content="notranslate" />',
    )
