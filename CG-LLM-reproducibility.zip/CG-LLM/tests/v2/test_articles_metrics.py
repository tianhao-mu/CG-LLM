from pathlib import Path

import pytest

from src.eval import metrics as M
from src.eval.calibration import ece, risk_coverage
from src.eval.stats import cohen_kappa, fleiss_kappa, mcnemar_exact, wilson_ci
from src.pipelines.parsing import extract_json, normalize_articles, normalize_decision, parse_facts
from src.policy.constraints import default_table
from src.rag.articles import load_corpus, zh_numeral_to_int

REG = Path(__file__).resolve().parents[2] / "data" / "regulations"


def test_zh_numerals():
    assert [zh_numeral_to_int(s) for s in ("一", "十", "十九", "二十一", "六十二", "一百零二")] == [1, 10, 19, 21, 62, 102]


@pytest.mark.parametrize("lang", ["en", "zh"])
def test_constraint_articles_exist_in_corpus(lang):
    ids = {a.article_id for a in load_corpus(REG, lang)}
    for c in default_table().constraints:
        for a in c.articles:
            assert a in ids, (lang, c.id, a)


def test_parsing_helpers():
    assert extract_json('noise ```json\n{"decision": "MODIFY",}\n``` tail') == {"decision": "MODIFY"}
    assert extract_json('<think>{"x":1}</think> {"a": {"b": 2}}') == {"a": {"b": 2}}
    assert normalize_decision("approve with conditions") == "MODIFY"
    assert normalize_decision("conditional") == "MODIFY"
    assert normalize_decision("REJECTED") == "REJECT"
    assert normalize_articles(["IR-2023: Art. 19", "ir-2023:32", "CCAR-92:92.51"]) == ["IR-2023:19", "IR-2023:32", "CCAR-92:92.51"]
    f, _ = parse_facts({"altitude_max_m": "120", "time_start": "2026-11-10T09:00", "time_end": "10:30", "pilot_license": "yes"})
    assert f.altitude_max_m == 120 and f.time_end.hour == 10 and f.pilot_license is True


def _r(gold, pred, cid="c", conf=None, pre=None):
    return {"case_id": cid, "gold_decision": gold, "decision": pred, "confidence": conf, "pre_escalation_decision": pre or pred}


def test_decision_metrics():
    recs = [_r("REJECT", "APPROVE", "1"), _r("REJECT", "REJECT", "2"), _r("APPROVE", "MODIFY", "3"),
            _r("MODIFY", "ESCALATE", "4", pre="APPROVE"), _r("ESCALATE", "ESCALATE", "5")]
    assert M.accuracy(recs) == pytest.approx(2 / 5)
    assert M.unsafe_permissive_rate(recs) == pytest.approx(1 / 3)
    assert M.over_conservative_rate(recs) == pytest.approx(1 / 2)
    assert M.mean_cost(recs) == pytest.approx((10 + 0 + 1 + 0.5 + 0) / 5)
    e = M.escalation_stats(recs)
    assert e["escalation_precision"] == 1.0 and e["incomplete_recall"] == 1.0


def test_stats():
    lo, hi = wilson_ci(50, 100)
    assert lo < 0.5 < hi
    assert mcnemar_exact([True] * 10, [False] * 10)["p_value"] < 0.01
    assert cohen_kappa(list("aabb"), list("aabb")) == 1.0
    assert fleiss_kappa([list("aaa"), list("bbb"), list("aab")]) > 0.4
    assert ece([1.0, 1.0], [True, True]) == 0.0
    assert risk_coverage([0.9, 0.1], [True, False])["risk"] == [0.0, 0.5]
