import pytest

from src.benchmark.generator import RECIPES, generate
from src.benchmark.perturb import add_typos, make_variants, paraphrase_preserves_facts
from src.pipelines.regex_extract import regex_extract
from src.policy.engine import RuleEngine


@pytest.fixture(scope="module")
def cases():
    return generate(n_per_recipe=3, seed=123)[0]


def test_every_recipe_produces_cases(cases):
    assert {c.recipe for c in cases} == set(RECIPES)


def test_gold_equals_engine_and_intent(cases):
    eng = RuleEngine()
    for c in cases:
        d = eng.evaluate(c.gold.request_facts(), c.context).decision
        d = "ESCALATE" if d == "INDETERMINATE" else d
        assert d == c.gold.decision == c.gold.intent, c.case_id


def test_texts_state_every_known_fact(cases):
    """Regex extraction on clean template text recovers the gold decision."""
    eng = RuleEngine()
    for c in cases:
        for lang in ("en", "zh"):
            d = eng.evaluate(regex_extract(c.text(lang), lang), c.context).decision
            d = "ESCALATE" if d == "INDETERMINATE" else d
            assert d == c.gold.decision, (c.case_id, lang, c.text(lang))


def test_variants_keep_labels(cases):
    eng = RuleEngine()
    for c in cases[:30]:
        for v in make_variants(c, eng):
            assert v.gold.decision == c.gold.decision and v.parent_id == c.case_id


def test_paraphrase_check():
    assert paraphrase_preserves_facts("Fly 30-110 m on 2026-11-03.", "Altitude 30 to 110 m, date 2026-11-03.")
    assert not paraphrase_preserves_facts("Insurance is not in place, 110 m.", "Insurance is in place, 110 m.")
    assert add_typos("abc 123", __import__("random").Random(0)) .endswith("123")
