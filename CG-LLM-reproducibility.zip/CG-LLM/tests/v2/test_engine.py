from datetime import datetime

import pytest

from src.benchmark.generator import rect
from src.policy.engine import RuleEngine
from src.policy.facts import ApprovedOp, CaseContext, RequestFacts, classify_mtow
from src.policy.modification import verify_modification
from pyproj import Transformer

FWD = Transformer.from_crs("EPSG:4326", "EPSG:4547", always_xy=True)
CX, CY = FWD.transform(113.951, 22.524)  # Talent Park, clear of static zones
ENGINE = RuleEngine()


def ctx(ops=(), submitted=datetime(2026, 11, 9, 9, 0), cx=CX, cy=CY):
    return CaseContext(case_id="t", area_coordinates=rect(cx, cy, 300, 300), submitted_at=submitted,
                       approved_ops=[ApprovedOp(**o) for o in ops])


def facts(**kw):
    base = dict(operator_type="entity", commercial=True, purpose="aerial_photography", uas_model="DJI Air 3",
                mtow_kg=0.72, real_name_registered=True, operation_certificate=True, liability_insurance=True,
                altitude_min_m=30, altitude_max_m=100, time_start=datetime(2026, 11, 10, 10),
                time_end=datetime(2026, 11, 10, 11))
    base.update(kw)
    return RequestFacts(**base)


def op(dx=0, t0=(11, 5), t1=(12, 0), alt=(30, 100)):
    return dict(op_id="OP1", coordinates=rect(CX + dx, CY, 300, 300), altitude_min_m=alt[0], altitude_max_m=alt[1],
                time_start=datetime(2026, 11, 10, *t0), time_end=datetime(2026, 11, 10, *t1))


def test_mtow_classes():
    assert [classify_mtow(w).value for w in (0.249, 0.72, 9.2, 92, 210)] == ["micro", "light", "small", "medium", "large"]


def test_clean_request_is_approved():
    assert ENGINE.evaluate(facts(), ctx()).decision == "APPROVE"


@pytest.mark.parametrize("kw, decision, trigger", [
    (dict(liability_insurance=None), "MODIFY", "C03_LIABILITY_INSURANCE"),
    (dict(liability_insurance=False), "REJECT", "C03_LIABILITY_INSURANCE"),
    (dict(altitude_max_m=140), "MODIFY", "C06_ALTITUDE_CEILING"),
    (dict(altitude_max_m=200), "REJECT", "C06_ALTITUDE_CEILING"),
    (dict(time_start=datetime(2026, 11, 10, 18, 30), time_end=datetime(2026, 11, 10, 19, 30)), "MODIFY", "C08_NIGHT_LIGHTING"),
    (dict(bvlos=True), "MODIFY", "C09_BVLOS_AWARENESS"),
    (dict(prohibited_activity=True), "REJECT", "C10_PROHIBITED_ACTIVITY"),
    (dict(mtow_kg=9.2), "MODIFY", "C04_PILOT_LICENSE"),
])
def test_single_constraint(kw, decision, trigger):
    d = ENGINE.evaluate(facts(**kw), ctx())
    assert d.decision == decision
    assert trigger in d.trigger_ids


def test_filing_deadline_boundary():
    assert ENGINE.evaluate(facts(), ctx(submitted=datetime(2026, 11, 9, 12, 0))).decision == "APPROVE"
    d = ENGINE.evaluate(facts(), ctx(submitted=datetime(2026, 11, 9, 12, 1)))
    assert d.decision == "REJECT" and "C07_FILING_DEADLINE" in d.trigger_ids


def test_missing_altitude_is_indeterminate():
    assert ENGINE.evaluate(facts(altitude_max_m=None), ctx()).decision == "INDETERMINATE"


def test_separation_modification_is_verified():
    c = ctx([op()])
    d = ENGINE.evaluate(facts(), c)
    assert d.decision == "MODIFY" and d.modification is not None
    assert verify_modification(ENGINE, facts(), c, d.modification)["valid"]
    assert not verify_modification(ENGINE, facts(), c, {"time_start": "2026-11-10T10:00", "time_end": "2026-11-10T11:00"})["valid"]


def test_strict_overlap_rejected():
    d = ENGINE.evaluate(facts(), ctx([op(t0=(10, 30), t1=(11, 30))]))
    assert d.decision == "REJECT" and "C14_SEPARATION_SEVERE" in d.trigger_ids


def test_airport_zone_and_exemption():
    ax, ay = FWD.transform(113.811, 22.639)
    c = ctx(cx=ax, cy=ay)
    assert ENGINE.evaluate(facts(), c).decision == "REJECT"
    assert ENGINE.evaluate(facts(purpose="airport_inspection", commercial=False), c).decision == "APPROVE"
