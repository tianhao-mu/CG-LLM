import pytest

from src.benchmark.generator import generate
from src.llm.providers import LLMClient, load_registry
from src.pipelines.base import RunContext
from src.pipelines.registry import METHODS
from src.policy.engine import RuleEngine
from src.rag.hybrid import HybridRetriever


@pytest.fixture(scope="module")
def setup():
    cases = generate(n_per_recipe=1, seed=7)[0]
    client = LLMClient(load_registry(), cache_path=None, use_cache=False)
    retr = {lang: HybridRetriever(lang=lang, mode="bm25") for lang in ("en", "zh")}
    return cases, client, retr


@pytest.mark.parametrize("method", sorted(METHODS))
@pytest.mark.parametrize("lang", ["en", "zh"])
def test_every_method_runs_offline(setup, method, lang):
    cases, client, retr = setup
    rc = RunContext(client=client, model="mock", lang=lang, engine=RuleEngine(), retriever=retr[lang])
    pipe = METHODS[method](rc)
    for c in cases[:12]:
        rec = pipe.run(c)
        assert not rec["error"], rec.get("traceback")
        assert rec["decision"] in ("APPROVE", "MODIFY", "REJECT", "ESCALATE", None)


def test_oracle_and_full_mock_pipeline_are_exact(setup):
    cases, client, retr = setup
    rc = RunContext(client=client, model="mock", engine=RuleEngine(), retriever=retr["en"])
    for name in ("oracle_engine", "cgllm_no_review"):
        pipe = METHODS[name](rc)
        assert all(pipe.run(c)["decision"] == c.gold.decision for c in cases), name
