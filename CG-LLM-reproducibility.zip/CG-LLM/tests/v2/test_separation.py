from datetime import datetime

import pytest

from src.airspace.separation import SeparationEngine, Severity, Volume
from src.benchmark.generator import rect
from src.geo.projection import polygon_lonlat_to_metric, rectangle_lonlat
from pyproj import Transformer

FWD = Transformer.from_crs("EPSG:4326", "EPSG:4547", always_xy=True)
CX, CY = FWD.transform(113.95, 22.53)
T = datetime(2026, 11, 10, 10, 0)


def vol(vid, dx=0, w=300, alt=(30, 90), t0=(10, 0), t1=(11, 0)):
    return Volume.from_lonlat(vid, rect(CX + dx, CY, w, 300), *alt, T.replace(hour=t0[0], minute=t0[1]),
                              T.replace(hour=t1[0], minute=t1[1]))


def test_metric_area_is_in_square_metres():
    poly = polygon_lonlat_to_metric(rectangle_lonlat(113.95, 22.53, 400, 300))
    assert poly.area == pytest.approx(120_000, rel=1e-3)


@pytest.mark.parametrize("other, expected", [
    (dict(), Severity.CRITICAL),
    (dict(dx=200), Severity.HIGH),                         # 100 m x-overlap of 300 m
    (dict(dx=330), Severity.MEDIUM),                       # 30 m horizontal gap
    (dict(dx=380), Severity.LOW),                          # 80 m gap < 2 x 50 m
    (dict(dx=420), Severity.NONE),                         # 120 m gap
    (dict(alt=(110, 140)), Severity.MEDIUM),               # 20 m vertical gap
    (dict(alt=(150, 160)), Severity.NONE),                 # 60 m vertical gap = 2 x 30 m
    (dict(t0=(11, 5), t1=(12, 0)), Severity.MEDIUM),       # 5 min gap
    (dict(t0=(11, 20), t1=(12, 0)), Severity.NONE),        # 20 min gap = 2 x 10 min
])
def test_severity_levels(other, expected):
    eng = SeparationEngine([vol("O", **other)])
    assert eng.assess(vol("R")).max_severity == expected


def test_single_dimension_overlap_is_not_a_conflict():
    # Same footprint and altitude, but 3 hours apart: the conference version flagged this.
    eng = SeparationEngine([vol("O", t0=(14, 0), t1=(15, 0))])
    assert eng.assess(vol("R")).max_severity == Severity.NONE


def test_index_matches_brute_force():
    ops = [vol(f"O{i}", dx=i * 90, alt=(20 + i % 3 * 30, 60 + i % 3 * 30)) for i in range(25)]
    req = vol("R", dx=600)
    a = SeparationEngine(ops, use_index=True).assess(req)
    b = SeparationEngine(ops, use_index=False).assess(req)
    sig = lambda r: sorted((p.other_id, p.severity) for p in r.conflicts)
    assert sig(a) == sig(b)
